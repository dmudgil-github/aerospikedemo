package com.aerospike.fraud.demo.txn.model;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.aerospike.fraud.demo.txn.database.mappers.CustomerMapper;
import com.aerospike.fraud.demo.txn.util.seed.CustomerSeeder;

public class AllModelTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		CustomerMapper customerMapper = new CustomerMapper();
	}

}
