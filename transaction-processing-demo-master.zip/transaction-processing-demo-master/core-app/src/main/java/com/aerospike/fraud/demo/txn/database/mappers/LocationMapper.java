package com.aerospike.fraud.demo.txn.database.mappers;

import java.util.ArrayList;
import java.util.List;

import com.aerospike.fraud.demo.txn.database.Column;
import com.aerospike.fraud.demo.txn.database.DataElement;
import com.aerospike.fraud.demo.txn.database.RecordData;
import com.aerospike.fraud.demo.txn.model.Location;

/**
 * This class performs mapping from database records to Locations and back.
 * This could be done with a lot less code using annotations and introspection, but
 * this has a runtime performance penalty and this is key in this use case.
 * @author Tim
 *
 */
public class LocationMapper {
	public Location fromRecord(RecordData record) {
		Location result = null;
		if (record != null) {
			result = new Location();
			result.setCountry(record.getString("country"));
			result.setPostalCode(record.getString("pc"));
			result.setId(record.getString("id"));
			result.setAddress(record.getString("address"));
			result.setLat(record.getDouble("lat"));
			result.setLng(record.getDouble("lng"));
		}
		return result;
	}
	
	public Column[] toRecord(Location Location) {
		List<Column> elements = new ArrayList<Column>();
		elements.add(new Column("country", DataElement.get(Location.getCountry())));
		elements.add(new Column("pc", DataElement.get(Location.getPostalCode())));
		elements.add(new Column("id", DataElement.get(Location.getId())));
		elements.add(new Column("address", DataElement.get(Location.getAddress())));
		elements.add(new Column("lat", DataElement.get(Location.getLat())));
		elements.add(new Column("lng", DataElement.get(Location.getLng())));
		return elements.toArray(new Column[0]);
	}

}
