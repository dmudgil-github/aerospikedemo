package com.aerospike.fraud.demo.txn.util.logging;

public class NullLogger extends Logger{

	@Override
	public void log(String value) {
	}

}
