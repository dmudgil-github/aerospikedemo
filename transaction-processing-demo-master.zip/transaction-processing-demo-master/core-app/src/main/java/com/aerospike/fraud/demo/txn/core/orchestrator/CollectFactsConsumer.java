package com.aerospike.fraud.demo.txn.core.orchestrator;

import com.aerospike.fraud.demo.txn.client.Statistics;
import com.aerospike.fraud.demo.txn.client.Statistics.OperationStatistics;
import com.aerospike.fraud.demo.txn.core.orchestrator.TxnFraudOrchestrator.FraudResult;
import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.database.DatabaseKey;
import com.aerospike.fraud.demo.txn.database.PreparedDatabaseStatement;
import com.aerospike.fraud.demo.txn.database.RecordData;
import com.aerospike.fraud.demo.txn.database.mappers.AccountMapper;
import com.aerospike.fraud.demo.txn.database.mappers.CreditCardMapper;
import com.aerospike.fraud.demo.txn.database.mappers.CustomerMapper;
import com.aerospike.fraud.demo.txn.model.Account;
import com.aerospike.fraud.demo.txn.model.CreditCard;
import com.aerospike.fraud.demo.txn.model.Customer;
import com.aerospike.fraud.demo.txn.model.FraudFactsModel;
import com.aerospike.fraud.demo.txn.util.logging.Logger;

class CollectFactsConsumer {

//	private final Database database;
	private final Logger logger;
	private final String namespace;
	private static final CreditCardMapper cardMapper = new CreditCardMapper();
	private static final AccountMapper accountMapper = new AccountMapper();
	private static final CustomerMapper customerMapper = new CustomerMapper();
	private final OperationStatistics cardStats;
	private final OperationStatistics accountStats;
	private final OperationStatistics customerStats;
	private static PreparedDatabaseStatement whiteListPreparedStatement = null;
	private static PreparedDatabaseStatement blackListPreparedStatement = null;
	private static PreparedDatabaseStatement cardsListPreparedStatement = null;
	private static PreparedDatabaseStatement accountsListPreparedStatement = null;
	private static PreparedDatabaseStatement customersListPreparedStatement = null;

	public CollectFactsConsumer(Database database, Logger logger, String namespace) {
//		this.database = database;
		this.logger = logger;
		this.namespace = namespace;
		this.cardStats = Statistics.getInstance().getStats(Statistics.CARD_READ_STATS);
		this.accountStats = Statistics.getInstance().getStats(Statistics.ACCOUNT_READ_STATS);
		this.customerStats = Statistics.getInstance().getStats(Statistics.CUSTOMER_READ_STATS);
		synchronized(CollectFactsConsumer.class) {
			if (whiteListPreparedStatement == null) {
				whiteListPreparedStatement = database.prepare("select cardNo,reason,date from " + namespace + ".whiteListCards where cardNo = ?");
			}
			if (blackListPreparedStatement == null) {
				blackListPreparedStatement = database.prepare("select cardNo,reason,date from " + namespace + ".blackListCards where cardNo = ?");
			}
			if (cardsListPreparedStatement == null) {
				cardsListPreparedStatement = database.prepare("select cardNo,accountId,expMon,expYear,nameOnCard,padding0,padding1,padding2,padding3,padding4,padding5,padding6,padding7,padding8,padding9 from " + namespace + ".cards where cardNo = ?");
			}
			if (accountsListPreparedStatement == null) {
				accountsListPreparedStatement = database.prepare("select number,name,custId,opened,cards,padding0,padding1,padding2,padding3,padding4,padding5,padding6,padding7,padding8,padding9 from " + namespace + ".accounts where number = ?");
			}
			if (customersListPreparedStatement == null) {
				customersListPreparedStatement = database.prepare("select id,firstName,lastName,addr,city,postcode,joined,numAccounts,accounts,padding0,padding1,padding2,padding3,padding4,padding5,padding6,padding7,padding8,padding9 from " + namespace + ".customers where id = ?");
			}
		}
	}
	
	protected FraudResult collectCustomerAccountCardInfo(String txnId, String pan, FraudFactsModel fraudFacts) {
		RecordData result = null;

		FraudResult fraudResult = FraudResult.OK;
		
		// Check for whitelisted and blacklisted cards
		OperationStatistics blackListStats = Statistics.getInstance().getStats(Statistics.BLACK_LIST_STATS);
		long time = blackListStats.beginMeasure();
		result = blackListPreparedStatement.get(new DatabaseKey(namespace, "blackListCards", pan));
		blackListStats.endMeasure(time);
		if (result == null) {
			// Check to see if it's in the whitelist 
			OperationStatistics whiteListStats = Statistics.getInstance().getStats(Statistics.WHITE_LIST_STATS);
			whiteListStats.beginMeasure();
			result = whiteListPreparedStatement.get(new DatabaseKey(namespace, "whiteListCards", pan));
			whiteListStats.endMeasure(time);
			if (result != null) {
				whiteListStats.addHit();
				fraudResult = FraudResult.WHITE_LISTED;
			}
		}
		else {
			blackListStats.addHit();
			fraudResult = FraudResult.BLACK_LISTED;
		}
		
		// Load the card, the account and the customer
		time = cardStats.beginMeasure();
		result = cardsListPreparedStatement.get(new DatabaseKey(this.namespace, "cards", pan));
		cardStats.endMeasure(time);
		if (result != null) {
			cardStats.addHit();
			CreditCard card = cardMapper.fromRecord(result);
			fraudFacts.setCard(card);
			time = accountStats.beginMeasure();
			result = accountsListPreparedStatement.get(new DatabaseKey(this.namespace, "accounts", card.getAccountId()));
			accountStats.endMeasure(time);
			if (result != null) {
				accountStats.addHit();
				Account account = accountMapper.fromRecord(result);
				fraudFacts.setAccount(account);
				time = customerStats.beginMeasure();
				result = customersListPreparedStatement.get(new DatabaseKey(this.namespace, "customers", account.getCustomerId()));
				customerStats.endMeasure(time);
				if (result != null) {
					customerStats.addHit();
					Customer customer = customerMapper.fromRecord(result);
					fraudFacts.setCustomer(customer);
				} else {
					logger.log("Txn %s: could not find customer %s", txnId, account.getCustomerId());
					return FraudResult.MISSING_DATA;
				}
			} else {
				logger.log("Txn %s: could not find account %s", txnId, card.getAccountId());
				return FraudResult.MISSING_DATA;
			}
		} else {
			logger.log("Txn %s: could not find card %s", txnId, pan);
			return FraudResult.MISSING_DATA;
		}
		return FraudResult.OK;
	}
}