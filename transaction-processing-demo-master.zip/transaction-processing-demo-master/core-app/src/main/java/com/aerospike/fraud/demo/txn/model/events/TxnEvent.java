package com.aerospike.fraud.demo.txn.model.events;

public class TxnEvent extends Event {
	


}
