package com.aerospike.fraud.demo.txn.model;

import java.util.List;

import com.aerospike.fraud.demo.txn.model.Merchant.MerchantType;

public class FraudFactsModel {
	public static class TimeSpendingHabits {
		private SpendingHabits hourHabits;
		private SpendingHabits dayHabits;
		private SpendingHabits weekHabits;
		private SpendingHabits monthHabits;
		private SpendingHabits yearHabits;

		public TimeSpendingHabits(SpendingHabits hourHabits, SpendingHabits dayHabits, SpendingHabits weekHabits,
				SpendingHabits monthHabits, SpendingHabits yearHabits) {
			super();
			this.hourHabits = hourHabits;
			this.dayHabits = dayHabits;
			this.weekHabits = weekHabits;
			this.monthHabits = monthHabits;
			this.yearHabits = yearHabits;
		}

		public SpendingHabits getHourHabits() {
			return hourHabits;
		}

		public SpendingHabits getDayHabits() {
			return dayHabits;
		}

		public SpendingHabits getWeekHabits() {
			return weekHabits;
		}

		public SpendingHabits getMonthHabits() {
			return monthHabits;
		}

		public SpendingHabits getYearHabits() {
			return yearHabits;
		}
	}

	private ClientHydratedTransaction transaction;
	private Customer customer;
	private Account account;
	private CreditCard card;
	private volatile Merchant merchant;
	private volatile MerchantType merchantType;
	private volatile List<HistoryEntry> terminalHistory;	
	private volatile TimeSpendingHabits customerSpendingHabits;
	private volatile TimeSpendingHabits customerSpendingHabitsByTerminal;
	private volatile TimeSpendingHabits customerSpendingHabitsByMerchant;
	private volatile AcctNumAndCode acctNumAndCode;
	private volatile Terminal terminal;
	private volatile Location location;
	private volatile Store store;
	
	public ClientHydratedTransaction getTransaction() {
		return transaction;
	}
	public void setTransaction(ClientHydratedTransaction transaction) {
		this.transaction = transaction;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public CreditCard getCard() {
		return card;
	}
	public void setCard(CreditCard card) {
		this.card = card;
	}
	public Merchant getMerchant() {
		return merchant;
	}
	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}
	public MerchantType getMerchantType() {
		return merchantType;
	}
	public void setMerchantType(MerchantType merchantType) {
		this.merchantType = merchantType;
	}
	public List<HistoryEntry> getTerminalHistory() {
		return terminalHistory;
	}
	public void setTerminalHistory(List<HistoryEntry> terminalHistory) {
		this.terminalHistory = terminalHistory;
	}
	public TimeSpendingHabits getCustomerSpendingHabits() {
		return customerSpendingHabits;
	}
	public void setCustomerSpendingHabits(TimeSpendingHabits customerSpendingHabits) {
		this.customerSpendingHabits = customerSpendingHabits;
	}
	public TimeSpendingHabits getCustomerSpendingHabitsByMerchant() {
		return customerSpendingHabitsByMerchant;
	}
	public void setCustomerSpendingHabitsByMerchant(TimeSpendingHabits customerSpendingHabitsByMerchant) {
		this.customerSpendingHabitsByMerchant = customerSpendingHabitsByMerchant;
	}
	public TimeSpendingHabits getCustomerSpendingHabitsByTerminal() {
		return customerSpendingHabitsByTerminal;
	}
	public void setCustomerSpendingHabitsByTerminal(TimeSpendingHabits customerSpendingHabitsByTerminal) {
		this.customerSpendingHabitsByTerminal = customerSpendingHabitsByTerminal;
	}
	public AcctNumAndCode getAcctNumAndCode() {
		return acctNumAndCode;
	}
	public void setAcctNumAndCode(AcctNumAndCode acctNumAndCode) {
		this.acctNumAndCode = acctNumAndCode;
	}
	public Terminal getTerminal() {
		return terminal;
	}
	public void setTerminal(Terminal terminal) {
		this.terminal = terminal;
	}
	public Location getLocation() {
		return location;
	}
	public void setLocation(Location location) {
		this.location = location;
	}
	public Store getStore() {
		return store;
	}
	public void setStore(Store store) {
		this.store = store;
	}
}
