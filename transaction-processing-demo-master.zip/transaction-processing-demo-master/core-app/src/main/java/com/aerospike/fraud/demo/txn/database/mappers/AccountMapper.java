package com.aerospike.fraud.demo.txn.database.mappers;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.aerospike.fraud.demo.txn.database.Column;
import com.aerospike.fraud.demo.txn.database.DataElement;
import com.aerospike.fraud.demo.txn.database.RecordData;
import com.aerospike.fraud.demo.txn.model.Account;

public class AccountMapper {
//	public String getColumnNameForField(String field) {
//		switch (field) {
//		case "number": return "number";
//		case "nameOnAccount"
//		}
//	}
	public Account fromRecord(RecordData record) {
		Account result = null;
		if (record != null) {
			result = new Account();
			result.setNumber(record.getString("number"));
			result.setNameOnAccount(record.getString("name"));
			result.setCustomerId(record.getString("custId"));
			result.setDateOpened(new Date(record.getLong("opened")));
			String[] paddingStrings = new String[10];
			for (int i = 0; i < 10; i++) {
				String s = record.getString("padding" + i);
				if (s != null) {
					paddingStrings[i] = s;
				}
				else {
					break;
				}
			}
			result.setPadding(paddingStrings);
		}
		return result;
	}
	
	public Column[] toRecord(Account account) {
		List<Column> elements = new ArrayList<Column>();
		elements.add(new Column("number", DataElement.get(account.getNumber())));
		elements.add(new Column("name", DataElement.get(account.getNameOnAccount())));
		elements.add(new Column("custId", DataElement.get(account.getCustomerId())));
		elements.add(new Column("opened", DataElement.get(account.getDateOpened().getTime())));
				
		for (int i = 0; i < account.getPadding().length; i++) {
			elements.add(new Column("padding" + i, DataElement.get(account.getPadding()[i])));
		}

		return elements.toArray(new Column[0]);
	}
}
