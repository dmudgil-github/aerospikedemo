package com.aerospike.fraud.demo.txn.database.mappers;

import java.util.ArrayList;
import java.util.List;

import com.aerospike.fraud.demo.txn.database.Column;
import com.aerospike.fraud.demo.txn.database.DataElement;
import com.aerospike.fraud.demo.txn.model.ClientHydratedTransaction;

public class TransactionMapper {
	public Column[] toRecord(ClientHydratedTransaction txn) {
		List<Column> elements = new ArrayList<Column>();
		elements.add(new Column("type", DataElement.get(txn.getRecordType())));
		elements.add(new Column("extTxnId", DataElement.get(txn.getExternalTransactionId())));
		elements.add(new Column("dataSpcVer", DataElement.get(txn.getDataSpecificationVersion())));
		elements.add(new Column("pan", DataElement.get(txn.getPan())));
		elements.add(new Column("custAcctNo", DataElement.get(txn.getCustomerAcctNumber())));
		elements.add(new Column("availBal", DataElement.get(txn.getAvailableBalance())));
		elements.add(new Column("availCashLmt", DataElement.get(txn.getAvailableDailyCashLimit())));
		elements.add(new Column("availMerchLmt", DataElement.get(txn.getAvailableDailyMerchandiseLimit())));
		elements.add(new Column("termId", DataElement.get(txn.getTerminalId())));
		elements.add(new Column("termVerf", DataElement.get(txn.getTerminalVerificationResults())));
		elements.add(new Column("cardVerf", DataElement.get(txn.getCardVerificationResults())));
		elements.add(new Column("acqId", DataElement.get(txn.getAcquirerId())));
		elements.add(new Column("acqBin", DataElement.get(txn.getAcquirerBin())));
		elements.add(new Column("acctExpDate", DataElement.get(txn.getAcctExpireDate())));
		elements.add(new Column("acqCountry", DataElement.get(txn.getAcquirerCountry())));
		elements.add(new Column("txnDate", DataElement.get(txn.getTransactionDate())));
		elements.add(new Column("txnTime", DataElement.get(txn.getTransactionTime())));
		elements.add(new Column("txnType", DataElement.get(txn.getTransactionType().toString())));
		elements.add(new Column("txnAmt", DataElement.get(txn.getTransactionAmount())));
		elements.add(new Column("txnCurCde", DataElement.get(txn.getTransactionCurrencyCode())));
		elements.add(new Column("txnCurCnvRte", DataElement.get(txn.getTransactionCurrencyConversionR())));
		elements.add(new Column("merchId", DataElement.get(txn.getMerchantId())));
		elements.add(new Column("merchCity", DataElement.get(txn.getMerchantCity())));
		elements.add(new Column("merchCountryCd", DataElement.get(txn.getMerchantCountryCode())));
		elements.add(new Column("merchName", DataElement.get(txn.getMerchantName())));
		elements.add(new Column("acctCode", DataElement.get(txn.getAccountCode())));
		elements.add(new Column("s_code", DataElement.get(txn.getS_code())));
		
		return elements.toArray(new Column[0]);
	}
	
	
}
