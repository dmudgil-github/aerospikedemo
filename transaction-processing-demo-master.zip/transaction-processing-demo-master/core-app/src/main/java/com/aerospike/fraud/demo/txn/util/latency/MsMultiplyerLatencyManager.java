package com.aerospike.fraud.demo.txn.util.latency;

import java.io.PrintStream;
import java.text.DecimalFormat;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicLongArray;

public class MsMultiplyerLatencyManager implements LatencyManager {
    private final AtomicInteger[] buckets;
    // We will have 2 window histograms to be able to swap them over almost atomically 
    private final AtomicLongArray[] windowHistogramSet;
    // This will be a reference to the ones we're increasing in this window.
    private volatile AtomicLongArray windowHistogram;
    private volatile int windowHistogramSetIndex = 0;
    private final int lastBucket;
    private final int multiplyer;
    private static final int COLUMN_WIDTH = 6;
    private final boolean showMicroSeconds;
    private static final long NS_TO_MS = 1000000;
    private static final long NS_TO_US = 1000;
    private String header;
    // ycsb variables
    private AtomicInteger _buckets;
    private AtomicLongArray histogram;
    private AtomicLong histogramoverflow;
    private AtomicInteger operations;
    private AtomicLong totallatency;
  //keep a windowed version of these stats for printing status
    private AtomicInteger windowoperations;
    private AtomicLong windowtotallatency;
    private AtomicLong min;
    private AtomicLong max;
    private AtomicLong windowMin;
    private AtomicLong windowMax;
    

    private class MicrosecondTimingInfo implements TimingInfo {
    	long startTime;
    	public MicrosecondTimingInfo() {
    		this.startTime = System.nanoTime();
		}
    	public long getStartTime() {
			return startTime;
		}
    }
    
    public MsMultiplyerLatencyManager(int columns, int bitShift, boolean showMicroSeconds) {
    	this.lastBucket = columns - 1;
    	this.multiplyer = bitShift;
    	this.showMicroSeconds = showMicroSeconds;
		buckets = new AtomicInteger[columns];
		// ycsb variables
		_buckets = new AtomicInteger(1000);
		histogram = new AtomicLongArray(_buckets.get());
        histogramoverflow = new AtomicLong(0);
		windowHistogramSet = new AtomicLongArray[2];
		windowHistogramSet[0] = new AtomicLongArray(_buckets.get());
		windowHistogramSet[1] = new AtomicLongArray(_buckets.get());
		windowHistogram = windowHistogramSet[windowHistogramSetIndex];
        operations = new AtomicInteger(0);
        totallatency = new AtomicLong(0);
        windowoperations = new AtomicInteger(0);
        windowtotallatency = new AtomicLong(0);
        min = new AtomicLong(-1);
        max = new AtomicLong(-1);
        windowMin = new AtomicLong(-1);
        windowMax = new AtomicLong(-1);
		
		for (int i = 0; i < columns; i++) {
			buckets[i] = new AtomicInteger();
		}
		formHeader();
    }
    
    private void formHeader() {
		int limit = 0;
		String units = showMicroSeconds ? "us" : "ms";
		StringBuilder s = new StringBuilder(64);
		s.append("\n       <=1").append(units).append(" >1").append(units);
		
		for (int i = 2; i < buckets.length; i++) {			
			limit += multiplyer;
			String str = " >" + limit + units;
			s.append(str);
			for (int j = str.length(); j < COLUMN_WIDTH; j++) {
				s.append(' ');
			}
		}
		String[] headings = new String[] {"  avg", "95th%", "99th%", "count"};
		for (String str : headings) {
			s.append(str);
			for (int j = str.length(); j < COLUMN_WIDTH; j++) {
				s.append(' ');
			}
		}
		header = s.toString();
    }
    
	public void add(long elapsed) {
		int index = getIndex(elapsed);
		buckets[index].incrementAndGet();
		
		/*
		 * ycsb calculations
		 */
		// Latency is specified in ns
		long latencyUs = elapsed / 1000;
		long latencyMs = latencyUs / 1000;
        if (latencyMs >= _buckets.get()) {
            histogramoverflow.incrementAndGet();
        } else {
        	int latency = (int)latencyMs;
            histogram.incrementAndGet(latency);
            windowHistogram.incrementAndGet(latency);
        }
        operations.incrementAndGet();
        totallatency.addAndGet(latencyUs);
        windowoperations.incrementAndGet();
        windowtotallatency.addAndGet(latencyUs);

        if ((min.get() < 0) || (latencyUs < min.get())) {
            min.set(latencyUs);
        }

        if ((max.get() < 0) || (latencyUs > max.get())) {
            max.set(latencyUs);
        }
        
        if ((windowMin.get() < 0) || (latencyUs < windowMin.get())) {
            windowMin.set(latencyUs);
        }

        if ((windowMax.get() < 0) || (latencyUs > windowMax.get())) {
            windowMax.set(latencyUs);
        }
        
	}

	private int getIndex(long elapsed) {
		long limit = 0L;
		if (showMicroSeconds) {
			elapsed /= NS_TO_US;
		}
		else {
			elapsed /= NS_TO_MS;
		}
		for (int i = 0; i < lastBucket; i++) {
			if (elapsed <= limit) {
				return i;
			}
			limit += multiplyer;
		}
		return lastBucket;
	}
	
	public void printHeader(PrintStream stream) {	
		stream.println(header);
	}
	
	public static class TimingResults {
		private final double avgWindow;
		private final int countWindow;
		private final double average;
		private final int count;
		private final double percent95;
		private final double percent99;
		private final double windowpercent95;
		private final double windowpercent99;
		private final double min;
		private final double max;
		private final double minWindow;
		private final double maxWindow;
		private final double[] timings;
		public TimingResults(double avgWindow, int countWindow, double average, int count, double percent95,
				double percent99, double windowpercent95, double windowpercent99, double min, double max, double minWindow, double maxWindow,
				double[] timings) {
			super();
			this.avgWindow = avgWindow;
			this.countWindow = countWindow;
			this.average = average;
			this.count = count;
			this.percent95 = percent95;
			this.percent99 = percent99;
			this.windowpercent95 = windowpercent95;
			this.windowpercent99 = windowpercent99;
			this.min = min;
			this.max = max;
			this.minWindow = minWindow;
			this.maxWindow = maxWindow;
			this.timings = timings;
		}
		public double getAvgWindow() {
			return avgWindow;
		}
		public int getCountWindow() {
			return countWindow;
		}
		public double getAverage() {
			return average;
		}
		public int getCount() {
			return count;
		}
		public double getPercent95() {
			return percent95;
		}
		public double getPercent99() {
			return percent99;
		}
		public double getMin() {
			return min;
		}
		public double getMax() {
			return max;
		}
		public double getMinWindow() {
			return minWindow;
		}
		public double getMaxWindow() {
			return maxWindow;
		}
		public double[] getTimings() {
			return timings;
		}
		
		public String toJson() {
			DecimalFormat df2 = new DecimalFormat("0.00");
			StringBuffer sb = new StringBuffer(1000);
	        sb.append("\"timings\":{\"0\":").append(df2.format(timings[0]));
	        for (int i = 1; i < timings.length; i++) {
	            if (timings[i] > 0) {
	            	sb.append(",\"").append(i).append("\":").append(df2.format(timings[i]));
	            }
	        }
			sb.append("}");
	        sb.append(",\"avgWindow\":").append(df2.format(avgWindow));
	        sb.append(",\"countWindow\":").append(countWindow);
	        sb.append(",\"average\":").append(df2.format(average));
	        sb.append(",\"count\":").append(count);
	        sb.append(",\"percent95th\":").append(df2.format(percent95));
	        sb.append(",\"percent99th\":").append(df2.format(percent99));
	        sb.append(",\"min\":").append(df2.format(min));
	        sb.append(",\"max\":").append(df2.format(max));
	        sb.append(",\"minWindow\":").append(df2.format(minWindow));
	        sb.append(",\"maxWindow\":").append(df2.format(maxWindow));
	        return sb.toString();
		}
		public static String getCsvHeading(int buckets) {
			StringBuffer sb = new StringBuffer(1000);
			sb.append("avgWindow,countWindow,average,count,percent95th,percent99th,min,max,minWindow,maxWindow,percent95thWindow,percent99thWindow");
			for (int i = 0; i < buckets; i++) {
				sb.append(",").append(i);
			}
			sb.append("\n");
			return sb.toString();
		}
		
		public String toCsv() {
			DecimalFormat df2 = new DecimalFormat("0.00");
			StringBuffer sb = new StringBuffer(1000);
	        sb.append(df2.format(avgWindow));
	        sb.append(",").append(countWindow);
	        sb.append(",").append(df2.format(average));
	        sb.append(",").append(count);
	        sb.append(",").append(df2.format(percent95));
	        sb.append(",").append(df2.format(percent99));
	        sb.append(",").append(df2.format(min));
	        sb.append(",").append(df2.format(max));
	        sb.append(",").append(df2.format(minWindow));
	        sb.append(",").append(df2.format(maxWindow));
	        sb.append(",").append(df2.format(windowpercent95));
	        sb.append(",").append(df2.format(windowpercent99));
	        for (int i = 0; i < timings.length; i++) {
	            if (timings[i] > 0) {
	            	sb.append(",").append(df2.format(timings[i]));
	            }
	        }
	        return sb.toString();
		}
	}
	
	public TimingResults getResults() {
		// Capture snapshot and make buckets cumulative.
		int[] array = new int[buckets.length];
		int sum = 0;
		int count;
		
		for (int i = buckets.length - 1; i >= 1 ; i--) {
			 count = buckets[i].getAndSet(0);
			 array[i] = count + sum;
			 sum += count;
		}
		// The first bucket (<=1ms) does not need a cumulative adjustment.
		count = buckets[0].getAndSet(0);
		array[0] = count;
		sum += count;
		
		double[] timings = new double[array.length];
        double sumDouble = (double)sum;
        // Prevent divide by 0 errors when there are no results
        if (sumDouble == 0) {
        	sumDouble = 1;
        }
        int ninetyFifthWindow = 0;
        int ninetyNinthWindow = 0;
        boolean done95th = false;
        boolean done99th = false;
        
        timings[0] =  (double)array[0] * 100.0 / sumDouble;
        for (int i = 0; i < array.length; i++) {
            timings[i] = (double)array[i] * 100.0 / sumDouble;
            if (i > 0 && !done95th && timings[i] < 5) {
            	ninetyFifthWindow = i;
            	done95th = true;
            }
            if (i > 0 && !done99th && timings[i] < 1) {
            	ninetyNinthWindow = i;
            	done99th = true;
            }
        }
        if (!done95th) {
        	ninetyFifthWindow = array.length + 1;
        }
        if (!done99th) {
        	ninetyNinthWindow = array.length + 1;
        }
        done95th = false;
        done99th = false;

		/*
		 * ycsb print results
		 */
        double ops = (double)operations.get();
        if (ops == 0) {
        	ops = 1;
        }
        double windowOps = (double)windowoperations.get();
        if (windowOps == 0) {
        	windowOps = 1;
        }
		double avgLatency = ((double) totallatency.get()) / ops;
		double windowAvgLatency = ((double) windowtotallatency.get()) / windowOps;

        int opcounter = 0;
        done95th = false;
        int ninetyFifth = 0;
        int ninetyNinth = 0;
        for (int i = 0; i < _buckets.get(); i++) {
            opcounter += histogram.get(i);
            double percentage = ((double) opcounter) / ops;
            if ((!done95th) && percentage >= 0.95) {
            	ninetyFifth = i;
                done95th = true;
            }
            if (percentage >= 0.99) {
            	ninetyNinth = i;
                break;
            }
        }
        
        // Now compute the window 95th and 99th percentile.
//        AtomicLongArray theseResults = windowHistogram;
//        windowHistogramSetIndex = (windowHistogramSetIndex + 1) % 2;
//        int highestBucket = (int)((windowMax.get() + 999)/1000);
//        int ninetyFifthWindow = 0;
//        int ninetyNinthWindow = 0;
//        done95th = false;
//        boolean done99th = false;
//        opcounter = 0;
//        for (int i = 0; i < _buckets.get(); i++) {
//            opcounter += theseResults.getAndSet(i, 0);
//            double percentage = ((double) opcounter) / windowOps;
//            if ((!done95th) && percentage >= 0.95) {
//            	ninetyFifthWindow = i;
//                done95th = true;
//            }
//            if ((!done99th) && percentage >= 0.99) {
//            	ninetyNinthWindow = i;
//            	done99th = true;
//            }
//            if (i > highestBucket) {
//            	break;
//            }
//        }
//        System.out.println("95% = " + ninetyFifthWindow + ", 99% = " + ninetyNinthWindow);
 
        TimingResults results = new TimingResults(windowAvgLatency/1000, windowoperations.get(),
        		avgLatency/1000, operations.get(), ninetyFifth, ninetyNinth, ninetyFifthWindow, ninetyNinthWindow, min.get()/1000, 
        		max.get()/1000, windowMin.get()/1000, windowMax.get()/1000, timings);
        windowoperations.set(0);
        windowtotallatency.set(0);
        windowMin.set(-1);
        windowMax.set(-1);
        
        return results;
	}
	/**
	 * Print latency percents for specified cumulative ranges.
	 * This function is not absolutely accurate for a given time slice because this method 
	 * is not synchronized with the add() method.  Some values will slip into the next iteration.  
	 * It is not a good idea to add extra locks just to measure performance since that actually 
	 * affects performance.  Fortunately, the values will even out over time
	 * (ie. no double counting).
	 */
	public void printResults(PrintStream stream, String prefix) {
		//TimingResults results = getResults();
		// Capture snapshot and make buckets cumulative.
		int[] array = new int[buckets.length];
		int sum = 0;
		int count;
		
		for (int i = buckets.length - 1; i >= 1 ; i--) {
			 count = buckets[i].getAndSet(0);
			 array[i] = count + sum;
			 sum += count;
		}
		// The first bucket (<=1ms) does not need a cumulative adjustment.
		count = buckets[0].getAndSet(0);
		array[0] = count;
		sum += count;
		
		// Print cumulative results.
		stream.print(prefix);
//		stream.print(' ' );
//		stream.print(sum);
        int spaces = 6 - prefix.length();

        for (int j = 0; j < spaces; j++) {
        	stream.print(' ');
        }

        double sumDouble = (double)sum;
        int limit = 0;

        printColumn(stream, limit-1, sumDouble, array[0]);
        printColumn(stream, limit-1, sumDouble, array[1]);

        for (int i = 2; i < array.length; i++) {
            limit += multiplyer;
            printColumn(stream, limit, sumDouble, array[i]);
        }
		
		/*
		 * ycsb print results
		 */
		StringBuilder buffer = new StringBuilder(1024);
		double avgLatency = (((double) totallatency.get()) / ((double) operations.get()));
		double windowAvgLatency = (((double) windowtotallatency.get()) / ((double) windowoperations.get()));

        int opcounter = 0;
        boolean done95th = false;
        int ninetyFifth = 0;
        int ninetyNinth = 0;
        for (int i = 0; i < _buckets.get(); i++) {
            opcounter += histogram.get(i);
            double percentage = ((double) opcounter) / ((double) operations.get());
            if ((!done95th) && percentage >= 0.95) {
            	ninetyFifth = i;
                done95th = true;
            }
            if (percentage >= 0.99) {
            	ninetyNinth = i;
                break;
            }
        }
        printColumn(stream, limit, (int)((long)windowAvgLatency/1000), "ms");
        limit += multiplyer;
        printColumn(stream, limit, ninetyFifth, "ms");
        limit += multiplyer;
        printColumn(stream, limit, ninetyNinth, "ms");
        limit += multiplyer;
        printColumn(stream, limit, windowoperations.get());
        limit += multiplyer;

        stream.println();
        windowoperations.set(0);
        windowtotallatency.set(0);
		
	}
	
    private void printColumn(PrintStream stream, int limit, double sum, int value) {
        long percent = 0;

        if (value > 0) {
            percent = Math.round((double)value * 100.0 / sum);
        }
        String percentString = Long.toString(percent) + "%";      
        int spaces = Integer.toString(limit).length() + 4 - percentString.length();

        for (int j = 0; j < spaces; j++) {
        	stream.print(' ');
        }
        stream.print(percentString);
    }

    private void printColumn(PrintStream stream, int limit, int value) {
        String data = Integer.toString(value);      
        int spaces = Integer.toString(limit).length() + 4 - data.length();

        for (int j = 0; j < spaces; j++) {
        	stream.print(' ');
        }
        stream.print(data);
    }

    private void printColumn(PrintStream stream, int limit, int value, String suffix) {
        String data = Integer.toString(value) + suffix;      
        int spaces = Integer.toString(limit).length() + 4 - data.length();

        for (int j = 0; j < spaces; j++) {
        	stream.print(' ');
        }
        stream.print(data);
    }

	@Override
	public TimingInfo beginMeasure() {
		return new MicrosecondTimingInfo();
	}

	@Override
	public void endMeasure(TimingInfo info) {
		long diff = System.nanoTime() - ((MicrosecondTimingInfo)info).getStartTime();
		this.add(diff);
	}

}
