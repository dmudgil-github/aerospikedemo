package com.aerospike.fraud.demo.txn.core.rulesengine;

import com.aerospike.fraud.demo.txn.core.orchestrator.TxnFraudOrchestrator.FraudResult;
import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.model.ClientHydratedTransaction;
import com.aerospike.fraud.demo.txn.model.FraudFactsModel;

public class RulesEngineStub implements RulesEngine {

	private static final int PROCESSING_TIME_MS = 5;
	public int processData(Database database, String keySpace, ClientHydratedTransaction transaction, FraudFactsModel components, FraudResult fraudResult) {
		if (fraudResult == FraudResult.BLACK_LISTED) {
			return FAILURE_SCORE;
		}
		else if (fraudResult == FraudResult.WHITE_LISTED) {
			return SUCCESS_SCORE;
		}
		try {
			Thread.sleep(PROCESSING_TIME_MS);
		} catch (InterruptedException e) {
		}
		return FAILURE_SCORE + ((SUCCESS_SCORE - FAILURE_SCORE) * 3 / 4);
	}

}
