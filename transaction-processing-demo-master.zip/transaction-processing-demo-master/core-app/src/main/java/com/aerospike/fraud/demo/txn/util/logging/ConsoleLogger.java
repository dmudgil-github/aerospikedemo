package com.aerospike.fraud.demo.txn.util.logging;

public class ConsoleLogger extends Logger {
	private static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(ConsoleLogger.class);
	
	@Override
	public void log(String value) {
		log.info(value);
	}

}
