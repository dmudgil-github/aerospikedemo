package com.aerospike.fraud.demo.txn.model;

public class ClientHydratedTransaction extends RawTransaction {
	public enum TransactionType {
		REFUND("R"),
		CREDIT("C");
		
		private String type;
		private TransactionType(String type) {
			this.type = type;
		}
		public String getType() {
			return type;
		}
	}
	
	private String recordType;
	private String dataSpecificationVersion;
	private String clientIdFromHeader;
	private String recordCreationDate;
	private String recordCreationTime;
	private String recordCreationMilliseconds;
	private String gmtOffset;
	private String customerIdFromHeader;
	private String customerAcctNumber;
	private String externalTransactionId;
	private String pan;
	private String authPostFlag;
	private String cardPostalCode;
	private String cardCountryCode;
	private String openDate;
	private String plasticIssueDate;
	private String plasticIssueType;
	private String acctExpireDate;
	private String cardExpireDate;
	private String dailyMerchandiseLimit;
	private String dailyCashLimit;
	private String customerGender;
	private String customerDateOfBirth;
	private String numberOfCards;
	private String incomeOrCashBack;
	private String cardType;
	private String cardUse;
	private String transactionDate;
	private String transactionTime;
	private String transactionAmount;
	private String transactionCurrencyCode;
	private String transactionCurrencyConversionR;
	private String authDecisionCode;
	private TransactionType transactionType;
	private String mcc;
	private String merchantPostalCode;
	private String merchantCountryCode;
	private String pinVerifyCode;
	private String cvvVerifyCode;
	private String posEntryMode;
	private String postDate;
	private String authPostMiscIndicator;
	private String mismatchIndicator;
	private String caseCreationIndicator;
	private String userIndicator01;
	private String userIndicator02;
	private String userData01;
	private String userData02;
	private String onUsMerchantId;
	private String merchantDataProvided;
	private String cardholderDataProvided;
	private String externalScore1;
	private String externalScore2;
	private String externalScore3;
	private String customerPresent;
	private String atmOwner;
	private String randomDigits;
	private String portfolio;
	private String clientId;
	private String acquirerBin;
	private String merchantName;
	private String merchantCity;
	private String merchantState;
	private String caseSuppressionIndicator;
	private String userIndicator03;
	private String userIndicator04;
	private String userData03;
	private String userData04;
	private String userData05;
	private String realtimeRequest;
	private String padResponse;
	private String padActionExpireDate;
	private String cardMasterAcctNumber;
	private String cardAipStatic;
	private String cardAipDynamic;
	private String cardAipVerify;
	private String cardAipRisk;
	private String cardAipIssuerAuthentication;
	private String cardAipCombined;
	private String cardDailyLimitCode;
	private String availableBalance;
	private String availableDailyCashLimit;
	private String availableDailyMerchandiseLimit;
	private String atmHostMcc;
	private String atmProcessingCode;
	private String atmCameraPresent;
	private String cardPinType;
	private String cardMediaType;
	private String cvv2Present;
	private String cvv2Response;
	private String avsResponse;
	private String transactionCategory;
	private String acquirerId;
	private String acquirerCountry;
	private String terminalId;
	private String terminalType;
	private String terminalEntryCapability;
	private String posConditionCode;
	private String networkId;
	private String authExpireDateVerify;
	private String authSecondaryVerify;
	private String authBeneficiary;
	private String authResponseCode;
	private String authReversalReason;
	private String authCardIssuer;
	private String terminalVerificationResults;
	private String cardVerificationResults;
	private String cryptogramValid;
	private String atcCard;
	private String atcHost;
	private String offlineLowerLimit;
	private String offlineUpperLimit;
	private String recurringAuthFrequency;
	private String recurringAuthExpireDate;
	private String linkedAcctType;
	private String cardIncentive;
	private String cardPinLength;
	private String cardPinSetDate;
	private String processorAuthReasonCode;
	private String standinAdvice;
	private String merchantId;
	private String cardOrder;
	private String cashbackAmount;
	private String userData06;
	private String userData07;
	private String paymentInstrumentId;
	private String avsRequest;
	private String cvrOfflinePinVerificationPerfo;
	private String cvrOfflinePinVerificationFaile;
	private String cvrPinTryLimitExceeded;
	private String posUnattended;
	private String posOffPremises;
	private String posCardCapture;
	private String posSecurity;
	private String authId;
	private String userData08;
	private String userData09;
	private String userIndicator05;
	private String userIndicator06;
	private String userIndicator07;
	private String userIndicator08;
	private String modelControl1;
	private String modelControl2;
	private String modelControl3;
	private String modelControl4;
	private String segmentId1;
	private String segmentId2;
	private String segmentId3;
	private String segmentId4;
	
	// 2 fields to do internal code lookup in conjunction with the Merchant Name
	private String accountCode;
	private String s_code;
	
	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public String getDataSpecificationVersion() {
		return dataSpecificationVersion;
	}

	public void setDataSpecificationVersion(String dataSpecificationVersion) {
		this.dataSpecificationVersion = dataSpecificationVersion;
	}

	public String getClientIdFromHeader() {
		return clientIdFromHeader;
	}

	public void setClientIdFromHeader(String clientIdFromHeader) {
		this.clientIdFromHeader = clientIdFromHeader;
	}

	public String getRecordCreationDate() {
		return recordCreationDate;
	}

	public void setRecordCreationDate(String recordCreationDate) {
		this.recordCreationDate = recordCreationDate;
	}

	public String getRecordCreationTime() {
		return recordCreationTime;
	}

	public void setRecordCreationTime(String recordCreationTime) {
		this.recordCreationTime = recordCreationTime;
	}

	public String getRecordCreationMilliseconds() {
		return recordCreationMilliseconds;
	}

	public void setRecordCreationMilliseconds(String recordCreationMilliseconds) {
		this.recordCreationMilliseconds = recordCreationMilliseconds;
	}

	public String getGmtOffset() {
		return gmtOffset;
	}

	public void setGmtOffset(String gmtOffset) {
		this.gmtOffset = gmtOffset;
	}

	public String getCustomerIdFromHeader() {
		return customerIdFromHeader;
	}

	public void setCustomerIdFromHeader(String customerIdFromHeader) {
		this.customerIdFromHeader = customerIdFromHeader;
	}

	public String getCustomerAcctNumber() {
		return customerAcctNumber;
	}

	public void setCustomerAcctNumber(String customerAcctNumber) {
		this.customerAcctNumber = customerAcctNumber;
	}

	public String getExternalTransactionId() {
		return externalTransactionId;
	}

	public void setExternalTransactionId(String externalTransactionId) {
		this.externalTransactionId = externalTransactionId;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getAuthPostFlag() {
		return authPostFlag;
	}

	public void setAuthPostFlag(String authPostFlag) {
		this.authPostFlag = authPostFlag;
	}

	public String getCardPostalCode() {
		return cardPostalCode;
	}

	public void setCardPostalCode(String cardPostalCode) {
		this.cardPostalCode = cardPostalCode;
	}

	public String getCardCountryCode() {
		return cardCountryCode;
	}

	public void setCardCountryCode(String cardCountryCode) {
		this.cardCountryCode = cardCountryCode;
	}

	public String getOpenDate() {
		return openDate;
	}

	public void setOpenDate(String openDate) {
		this.openDate = openDate;
	}

	public String getPlasticIssueDate() {
		return plasticIssueDate;
	}

	public void setPlasticIssueDate(String plasticIssueDate) {
		this.plasticIssueDate = plasticIssueDate;
	}

	public String getPlasticIssueType() {
		return plasticIssueType;
	}

	public void setPlasticIssueType(String plasticIssueType) {
		this.plasticIssueType = plasticIssueType;
	}

	public String getAcctExpireDate() {
		return acctExpireDate;
	}

	public void setAcctExpireDate(String acctExpireDate) {
		this.acctExpireDate = acctExpireDate;
	}

	public String getCardExpireDate() {
		return cardExpireDate;
	}

	public void setCardExpireDate(String cardExpireDate) {
		this.cardExpireDate = cardExpireDate;
	}

	public String getDailyMerchandiseLimit() {
		return dailyMerchandiseLimit;
	}

	public void setDailyMerchandiseLimit(String dailyMerchandiseLimit) {
		this.dailyMerchandiseLimit = dailyMerchandiseLimit;
	}

	public String getDailyCashLimit() {
		return dailyCashLimit;
	}

	public void setDailyCashLimit(String dailyCashLimit) {
		this.dailyCashLimit = dailyCashLimit;
	}

	public String getCustomerGender() {
		return customerGender;
	}

	public void setCustomerGender(String customerGender) {
		this.customerGender = customerGender;
	}

	public String getCustomerDateOfBirth() {
		return customerDateOfBirth;
	}

	public void setCustomerDateOfBirth(String customerDateOfBirth) {
		this.customerDateOfBirth = customerDateOfBirth;
	}

	public String getNumberOfCards() {
		return numberOfCards;
	}

	public void setNumberOfCards(String numberOfCards) {
		this.numberOfCards = numberOfCards;
	}

	public String getIncomeOrCashBack() {
		return incomeOrCashBack;
	}

	public void setIncomeOrCashBack(String incomeOrCashBack) {
		this.incomeOrCashBack = incomeOrCashBack;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public String getCardUse() {
		return cardUse;
	}

	public void setCardUse(String cardUse) {
		this.cardUse = cardUse;
	}

	public String getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getTransactionTime() {
		return transactionTime;
	}

	public void setTransactionTime(String transactionTime) {
		this.transactionTime = transactionTime;
	}

	public String getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(String transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public String getTransactionCurrencyCode() {
		return transactionCurrencyCode;
	}

	public void setTransactionCurrencyCode(String transactionCurrencyCode) {
		this.transactionCurrencyCode = transactionCurrencyCode;
	}

	public String getTransactionCurrencyConversionR() {
		return transactionCurrencyConversionR;
	}

	public void setTransactionCurrencyConversionR(String transactionCurrencyConversionR) {
		this.transactionCurrencyConversionR = transactionCurrencyConversionR;
	}

	public String getAuthDecisionCode() {
		return authDecisionCode;
	}

	public void setAuthDecisionCode(String authDecisionCode) {
		this.authDecisionCode = authDecisionCode;
	}

	public TransactionType getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(TransactionType transactionType) {
		this.transactionType = transactionType;
	}

	public String getMcc() {
		return mcc;
	}

	public void setMcc(String mcc) {
		this.mcc = mcc;
	}

	public String getMerchantPostalCode() {
		return merchantPostalCode;
	}

	public void setMerchantPostalCode(String merchantPostalCode) {
		this.merchantPostalCode = merchantPostalCode;
	}

	public String getMerchantCountryCode() {
		return merchantCountryCode;
	}

	public void setMerchantCountryCode(String merchantCountryCode) {
		this.merchantCountryCode = merchantCountryCode;
	}

	public String getPinVerifyCode() {
		return pinVerifyCode;
	}

	public void setPinVerifyCode(String pinVerifyCode) {
		this.pinVerifyCode = pinVerifyCode;
	}

	public String getCvvVerifyCode() {
		return cvvVerifyCode;
	}

	public void setCvvVerifyCode(String cvvVerifyCode) {
		this.cvvVerifyCode = cvvVerifyCode;
	}

	public String getPosEntryMode() {
		return posEntryMode;
	}

	public void setPosEntryMode(String posEntryMode) {
		this.posEntryMode = posEntryMode;
	}

	public String getPostDate() {
		return postDate;
	}

	public void setPostDate(String postDate) {
		this.postDate = postDate;
	}

	public String getAuthPostMiscIndicator() {
		return authPostMiscIndicator;
	}

	public void setAuthPostMiscIndicator(String authPostMiscIndicator) {
		this.authPostMiscIndicator = authPostMiscIndicator;
	}

	public String getMismatchIndicator() {
		return mismatchIndicator;
	}

	public void setMismatchIndicator(String mismatchIndicator) {
		this.mismatchIndicator = mismatchIndicator;
	}

	public String getCaseCreationIndicator() {
		return caseCreationIndicator;
	}

	public void setCaseCreationIndicator(String caseCreationIndicator) {
		this.caseCreationIndicator = caseCreationIndicator;
	}

	public String getUserIndicator01() {
		return userIndicator01;
	}

	public void setUserIndicator01(String userIndicator01) {
		this.userIndicator01 = userIndicator01;
	}

	public String getUserIndicator02() {
		return userIndicator02;
	}

	public void setUserIndicator02(String userIndicator02) {
		this.userIndicator02 = userIndicator02;
	}

	public String getUserData01() {
		return userData01;
	}

	public void setUserData01(String userData01) {
		this.userData01 = userData01;
	}

	public String getUserData02() {
		return userData02;
	}

	public void setUserData02(String userData02) {
		this.userData02 = userData02;
	}

	public String getOnUsMerchantId() {
		return onUsMerchantId;
	}

	public void setOnUsMerchantId(String onUsMerchantId) {
		this.onUsMerchantId = onUsMerchantId;
	}

	public String getMerchantDataProvided() {
		return merchantDataProvided;
	}

	public void setMerchantDataProvided(String merchantDataProvided) {
		this.merchantDataProvided = merchantDataProvided;
	}

	public String getCardholderDataProvided() {
		return cardholderDataProvided;
	}

	public void setCardholderDataProvided(String cardholderDataProvided) {
		this.cardholderDataProvided = cardholderDataProvided;
	}

	public String getExternalScore1() {
		return externalScore1;
	}

	public void setExternalScore1(String externalScore1) {
		this.externalScore1 = externalScore1;
	}

	public String getExternalScore2() {
		return externalScore2;
	}

	public void setExternalScore2(String externalScore2) {
		this.externalScore2 = externalScore2;
	}

	public String getExternalScore3() {
		return externalScore3;
	}

	public void setExternalScore3(String externalScore3) {
		this.externalScore3 = externalScore3;
	}

	public String getCustomerPresent() {
		return customerPresent;
	}

	public void setCustomerPresent(String customerPresent) {
		this.customerPresent = customerPresent;
	}

	public String getAtmOwner() {
		return atmOwner;
	}

	public void setAtmOwner(String atmOwner) {
		this.atmOwner = atmOwner;
	}

	public String getRandomDigits() {
		return randomDigits;
	}

	public void setRandomDigits(String randomDigits) {
		this.randomDigits = randomDigits;
	}

	public String getPortfolio() {
		return portfolio;
	}

	public void setPortfolio(String portfolio) {
		this.portfolio = portfolio;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getAcquirerBin() {
		return acquirerBin;
	}

	public void setAcquirerBin(String acquirerBin) {
		this.acquirerBin = acquirerBin;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public String getMerchantCity() {
		return merchantCity;
	}

	public void setMerchantCity(String merchantCity) {
		this.merchantCity = merchantCity;
	}

	public String getMerchantState() {
		return merchantState;
	}

	public void setMerchantState(String merchantState) {
		this.merchantState = merchantState;
	}

	public String getCaseSuppressionIndicator() {
		return caseSuppressionIndicator;
	}

	public void setCaseSuppressionIndicator(String caseSuppressionIndicator) {
		this.caseSuppressionIndicator = caseSuppressionIndicator;
	}

	public String getUserIndicator03() {
		return userIndicator03;
	}

	public void setUserIndicator03(String userIndicator03) {
		this.userIndicator03 = userIndicator03;
	}

	public String getUserIndicator04() {
		return userIndicator04;
	}

	public void setUserIndicator04(String userIndicator04) {
		this.userIndicator04 = userIndicator04;
	}

	public String getUserData03() {
		return userData03;
	}

	public void setUserData03(String userData03) {
		this.userData03 = userData03;
	}

	public String getUserData04() {
		return userData04;
	}

	public void setUserData04(String userData04) {
		this.userData04 = userData04;
	}

	public String getUserData05() {
		return userData05;
	}

	public void setUserData05(String userData05) {
		this.userData05 = userData05;
	}

	public String getRealtimeRequest() {
		return realtimeRequest;
	}

	public void setRealtimeRequest(String realtimeRequest) {
		this.realtimeRequest = realtimeRequest;
	}

	public String getPadResponse() {
		return padResponse;
	}

	public void setPadResponse(String padResponse) {
		this.padResponse = padResponse;
	}

	public String getPadActionExpireDate() {
		return padActionExpireDate;
	}

	public void setPadActionExpireDate(String padActionExpireDate) {
		this.padActionExpireDate = padActionExpireDate;
	}

	public String getCardMasterAcctNumber() {
		return cardMasterAcctNumber;
	}

	public void setCardMasterAcctNumber(String cardMasterAcctNumber) {
		this.cardMasterAcctNumber = cardMasterAcctNumber;
	}

	public String getCardAipStatic() {
		return cardAipStatic;
	}

	public void setCardAipStatic(String cardAipStatic) {
		this.cardAipStatic = cardAipStatic;
	}

	public String getCardAipDynamic() {
		return cardAipDynamic;
	}

	public void setCardAipDynamic(String cardAipDynamic) {
		this.cardAipDynamic = cardAipDynamic;
	}

	public String getCardAipVerify() {
		return cardAipVerify;
	}

	public void setCardAipVerify(String cardAipVerify) {
		this.cardAipVerify = cardAipVerify;
	}

	public String getCardAipRisk() {
		return cardAipRisk;
	}

	public void setCardAipRisk(String cardAipRisk) {
		this.cardAipRisk = cardAipRisk;
	}

	public String getCardAipIssuerAuthentication() {
		return cardAipIssuerAuthentication;
	}

	public void setCardAipIssuerAuthentication(String cardAipIssuerAuthentication) {
		this.cardAipIssuerAuthentication = cardAipIssuerAuthentication;
	}

	public String getCardAipCombined() {
		return cardAipCombined;
	}

	public void setCardAipCombined(String cardAipCombined) {
		this.cardAipCombined = cardAipCombined;
	}

	public String getCardDailyLimitCode() {
		return cardDailyLimitCode;
	}

	public void setCardDailyLimitCode(String cardDailyLimitCode) {
		this.cardDailyLimitCode = cardDailyLimitCode;
	}

	public String getAvailableBalance() {
		return availableBalance;
	}

	public void setAvailableBalance(String availableBalance) {
		this.availableBalance = availableBalance;
	}

	public String getAvailableDailyCashLimit() {
		return availableDailyCashLimit;
	}

	public void setAvailableDailyCashLimit(String availableDailyCashLimit) {
		this.availableDailyCashLimit = availableDailyCashLimit;
	}

	public String getAvailableDailyMerchandiseLimit() {
		return availableDailyMerchandiseLimit;
	}

	public void setAvailableDailyMerchandiseLimit(String availableDailyMerchandiseLimit) {
		this.availableDailyMerchandiseLimit = availableDailyMerchandiseLimit;
	}

	public String getAtmHostMcc() {
		return atmHostMcc;
	}

	public void setAtmHostMcc(String atmHostMcc) {
		this.atmHostMcc = atmHostMcc;
	}

	public String getAtmProcessingCode() {
		return atmProcessingCode;
	}

	public void setAtmProcessingCode(String atmProcessingCode) {
		this.atmProcessingCode = atmProcessingCode;
	}

	public String getAtmCameraPresent() {
		return atmCameraPresent;
	}

	public void setAtmCameraPresent(String atmCameraPresent) {
		this.atmCameraPresent = atmCameraPresent;
	}

	public String getCardPinType() {
		return cardPinType;
	}

	public void setCardPinType(String cardPinType) {
		this.cardPinType = cardPinType;
	}

	public String getCardMediaType() {
		return cardMediaType;
	}

	public void setCardMediaType(String cardMediaType) {
		this.cardMediaType = cardMediaType;
	}

	public String getCvv2Present() {
		return cvv2Present;
	}

	public void setCvv2Present(String cvv2Present) {
		this.cvv2Present = cvv2Present;
	}

	public String getCvv2Response() {
		return cvv2Response;
	}

	public void setCvv2Response(String cvv2Response) {
		this.cvv2Response = cvv2Response;
	}

	public String getAvsResponse() {
		return avsResponse;
	}

	public void setAvsResponse(String avsResponse) {
		this.avsResponse = avsResponse;
	}

	public String getTransactionCategory() {
		return transactionCategory;
	}

	public void setTransactionCategory(String transactionCategory) {
		this.transactionCategory = transactionCategory;
	}

	public String getAcquirerId() {
		return acquirerId;
	}

	public void setAcquirerId(String acquirerId) {
		this.acquirerId = acquirerId;
	}

	public String getAcquirerCountry() {
		return acquirerCountry;
	}

	public void setAcquirerCountry(String acquirerCountry) {
		this.acquirerCountry = acquirerCountry;
	}

	public String getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	public String getTerminalType() {
		return terminalType;
	}

	public void setTerminalType(String terminalType) {
		this.terminalType = terminalType;
	}

	public String getTerminalEntryCapability() {
		return terminalEntryCapability;
	}

	public void setTerminalEntryCapability(String terminalEntryCapability) {
		this.terminalEntryCapability = terminalEntryCapability;
	}

	public String getPosConditionCode() {
		return posConditionCode;
	}

	public void setPosConditionCode(String posConditionCode) {
		this.posConditionCode = posConditionCode;
	}

	public String getNetworkId() {
		return networkId;
	}

	public void setNetworkId(String networkId) {
		this.networkId = networkId;
	}

	public String getAuthExpireDateVerify() {
		return authExpireDateVerify;
	}

	public void setAuthExpireDateVerify(String authExpireDateVerify) {
		this.authExpireDateVerify = authExpireDateVerify;
	}

	public String getAuthSecondaryVerify() {
		return authSecondaryVerify;
	}

	public void setAuthSecondaryVerify(String authSecondaryVerify) {
		this.authSecondaryVerify = authSecondaryVerify;
	}

	public String getAuthBeneficiary() {
		return authBeneficiary;
	}

	public void setAuthBeneficiary(String authBeneficiary) {
		this.authBeneficiary = authBeneficiary;
	}

	public String getAuthResponseCode() {
		return authResponseCode;
	}

	public void setAuthResponseCode(String authResponseCode) {
		this.authResponseCode = authResponseCode;
	}

	public String getAuthReversalReason() {
		return authReversalReason;
	}

	public void setAuthReversalReason(String authReversalReason) {
		this.authReversalReason = authReversalReason;
	}

	public String getAuthCardIssuer() {
		return authCardIssuer;
	}

	public void setAuthCardIssuer(String authCardIssuer) {
		this.authCardIssuer = authCardIssuer;
	}

	public String getTerminalVerificationResults() {
		return terminalVerificationResults;
	}

	public void setTerminalVerificationResults(String terminalVerificationResults) {
		this.terminalVerificationResults = terminalVerificationResults;
	}

	public String getCardVerificationResults() {
		return cardVerificationResults;
	}

	public void setCardVerificationResults(String cardVerificationResults) {
		this.cardVerificationResults = cardVerificationResults;
	}

	public String getCryptogramValid() {
		return cryptogramValid;
	}

	public void setCryptogramValid(String cryptogramValid) {
		this.cryptogramValid = cryptogramValid;
	}

	public String getAtcCard() {
		return atcCard;
	}

	public void setAtcCard(String atcCard) {
		this.atcCard = atcCard;
	}

	public String getAtcHost() {
		return atcHost;
	}

	public void setAtcHost(String atcHost) {
		this.atcHost = atcHost;
	}

	public String getOfflineLowerLimit() {
		return offlineLowerLimit;
	}

	public void setOfflineLowerLimit(String offlineLowerLimit) {
		this.offlineLowerLimit = offlineLowerLimit;
	}

	public String getOfflineUpperLimit() {
		return offlineUpperLimit;
	}

	public void setOfflineUpperLimit(String offlineUpperLimit) {
		this.offlineUpperLimit = offlineUpperLimit;
	}

	public String getRecurringAuthFrequency() {
		return recurringAuthFrequency;
	}

	public void setRecurringAuthFrequency(String recurringAuthFrequency) {
		this.recurringAuthFrequency = recurringAuthFrequency;
	}

	public String getRecurringAuthExpireDate() {
		return recurringAuthExpireDate;
	}

	public void setRecurringAuthExpireDate(String recurringAuthExpireDate) {
		this.recurringAuthExpireDate = recurringAuthExpireDate;
	}

	public String getLinkedAcctType() {
		return linkedAcctType;
	}

	public void setLinkedAcctType(String linkedAcctType) {
		this.linkedAcctType = linkedAcctType;
	}

	public String getCardIncentive() {
		return cardIncentive;
	}

	public void setCardIncentive(String cardIncentive) {
		this.cardIncentive = cardIncentive;
	}

	public String getCardPinLength() {
		return cardPinLength;
	}

	public void setCardPinLength(String cardPinLength) {
		this.cardPinLength = cardPinLength;
	}

	public String getCardPinSetDate() {
		return cardPinSetDate;
	}

	public void setCardPinSetDate(String cardPinSetDate) {
		this.cardPinSetDate = cardPinSetDate;
	}

	public String getProcessorAuthReasonCode() {
		return processorAuthReasonCode;
	}

	public void setProcessorAuthReasonCode(String processorAuthReasonCode) {
		this.processorAuthReasonCode = processorAuthReasonCode;
	}

	public String getStandinAdvice() {
		return standinAdvice;
	}

	public void setStandinAdvice(String standinAdvice) {
		this.standinAdvice = standinAdvice;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getCardOrder() {
		return cardOrder;
	}

	public void setCardOrder(String cardOrder) {
		this.cardOrder = cardOrder;
	}

	public String getCashbackAmount() {
		return cashbackAmount;
	}

	public void setCashbackAmount(String cashbackAmount) {
		this.cashbackAmount = cashbackAmount;
	}

	public String getUserData06() {
		return userData06;
	}

	public void setUserData06(String userData06) {
		this.userData06 = userData06;
	}

	public String getUserData07() {
		return userData07;
	}

	public void setUserData07(String userData07) {
		this.userData07 = userData07;
	}

	public String getPaymentInstrumentId() {
		return paymentInstrumentId;
	}

	public void setPaymentInstrumentId(String paymentInstrumentId) {
		this.paymentInstrumentId = paymentInstrumentId;
	}

	public String getAvsRequest() {
		return avsRequest;
	}

	public void setAvsRequest(String avsRequest) {
		this.avsRequest = avsRequest;
	}

	public String getCvrOfflinePinVerificationPerfo() {
		return cvrOfflinePinVerificationPerfo;
	}

	public void setCvrOfflinePinVerificationPerfo(String cvrOfflinePinVerificationPerfo) {
		this.cvrOfflinePinVerificationPerfo = cvrOfflinePinVerificationPerfo;
	}

	public String getCvrOfflinePinVerificationFaile() {
		return cvrOfflinePinVerificationFaile;
	}

	public void setCvrOfflinePinVerificationFaile(String cvrOfflinePinVerificationFaile) {
		this.cvrOfflinePinVerificationFaile = cvrOfflinePinVerificationFaile;
	}

	public String getCvrPinTryLimitExceeded() {
		return cvrPinTryLimitExceeded;
	}

	public void setCvrPinTryLimitExceeded(String cvrPinTryLimitExceeded) {
		this.cvrPinTryLimitExceeded = cvrPinTryLimitExceeded;
	}

	public String getPosUnattended() {
		return posUnattended;
	}

	public void setPosUnattended(String posUnattended) {
		this.posUnattended = posUnattended;
	}

	public String getPosOffPremises() {
		return posOffPremises;
	}

	public void setPosOffPremises(String posOffPremises) {
		this.posOffPremises = posOffPremises;
	}

	public String getPosCardCapture() {
		return posCardCapture;
	}

	public void setPosCardCapture(String posCardCapture) {
		this.posCardCapture = posCardCapture;
	}

	public String getPosSecurity() {
		return posSecurity;
	}

	public void setPosSecurity(String posSecurity) {
		this.posSecurity = posSecurity;
	}

	public String getAuthId() {
		return authId;
	}

	public void setAuthId(String authId) {
		this.authId = authId;
	}

	public String getUserData08() {
		return userData08;
	}

	public void setUserData08(String userData08) {
		this.userData08 = userData08;
	}

	public String getUserData09() {
		return userData09;
	}

	public void setUserData09(String userData09) {
		this.userData09 = userData09;
	}

	public String getUserIndicator05() {
		return userIndicator05;
	}

	public void setUserIndicator05(String userIndicator05) {
		this.userIndicator05 = userIndicator05;
	}

	public String getUserIndicator06() {
		return userIndicator06;
	}

	public void setUserIndicator06(String userIndicator06) {
		this.userIndicator06 = userIndicator06;
	}

	public String getUserIndicator07() {
		return userIndicator07;
	}

	public void setUserIndicator07(String userIndicator07) {
		this.userIndicator07 = userIndicator07;
	}

	public String getUserIndicator08() {
		return userIndicator08;
	}

	public void setUserIndicator08(String userIndicator08) {
		this.userIndicator08 = userIndicator08;
	}

	public String getModelControl1() {
		return modelControl1;
	}

	public void setModelControl1(String modelControl1) {
		this.modelControl1 = modelControl1;
	}

	public String getModelControl2() {
		return modelControl2;
	}

	public void setModelControl2(String modelControl2) {
		this.modelControl2 = modelControl2;
	}

	public String getModelControl3() {
		return modelControl3;
	}

	public void setModelControl3(String modelControl3) {
		this.modelControl3 = modelControl3;
	}

	public String getModelControl4() {
		return modelControl4;
	}

	public void setModelControl4(String modelControl4) {
		this.modelControl4 = modelControl4;
	}

	public String getSegmentId1() {
		return segmentId1;
	}

	public void setSegmentId1(String segmentId1) {
		this.segmentId1 = segmentId1;
	}

	public String getSegmentId2() {
		return segmentId2;
	}

	public void setSegmentId2(String segmentId2) {
		this.segmentId2 = segmentId2;
	}

	public String getSegmentId3() {
		return segmentId3;
	}

	public void setSegmentId3(String segmentId3) {
		this.segmentId3 = segmentId3;
	}

	public String getSegmentId4() {
		return segmentId4;
	}

	public void setSegmentId4(String segmentId4) {
		this.segmentId4 = segmentId4;
	}
	
	public String getAccountCode() {
		return accountCode;
	}
	
	public void setAccountCode(String accountCode) {
		this.accountCode = accountCode;
	}
	
	public String getS_code() {
		return s_code;
	}
	
	public void setS_code(String s_code) {
		this.s_code = s_code;
	}
}
