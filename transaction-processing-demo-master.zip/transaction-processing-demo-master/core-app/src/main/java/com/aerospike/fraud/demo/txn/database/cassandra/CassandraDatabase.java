package com.aerospike.fraud.demo.txn.database.cassandra;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.aerospike.client.Key;
import com.aerospike.fraud.demo.txn.database.Column;
import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.database.DatabaseKey;
import com.aerospike.fraud.demo.txn.database.PreparedDatabaseStatement;
import com.aerospike.fraud.demo.txn.database.RecordData;
import com.aerospike.fraud.demo.txn.database.WriteOptions;
import com.aerospike.fraud.demo.txn.util.latency.LatencyManager;
import com.aerospike.fraud.demo.txn.util.latency.LatencyManager.TimingInfo;
import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.ResultSetFuture;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.exceptions.AlreadyExistsException;

public class CassandraDatabase implements Database {
	private Cluster cluster;
	private Session session;
	private long idValueRead = -1L;
	private long currentId = -1L;
	private static final long ID_COUNTS_TO_ALLOCATE = 10000;
	private LatencyManager readLatencyManager;
	private LatencyManager writeLatencyManager;
	private LatencyManager batchLatencyManager;
	private Map<String, String> tableIds;
	private Map<String, PreparedStatement> preparedStatementCache = new HashMap<String, PreparedStatement>(100);

	public CassandraDatabase(String host, LatencyManager readLatencyManager, LatencyManager writeLatencyManager, LatencyManager batchLatencyManager, Map<String, String> tableIds) {
		cluster = Cluster.builder()                                              
				.addContactPoint(host)
				.build();
		session = cluster.connect();
		this.readLatencyManager = readLatencyManager;
		this.writeLatencyManager = writeLatencyManager;
		this.batchLatencyManager = batchLatencyManager;
		this.tableIds = tableIds;
	}

	@Override
	public void runDdlCommand(String command) {
		System.out.println(command);
		try {
			session.execute(command);
		}
		catch (AlreadyExistsException e) {
			System.out.println("Table already exists, skipping");
		}
	}
	
	@Override
	public void dropTable(String keySpace, String table) {
		try {
		session.execute("drop table " + keySpace + "." + table);
		}
		catch (Exception e) {
			System.out.println("Info: Tried to drop a non-existent table: " + table);
		}
	}

	@Override
	public void put(WriteOptions options, DatabaseKey key, Column ... columns) {
		// TODO: implement TTL
		// TODO: Implement prepared statements
		StringBuilder builder = new StringBuilder(300);
		StringBuilder values = new StringBuilder(100);
		

		builder.append("insert into ").append(key.getKeyspace()).append(".").append(key.getTable()).append("(");
		values.append(" values (");

	
		
		for (int i = 0; i < columns.length; i++) {
			builder.append(columns[i].getName());
			values.append(columns[i].getData().toFormattedString());
			if (i < columns.length-1) {
				builder.append(',');
				values.append(',');
			}
			else {
				builder.append(')');
				values.append(')');
			}
		}
		builder.append(values.toString());
		TimingInfo info = writeLatencyManager.beginMeasure();
		session.execute(builder.toString());
		writeLatencyManager.endMeasure(info);
	}


	@Override
	public RecordData get(DatabaseKey key) {
		return get(key, (String [])null);
	}
	
	@Override
	public RecordData get(DatabaseKey key, String ... columns) {
		String colString = "*";
		if (columns != null && columns.length > 0) {
			StringBuilder builder = new StringBuilder(10*columns.length);
			for (int i = 0; i < columns.length; i++) {
				builder.append(columns[i]);
				if (i < (columns.length - 1)) {
					builder.append(',');
				}
			}
			colString = builder.toString();
		}
		String idName = tableIds.get(key.getTable());
		if (idName == null) {
			idName = "id";
		}
		String cql = String.format("select %s from %s.%s where %s = '%s'", colString, key.getKeyspace(), key.getTable(), idName, key.getId());
		TimingInfo info = readLatencyManager.beginMeasure();
		Row row = session.execute(cql).one();
		readLatencyManager.endMeasure(info);
		return row == null ? null : new CassandraRecord(row); 
	}
	
	public Session getSession() {
		return session;
	}
	
	@Override
	public RecordData get(DatabaseKey key, PreparedDatabaseStatement stmt) {
		TimingInfo info = readLatencyManager.beginMeasure();
		RecordData record = stmt.get(key);
		readLatencyManager.endMeasure(info);
		return record;
	}
	

	@Override
	public void close() {
		if (session != null) {
			session.close();
		}
		if (cluster != null) {
			cluster.close(); 
		}
	}

	@Override
	public PreparedDatabaseStatement prepare(String statement) {
		PreparedStatement ps = session.prepare(statement);
		return new CassandraPreparedStatement(this, ps, this.readLatencyManager);
	}

	@Override
	public void log(String keySpace, String table, String log) {
		long id = getUinqueID();
		long time = new Date().getTime();
		
		PreparedStatement statement = session.prepare("insert into " + keySpace + "." + table + "(id, date, message) values (?, ?, ?)");
		TimingInfo info = writeLatencyManager.beginMeasure();
		session.execute(statement.bind(id, time, log));
		writeLatencyManager.endMeasure(info);
	}

	private synchronized long getUinqueID() {
		if (currentId < 0){
			currentId = 1;
		}
		else {
			currentId++;
		}
		return currentId;
	}

	@Override
	public void addIdToList(DatabaseKey key, String column, String id, String counter) {
		// TODO Auto-generated method stub
	}

	@Override
	public void incrementMany(DatabaseKey key, String binName, Column... columns) {
		// TODO Auto-generated method stub
	}

	@Override
	public void incrementMany(DatabaseKey key, Column... columns) {
		// TODO Auto-generated method stub
	}

	@Override
	public RecordData[] get(DatabaseKey[] key) {
		return get(key, (String [])null);
	}
	
	@Override
	public RecordData[] get(DatabaseKey[] keys, String ... columns) {
		if (keys.length == 0) {
			return null;
		}
		RecordData[] results = new RecordData[keys.length];
		DatabaseKey key = keys[0];
		String colString = "*";
		if (columns != null && columns.length > 0) {
			StringBuilder builder = new StringBuilder(10*columns.length);
			for (int i = 0; i < columns.length; i++) {
				builder.append(columns[i]);
				if (i < (columns.length - 1)) {
					builder.append(',');
				}
			}
			colString = builder.toString();
		}
		String idName = tableIds.get(key.getTable());
		if (idName == null) {
			idName = "id";
		}
		TimingInfo info = batchLatencyManager.beginMeasure();
		String cql = String.format("select %s from %s.%s where %s = ?", colString, key.getKeyspace(), key.getTable(), idName);
		PreparedStatement statement = session.prepare(cql);
		List<ResultSetFuture> futures = new ArrayList<>();
		for (int i = 0; i < keys.length; i++) {
			ResultSetFuture resultSetFuture = session.executeAsync(statement.bind(keys[i].getId()));
			futures.add(resultSetFuture);
		}
		for (int i = 0; i < keys.length; i++) {
			Row row = futures.get(i).getUninterruptibly().one();
			results[i] = new CassandraRecord(row);
		}
		batchLatencyManager.endMeasure(info);
		return results;
	}

}
