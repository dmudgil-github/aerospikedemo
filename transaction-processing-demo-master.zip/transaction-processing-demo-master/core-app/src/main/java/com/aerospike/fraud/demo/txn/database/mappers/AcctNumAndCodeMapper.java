package com.aerospike.fraud.demo.txn.database.mappers;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.aerospike.fraud.demo.txn.database.Column;
import com.aerospike.fraud.demo.txn.database.DataElement;
import com.aerospike.fraud.demo.txn.database.RecordData;
import com.aerospike.fraud.demo.txn.model.AcctNumAndCode;

/**
 * This class performs mapping from database records to Merchants and back.
 * This could be done with a lot less code using annotations and introspection, but
 * this has a runtime performance penalty and this is key in this use case.
 * @author Tim
 *
 */
public class AcctNumAndCodeMapper {
	public AcctNumAndCode fromRecord(RecordData record) {
		AcctNumAndCode result = null;
		if (record != null) {
			SimpleDateFormat sdfDate = new SimpleDateFormat("yyyyMMdd");
			result = new AcctNumAndCode();
			result.setAcctNum(record.getString("acctNum"));
			result.setS_code(record.getString("s_code"));
			result.setMerchantName(record.getString("merchName"));
			result.setTxnCount(record.getLong("txnCount"));
			result.setId(record.getString("id"));
			try {
				result.setLastTransactionDate(sdfDate.parse(record.getString("txnDate")));
			} catch (ParseException e) {
				result.setLastTransactionDate(null);
			}
		}
		return result;
	}
	
	public Column[] toRecord(AcctNumAndCode acctNumAndCode) {
		List<Column> elements = new ArrayList<Column>();
		elements.add(new Column("id", DataElement.get(acctNumAndCode.getId())));
		elements.add(new Column("acctNum", DataElement.get(acctNumAndCode.getAcctNum())));
		elements.add(new Column("s_code", DataElement.get(acctNumAndCode.getS_code())));
		elements.add(new Column("merchName", DataElement.get(acctNumAndCode.getMerchantName())));
		elements.add(new Column("txnCount", DataElement.get(acctNumAndCode.getTxnCount())));
		SimpleDateFormat sdfDate = new SimpleDateFormat("yyyyMMdd");
		elements.add(new Column("txnDate", DataElement.get(sdfDate.format(acctNumAndCode.getLastTransactionDate()))));
		return elements.toArray(new Column[0]);
	}

}
