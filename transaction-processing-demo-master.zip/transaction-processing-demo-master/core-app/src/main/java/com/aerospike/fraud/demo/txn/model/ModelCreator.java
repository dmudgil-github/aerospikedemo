package com.aerospike.fraud.demo.txn.model;

import com.aerospike.fraud.demo.txn.database.RecordData;

public interface ModelCreator<T> {
	T createFromRecord(RecordData data);
}
