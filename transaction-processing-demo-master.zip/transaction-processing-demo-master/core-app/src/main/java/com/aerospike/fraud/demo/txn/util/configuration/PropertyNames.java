package com.aerospike.fraud.demo.txn.util.configuration;

import com.aerospike.fraud.demo.txn.util.configuration.PropertiesManager.NameWithDefault;

public class PropertyNames {
	public static final NameWithDefault BLACKLIST_KNOWN_CNT = new NameWithDefault("blacklist.known.count","0");
	public static final NameWithDefault BLACKLIST_TOTAL_CNT = new NameWithDefault("blacklist.total.count","0");
	public static final NameWithDefault WHITELIST_KNOWN_CNT = new NameWithDefault("whitelist.known.count","0");
	public static final NameWithDefault WHITELIST_TOTAL_CNT = new NameWithDefault("whitelist.total.count","0");
	public static final NameWithDefault REFUNDS_PCT = new NameWithDefault("refunds.percentage", "5%");
	public static final NameWithDefault CUSTOMER_CNT = new NameWithDefault("customers.count", "1000");
	public static final NameWithDefault CUSTOMER_VIP_PCT = new NameWithDefault("customers.vip.percentage", "5%");
	public static final NameWithDefault SPEND_HABITS_MAX_TXNS = new NameWithDefault("spendinghabits.transactions.max", "1000");
	public static final NameWithDefault SPEND_HABITS_TTL = new NameWithDefault("spendinghabits.history.ttl", "3y");
	public static final NameWithDefault MERCHANTS_CNT = new NameWithDefault("merchants.count", "250");
	public static final NameWithDefault ACCOUNTS_CNT = new NameWithDefault("accounts.count", "2000");
	public static final NameWithDefault CARDS_CNT = new NameWithDefault("cards.count", "2500");
	public static final NameWithDefault LOCATIONS_CNT = new NameWithDefault("locations.count", "50");
	public static final NameWithDefault STORES_CNT = new NameWithDefault("stores.count", "80");
	public static final NameWithDefault TERMINALS_CNT = new NameWithDefault("terminals.count", "40");
	public static final NameWithDefault TERMINALS_FRAUD_PCT = new NameWithDefault("terminals.fraud.percentage", "0.5%");
	public static final NameWithDefault TERMINAL_HISTORY_ENTRY_CNT = new NameWithDefault("terminals.history.per.terminal", "10");
	public static final NameWithDefault TERMIANALS_REFUND_PCT = new NameWithDefault("terminals.refund.percentage", "1.5%");
	public static final NameWithDefault EXISTING_TXNS_CNT = new NameWithDefault("transactions.existing.count", "10000");
	public static final NameWithDefault S_CODES_KNOWN_CNT = new NameWithDefault("s_codes.known.count", "10000");
	public static final NameWithDefault S_CODES_TOTAL_CNT = new NameWithDefault("s_codes.total.count", "15000");
	public static final NameWithDefault NODE_CNT = new NameWithDefault("node.count", "1");
}
