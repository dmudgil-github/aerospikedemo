package com.aerospike.fraud.demo.txn.client;

public class Control {
	private OperationMode mode = OperationMode.FULL;
	
	// Singleton instance
	private Control() {}
	private static Control instance = new Control();
	public static Control getInstance() {
		return instance;
	}
	
	public OperationMode getMode() {
		return mode;
	}
	public void setMode(OperationMode mode) {
		this.mode = mode;
	}
}