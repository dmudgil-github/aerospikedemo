package com.aerospike.fraud.demo.txn.util.seed;

import java.util.Locale;
import java.util.Random;

import org.apache.log4j.Logger;

import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.database.DatabaseKey;
import com.aerospike.fraud.demo.txn.database.mappers.CountryMapper;
import com.aerospike.fraud.demo.txn.model.Country;

public class CountrySeeder extends Seeder {
	private static final Logger logger = Logger.getLogger(CountrySeeder.class);
	private final String keySpace;
	private final Database database;
	
	public CountrySeeder(Database database, String keySpace) {
		super("Countries");
		this.database = database;
		this.keySpace = keySpace;
	}
	
	/**
	 * Generate the data
	 * @param r - not used in this case, can be null
	 */
	protected int doSeed(Random r, long unused, long unused2) {
		String[] locales = Locale.getISOCountries();
		CountryMapper mapper = new CountryMapper();
		int count = 0;
		for (String countryCode : locales) {
			Locale obj = new Locale("", countryCode);
			Country c = new Country(countryCode, obj.getDisplayCountry(), obj.getDisplayLanguage());
			try {
				database.put(null, new DatabaseKey(keySpace, "countries", countryCode), mapper.toRecord(c));
				count++;
			}
			catch (Exception e) {
//				logger.error("Error creating country " + c +": "+e.getMessage(), e);
			}
		}
		return count;
	}

	@Override
	public String getIdForLogicalId(long id) {
		String[] locales = Locale.getISOCountries();
		if (id >= 0 && id < locales.length) {
			return locales[(int)id];
		}
		return null;
	}
}
