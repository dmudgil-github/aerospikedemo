package com.aerospike.fraud.demo.txn.util.seed;

import java.util.Random;

import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.database.DatabaseKey;
import com.aerospike.fraud.demo.txn.database.mappers.MerchantMapper;
import com.aerospike.fraud.demo.txn.model.Merchant;
import com.aerospike.fraud.demo.txn.model.Merchant.MerchantType;
import com.aerospike.fraud.demo.txn.util.seed.SeederUtils.Alphabet;

public class MerchantSeeder extends Seeder implements IdMapper<Merchant> {
	private final Database database;
	private final String keySpace;
	private MerchantMapper mapper = new MerchantMapper();
	private static final SeederUtils utils = new SeederUtils();
	
	private final String [] COUNTRIES = {
			"GB",
			"US",
			"GE", // Georgia
			"PY", //Paraguay
			"PA"  // Panama			
	};
	
	public MerchantSeeder(Database database, String keySpace) {
		super("Merchants");
		this.database = database;
		this.keySpace = keySpace;
	}
	
	private Merchant generateMerchant(Random r, long id) {
		int i;
		
		Merchant merchant = new Merchant();
		i = utils.distribute(r, 80,17,1,1,1);
		merchant.setCountry(COUNTRIES[i]);
		merchant.setId(getIdForLogicalId(id));
		merchant.setName(utils.getCompanyName(r));
		merchant.setPostalCode(utils.getString(r, 6, Alphabet.ALPHA_NUM_UPPER));
		switch (utils.distribute(r, 85, 12, 1, 1, 1)) {
		case 0: merchant.setMerchantType(MerchantType.RETAIL); break;
		case 1: merchant.setMerchantType(MerchantType.INTERNET); break;
		case 2: merchant.setMerchantType(MerchantType.MOBILE); break;
		case 3: merchant.setMerchantType(MerchantType.MAIL_ORDER); break;
		case 4: merchant.setMerchantType(MerchantType.WHOLESALE); break;
		}
		return merchant;
	}
	
	public String getIdForLogicalId(long id) {
		return utils.formatNumber(id, 10, 8, 1000000);
	}
	
	@Override
	protected int doSeed(Random r, long startId, long endId) {
		int count = 0;
		for (long i = startId; i < endId; i++) {
			Merchant merchant = generateMerchant(r, i);
			DatabaseKey key = new DatabaseKey(keySpace, "merchants", merchant.getId());
			this.database.put(null, key, mapper.toRecord(merchant));
			count++;
		}
		return count;
	}
}
