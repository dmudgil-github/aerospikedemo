package com.aerospike.fraud.demo.txn.database.cassandra;

import java.util.List;
import java.util.Map;

import com.aerospike.fraud.demo.txn.database.Column;
import com.aerospike.fraud.demo.txn.database.DataElement;
import com.aerospike.fraud.demo.txn.database.DatabaseKey;
import com.aerospike.fraud.demo.txn.database.PreparedDatabaseStatement;
import com.aerospike.fraud.demo.txn.database.RecordData;
import com.aerospike.fraud.demo.txn.util.latency.LatencyManager;
import com.aerospike.fraud.demo.txn.util.latency.LatencyManager.TimingInfo;
import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.Row;

public class CassandraPreparedStatement implements PreparedDatabaseStatement{
	private final PreparedStatement stmt;
	private final CassandraDatabase db;
	private final LatencyManager readLatencyManager;
	
	public CassandraPreparedStatement(CassandraDatabase db, PreparedStatement stmt, LatencyManager readLatencyManager) {
		this.stmt = stmt;
		this.db = db;
		this.readLatencyManager = readLatencyManager;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void bind(BoundStatement bs, String columnName, DataElement data) {
		Object o = data.getObject();
		if (o == null) {
			bs.setToNull(columnName);
		}
		else if (o instanceof String) {
			bs.setString(columnName, (String)o);
		}
		else if (o instanceof Integer) {
			bs.setInt(columnName, (Integer)o);
		}
		else if (o instanceof Double) {
			bs.setDouble(columnName, (Double)o);
		}
		else if (o instanceof Float) {
			bs.setFloat(columnName, (Integer)o);
		}
		else if (o instanceof List) {
			bs.setList(columnName, (List)o);
		}
		else if (o instanceof Map) {
			bs.setMap(columnName, (Map)o);
		}
		else {
			throw new IllegalArgumentException("Column '" + columnName + "' has unsupported type: " + o.getClass().getName());
		}
	}
	
	public BoundStatement bind(DatabaseKey key, Column... columns) {
		BoundStatement bs = this.stmt.bind();
		if (columns != null) {
			for (Column thisColumn : columns) {
				DataElement data = thisColumn.getData();
				bind(bs, thisColumn.getName(), data);
			}
			return bs;
		}
		else {
			return this.stmt.bind().setString(0, key.getId());
		}
	}

	@Override
	public RecordData get(DatabaseKey key) {
		TimingInfo time = readLatencyManager.beginMeasure();
		BoundStatement bs = this.bind(key, null);
		Row row = db.getSession().execute(bs).one();
		readLatencyManager.endMeasure(time);
		return row == null ? null : new CassandraRecord(row); 

	}
}
