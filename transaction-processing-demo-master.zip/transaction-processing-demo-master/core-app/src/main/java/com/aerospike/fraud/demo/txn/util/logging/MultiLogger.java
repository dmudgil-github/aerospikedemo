package com.aerospike.fraud.demo.txn.util.logging;

public class MultiLogger extends Logger {

	private Logger[] loggers;

	public MultiLogger(Logger ... loggers) {
		this.loggers = loggers;
	}
	
	@Override
	public void log(String value) {
		for (Logger logger : loggers) {
			logger.log(value);
		}
	}
}
