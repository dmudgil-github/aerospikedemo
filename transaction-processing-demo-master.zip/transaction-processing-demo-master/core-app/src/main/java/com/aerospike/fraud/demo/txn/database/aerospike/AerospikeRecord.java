package com.aerospike.fraud.demo.txn.database.aerospike;

import java.util.List;

import com.aerospike.client.Record;
import com.aerospike.fraud.demo.txn.database.RecordData;

/**
 * The Aerospike implementation of a Record
 * @author Tim
 *
 */
class AerospikeRecord implements RecordData {
	Record record;
	public AerospikeRecord(Record record) {
		this.record = record;
	}
	
	@Override
	public Object get(String columnName) {
		return record == null ? null : record.getValue(columnName);
	}

	@Override
	public String getString(String columnName) {
		return record == null ? null : record.getString(columnName);
	}

	@Override
	public int getInt(String columnName) {
		return record == null ? 0 : record.getInt(columnName);
	}

	@Override
	public long getLong(String columnName) {
		return record == null ? 0 : record.getLong(columnName);
	}
	
	@Override
	public double getDouble(String columnName) {
		return record == null ? 0 : record.getDouble(columnName);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public <T> List<T> getList(String columnName, Class<T> clazz) {
		return record == null ? null : (List<T>)record.getList(columnName);
	}
}
