package com.aerospike.fraud.demo.txn.core.machinelearning;

import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.model.ClientHydratedTransaction;
import com.aerospike.fraud.demo.txn.model.FraudFactsModel;

public interface MachineLearning {
	void processData(Database database, String keySpace, ClientHydratedTransaction transaction, FraudFactsModel components, int score);
}
