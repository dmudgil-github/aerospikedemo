package com.aerospike.fraud.demo.txn.eventpublisher.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import com.aerospike.fraud.demo.txn.client.Statistics;
import com.aerospike.fraud.demo.txn.client.Statistics.OperationStatistics;
import com.aerospike.fraud.demo.txn.client.TxnFraudClient;
import com.aerospike.fraud.demo.txn.database.Column;
import com.aerospike.fraud.demo.txn.database.DataElement;
import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.database.DatabaseKey;
import com.aerospike.fraud.demo.txn.database.mappers.SpendingHabitsMapper;
import com.aerospike.fraud.demo.txn.database.mappers.TransactionMapper;
import com.aerospike.fraud.demo.txn.database.refdata.ReferenceData;
import com.aerospike.fraud.demo.txn.eventpublisher.EventException;
import com.aerospike.fraud.demo.txn.eventpublisher.PostEventHandler;
import com.aerospike.fraud.demo.txn.model.ClientHydratedTransaction;
import com.aerospike.fraud.demo.txn.model.ClientHydratedTransaction.TransactionType;
import com.aerospike.fraud.demo.txn.model.FraudFactsModel;
import com.aerospike.fraud.demo.txn.model.LatencyStatsWrapper;
import com.aerospike.fraud.demo.txn.model.events.Event;
import com.aerospike.fraud.demo.txn.model.events.PostTxnEvent;
import com.aerospike.fraud.demo.txn.util.logging.Logger;

public class PostEventHandlerImplSocket extends PostEventHandler {

		public PostEventHandlerImplSocket(Event event) {
		
			super(event);
		}

		public void handleEvent() throws EventException {
			this.prepareSocketCall();
			this.sendPayload();
			boolean isError = this.validateResponse();
			if (isError) {
				throw new EventException("Error in handling event...");
			} 
				
		
		}
		

		private void prepareSocketCall() {
			
		}
		
		private boolean validateResponse() {
			
			return true;
		}
		
		
		private Object sendPayload() {
			
			return null;
		}
		


}