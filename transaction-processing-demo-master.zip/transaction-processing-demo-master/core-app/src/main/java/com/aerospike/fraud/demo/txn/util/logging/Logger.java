package com.aerospike.fraud.demo.txn.util.logging;

public abstract class Logger {
	public abstract void log(String value);
	public void log(String format, Object ... args) {
		this.log(String.format(format, args));
	}
	
}
