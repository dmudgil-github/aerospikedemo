package com.aerospike.fraud.demo.txn.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Customer {
	private String customerId;
	private String firstName;
	private String lastName;
	private String preferredSalutation;
	private String address;
	private String city;
	private String postCode;
	private Date joinedBank;
	private int numAccounts;
	// used to fill out the object to the appropriate size, eg 2k
	private String[] padding;
	private boolean vip;
	
	private List<Account> accounts = new ArrayList<>();
	
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPreferredSalutation() {
		return preferredSalutation;
	}
	public void setPreferredSalutation(String preferredSalutation) {
		this.preferredSalutation = preferredSalutation;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPostCode() {
		return postCode;
	}
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}
	public Date getJoinedBank() {
		return joinedBank;
	}
	public boolean isVip() {
		return vip;
	}
	public void setVip(boolean vip) {
		this.vip = vip;
	}
	public void setJoinedBank(Date joinedBank) {
		this.joinedBank = joinedBank;
	}
	public List<Account> getAccounts() {
		return accounts;
	}
	public void setAccounts(List<Account> accounts) {
		if (accounts == null) {
			throw new IllegalArgumentException("Accounts cannot be null");
		}
		this.accounts = accounts;
	}
	public int getNumAccounts() {
		return numAccounts;
	}
	public void setNumAccounts(int numAccounts) {
		this.numAccounts = numAccounts;
	}
	public String[] getPadding() {
		return padding;
	}
	public void setPadding(String[] padding) {
		this.padding = padding;
	}
}
