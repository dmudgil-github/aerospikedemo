package com.aerospike.fraud.demo.txn.client;

import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.eclipse.jetty.server.Request;
import org.eclipse.jetty.server.handler.AbstractHandler;

import com.aerospike.fraud.demo.txn.core.orchestrator.TxnFraudOrchestrator;

public class StatisticsHandler extends AbstractHandler{
	private final TxnFraudOrchestrator simulator;
	public StatisticsHandler(TxnFraudOrchestrator simulator) {
		this.simulator = simulator;
	}
	
	@Override
	public void handle(String target, Request baseRequest, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		
		if (baseRequest.getRequestURI().startsWith("/data/")) {
			Statistics statistics = Statistics.getInstance();
			response.setContentType("text/json;charset=utf-8");
			response.setStatus(HttpServletResponse.SC_OK);
			response.getWriter().print(statistics.getAllStats());
//			response.getWriter().print("transactions=" + statistics.getTransactions().count + ";");
//			response.getWriter().print("whiteListHits=" + statistics.getWhiteListCardHits() + ";");
//			response.getWriter().print("blackListHits=" + statistics.getBlackListCardHits() + ";");
//			response.getWriter().print("transactionsThisSecond=" + statistics.getTransactionsThisSecond().count + ";");
//			response.getWriter().print("acctNumAndCodeHits=" + statistics.getAcctNumAndSCodeHits() + ";");
			response.addHeader("Access-Control-Allow-Origin", "*");
			baseRequest.setHandled(true);
		}
		else if (baseRequest.getRequestURI().startsWith("/control")) {
			response.setStatus(HttpServletResponse.SC_OK);
			Map<String, String[]> params = request.getParameterMap();
			String mode = request.getParameter("mode");
			if (mode != null) {
				OperationMode newMode = OperationMode.valueOf(mode);
				OperationMode currentMode = Control.getInstance().getMode();
				if (currentMode != newMode) {
					Control.getInstance().setMode(newMode);
					System.out.println("setting mode to " + newMode);
				}
			}
			response.addHeader("Access-Control-Allow-Origin", "*");
			baseRequest.setHandled(true);
		}
	}
}
