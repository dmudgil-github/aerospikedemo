package com.aerospike.fraud.demo.txn.client;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.PosixParser;
import org.apache.log4j.Logger;
import org.eclipse.jetty.server.Handler;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.handler.HandlerList;
import org.eclipse.jetty.server.handler.ResourceHandler;

import com.aerospike.fraud.demo.txn.core.machinelearning.MachineLearning;
import com.aerospike.fraud.demo.txn.core.machinelearning.MachineLearningStub;
import com.aerospike.fraud.demo.txn.core.orchestrator.TxnFraudOrchestrator;
import com.aerospike.fraud.demo.txn.core.rulesengine.RulesEngine;
import com.aerospike.fraud.demo.txn.core.rulesengine.RulesEngineStub;
import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.database.DatabaseLogger;
import com.aerospike.fraud.demo.txn.database.aerospike.AerospikeDatabase;
import com.aerospike.fraud.demo.txn.database.cassandra.CassandraDatabase;
import com.aerospike.fraud.demo.txn.model.Account;
import com.aerospike.fraud.demo.txn.model.AcctNumAndCode;
import com.aerospike.fraud.demo.txn.model.CreditCard;
import com.aerospike.fraud.demo.txn.model.LatencyStatsWrapper;
import com.aerospike.fraud.demo.txn.model.Merchant;
import com.aerospike.fraud.demo.txn.model.Terminal;
import com.aerospike.fraud.demo.txn.util.configuration.PropertiesManager;
import com.aerospike.fraud.demo.txn.util.configuration.PropertyNames;
import com.aerospike.fraud.demo.txn.util.latency.LatencyManager;
import com.aerospike.fraud.demo.txn.util.latency.LatencyManagerYcsb;
import com.aerospike.fraud.demo.txn.util.latency.MicrosecondLatencyManager;
import com.aerospike.fraud.demo.txn.util.latency.MsMultiplyerLatencyManager;
import com.aerospike.fraud.demo.txn.util.latency.NullLatencyManager;
import com.aerospike.fraud.demo.txn.util.logging.ConsoleLogger;
import com.aerospike.fraud.demo.txn.util.logging.MultiLogger;
import com.aerospike.fraud.demo.txn.util.logging.NullLogger;
import com.aerospike.fraud.demo.txn.util.seed.AccountSeeder;
import com.aerospike.fraud.demo.txn.util.seed.AcctNumAndCodeSeeder;
import com.aerospike.fraud.demo.txn.util.seed.CreditCardSeeder;
import com.aerospike.fraud.demo.txn.util.seed.IdMapper;
import com.aerospike.fraud.demo.txn.util.seed.MerchantSeeder;
import com.aerospike.fraud.demo.txn.util.seed.ProgramDataSeeder;
import com.aerospike.fraud.demo.txn.util.seed.TerminalSeeder;

public class TxnFraudClient {
	private static Logger log = Logger.getLogger(TxnFraudClient.class);
	
	private static final int DEFAULT_THREADS = 16;
	private static  Database database = null;
	private static  int nThreads;
	private static  LatencyManager latencyManager = new NullLatencyManager();
	private static LatencyManager readLatencyManager = new NullLatencyManager();
	private static LatencyManager writeLatencyManager = new NullLatencyManager();
	private static LatencyManager batchLatencyManager = new NullLatencyManager();
	private static boolean multLatency = true;
//	private static LatencyStatsWrapper latencyStatsWrapper = null;
	private static Options options = null;
	private static PropertiesManager properties;
	private static int throughput = -1;
	private static String namespace;
	private static boolean reset;
	private static com.aerospike.fraud.demo.txn.util.logging.Logger logger;

	private static int jettyPort = 8080;
	
	public static void main(String[] args) {
		CommandLine cl = null;
		
		try {
			options = readProgrameConfig(args);
			cl = parsesOptions(args,options);
			configureNFRs(cl);
			configureLatencySetup(args,options,cl);
		
			configureProperties(cl);

			configureDatabase(args,options,cl);
			
			configureLogger(namespace, cl, database);
			
			configureStatisticDirectory(cl);
			configureOperationMode(cl);
			configureListeningPort(cl);
			
			/**
			 * If the program is to seed database just seed the database with historic data, else
			 * Fireup the Rules Engine, Machine Learning Engine, Statistics Server,  
			 * Initialise the program that will generate the txns at client's end to pass to transaction orchestrator
			 * and finally start the transactionOrchestrator 
			 * 
			 * 
			 */
			
	        if (cl.hasOption("seed")) {
	        	seedDatabase(cl);
	        } else {
	        	// Get Handle for Machine Learning
	        	MachineLearning mlEngineHandle = getMachineLearningHandle(cl);
	        	RulesEngine rulesEngineHandle = getRulesEngineHandle(cl);
	        	Loader loader = configureClientTxnLoader(cl);
				
				startFraudOrchestrator(loader, rulesEngineHandle,mlEngineHandle,nThreads);
	        }
			
			
		} catch (Exception e) {
			log.error("Critical error: " + e.getMessage(), e);
			System.exit(-1);
			
		} finally {
			log.info("Shutting down program");
			if (database != null) {
				database.close();
			}
		}
	}

	public static Options readProgrameConfig(String[] args) {
		options = new Options();
		
			log.info("Transaction Processor simulation program starting up");
			
			options.addOption("h", "host", true, "Server hostname (default: 127.0.0.1)");
			options.addOption("p", "listenPort", true, "Port to listen for informational requests on. Default 8080, set 0 to disable.");
			options.addOption("P", "properties", true, "Properties file name. Can be a file path or a properties file on the classpath");
			options.addOption("n", "namespace", true, "Namespace");
			options.addOption("S", "seed", true, "Seed (load) the data into the database. Must specifiy the node number.");
			options.addOption("i", "initial", true, "Initial seed value for transaction loader (defaut: 0)");
			options.addOption("R", "random", true, "Value to seed random generator with (default: 0)");
			options.addOption("d", "database", true, "database to use, aerospike or cassandra");
			options.addOption("u", "usage", false, "Print usage.");
			options.addOption("q", "query", false, "Aggregate with query.");
			options.addOption("r", "reset", true, "Reset the database to the default state, removing any existing data");
			options.addOption("l", "logging", true, "Logging option. Needs a parameter (c)onsole, (d)atabase, (b)oth, (n)one (default)");
			options.addOption("D", "directory", true, "Statistics directory for outputting statistics. If not set, current directory is assumed.");
			options.addOption("o", "operationalMode", true, "Operational mode: FULL (default), COMPATIBLE, READONLY.");
			options.addOption("g", "throughput", true, "maximum throughput rate for this node (default: unlimited)");
			options.addOption("T", "tables", true, "Tables to re-seed (and reset). Value is a comma seperated list of tables or \"all\"  (Default: all)");
			options.addOption("z", "threads", true, 
					"Set the number of threads the client will use to generate load. " + 
					"It is not recommended to use a value greater than 125."
					);	
			options.addOption("t", "latency", true, 
					"\"ycsb\"[,warmup count] or <number of latency columns>,<range shift increment>[,(ms|us)]\n" +
					"ycsb: show the timings in ycsb format\n" +
					"Show transaction latency percentages using elapsed time ranges.\n" +
					"<number of latency columns>,<range shift increment>[,(ms|us)]\n" +
					"Show transaction latency percentages using elapsed time ranges.\n" +
					"<number of latency columns>: Number of elapsed time ranges.\n" +
					"<range shift increment>: Power of 2 multiple between each range starting at column 3.\n"+
					"(ms|us): display times in milliseconds (ms, default) or microseconds (us)\n\n" + 
					"A latency definition of '-latency 7,1' results in this layout:\n" +
					"    <=1ms >1ms >2ms >4ms >8ms >16ms >32ms\n" +
					"       x%   x%   x%   x%   x%    x%    x%\n" +
					"A latency definition of '-latency 4,3' results in this layout:\n" +
					"    <=1ms >1ms >8ms >64ms\n" +
					"       x%   x%   x%    x%\n\n" +
					"Latency columns are cumulative. If a transaction takes 9ms, it will be included in both the >1ms and >8ms columns."
					);
			options.addOption("m", "multiple", false, "Related to latency, multiples of the range shift parameter instead of using powers of the increment.\n" +
					"Using the '-m' option in addition to '-latency 7,2' results in this layout:\n" +
					"    <=1ms >1ms >2ms >4ms >6ms >8ms >10ms\n" +
					"       x%   x%   x%   x%   x%   x%    x%\n\n" +
					"Default value is true, to disable use '-m false'\n");

			return options;
		}
			
		public static CommandLine parsesOptions(String[] args,Options options) {
			CommandLine cl = null;
			try {

				CommandLineParser parser = new PosixParser();
				cl = parser.parse(options, args, false);
				
			} catch(Exception e) {
				log.error("Critical error: " + e.getMessage(), e);
				System.exit(-1);
			}
			return cl;
		}
		
		public static void configureLatencySetup(String[] args, Options options, CommandLine cl) throws Exception{
			if (cl.hasOption("latency")) {
				String[] latencyOpts = cl.getOptionValue("latency", "ycsb,10").split(",");

				if (latencyOpts.length >= 1 && "ycsb".equalsIgnoreCase(latencyOpts[0])) {
					int warmupCount = 0;
					if (latencyOpts.length == 2) {
						warmupCount = Integer.parseInt(latencyOpts[1]);
					}

					latencyManager = new LatencyManagerYcsb(" txns", warmupCount);
					readLatencyManager = new LatencyManagerYcsb(" reads", warmupCount);
					writeLatencyManager = new LatencyManagerYcsb(" writes", warmupCount);
					batchLatencyManager = new LatencyManagerYcsb(" writes", warmupCount);
				}
				else if (latencyOpts.length != 2 && latencyOpts.length != 3) {
					throw new Exception("Latency expects either \"ycsb\" or 2 or 3 arguments. Received: " + latencyOpts.length);
				}
				else {

					int columns = Integer.parseInt(latencyOpts[0]);
					int bitShift = Integer.parseInt(latencyOpts[1]);
					boolean showMicroSeconds = false;
					if (latencyOpts.length == 3) {
						if ("us".equalsIgnoreCase(latencyOpts[2])) {
							showMicroSeconds = true;
						}
					}
					if (multLatency == false) {
						latencyManager = new MicrosecondLatencyManager(columns, bitShift, showMicroSeconds);
						readLatencyManager = new MicrosecondLatencyManager(columns, bitShift, showMicroSeconds);
						writeLatencyManager = new MicrosecondLatencyManager(columns, bitShift, showMicroSeconds);
						batchLatencyManager = new MicrosecondLatencyManager(columns, bitShift, showMicroSeconds);
					}
					else {
						latencyManager = new MsMultiplyerLatencyManager(columns, bitShift, showMicroSeconds);
						readLatencyManager = new MsMultiplyerLatencyManager(columns, bitShift, showMicroSeconds);
						writeLatencyManager = new MsMultiplyerLatencyManager(columns, bitShift, showMicroSeconds);
						batchLatencyManager = new MsMultiplyerLatencyManager(columns, bitShift, showMicroSeconds);
					}
				}
			} 

		}
		
		public static void configureProperties(CommandLine cl) throws IOException {
			if (cl.hasOption("properties")) {
				properties = new PropertiesManager(cl.getOptionValue("properties"));
			}
			else {
				properties = new PropertiesManager("seeding.properties");
			}
		}
		
		public static void configureStatisticDirectory(CommandLine cl) throws IOException {
			if (cl.hasOption("directory")) {
				Statistics.getInstance().setDefaultLogDirectory(cl.getOptionValue("directory"));
			}
		}
				
		public static void configureOperationMode(CommandLine cl) throws IOException {
			if (cl.hasOption("operationalMode")) {
				OperationMode mode = OperationMode.valueOf(cl.getOptionValue("operationalMode"));
				Control.getInstance().setMode(mode);
			}
		}
		
		public static void configureListeningPort(CommandLine cl) throws IOException {
			if (cl.hasOption("listenPort")) {
				jettyPort  = Integer.valueOf(cl.getOptionValue("listenPort"));
			}
		}
		
		public static void configureNFRs(CommandLine cl) throws Exception {
		
			nThreads = Integer.parseInt(cl.getOptionValue("threads", "8"));			
			if (nThreads < 1) {
				throw new Exception("Client threads (-z) must be > 0");
			}
	
			if (!cl.hasOption("multiple")) {
				multLatency = false;
			}		
			
			if (cl.hasOption("throughput")) {
				throughput = Integer.parseInt(cl.getOptionValue("throughput"));
			}	
		}
		
		public static void configureLogger(String namespace, CommandLine cl, Database database) throws Exception {
	        logger = new NullLogger();
			if (cl.hasOption("logging")) {
				String db = cl.getOptionValue("l");
				switch (db.charAt(0)) {
				case 'b':
					log.info("Logging to both database and console");
					logger = new MultiLogger(new DatabaseLogger(database, namespace, "logging"), new ConsoleLogger());
					break;
				case 'c':
					log.info("Logging to console");
					logger = new ConsoleLogger();
					break;
				case 'd':
					log.info("Logging to database");
					logger = new DatabaseLogger(database, namespace, "logging");
					break;
				case 'n':
					log.info("disabling logging");
					break;
				default:
					logUsage(options);
					return;
				}
			}
		}
		
		public static void configureDatabase(String[] args, Options options, CommandLine cl) throws Exception {
			
			String host = cl.getOptionValue("h", "127.0.0.1");
			if (!cl.hasOption("namespace")) {
				log.error("Keyspace / namespace name must be specified");
				logUsage(options);
				throw new Exception("Keyspace / namespace name must be specified");
			}
			
			String rOption = cl.getOptionValue("reset", "false");
			reset = Boolean.valueOf(rOption);
			namespace = cl.getOptionValue("namespace", "test");
			log.debug("Host: " + host);
			log.debug("KeySpace: " + namespace);

			if (cl.hasOption("database")) {
				String db = cl.getOptionValue("database");
				switch (db.charAt(0)) {
				case 'a':
					
					log.info("Using Aerospike database");
					database = new AerospikeDatabase(host, 3000, readLatencyManager, writeLatencyManager, batchLatencyManager);
					break;
					
				case 'c':
					
					log.info("Using Cassandra database");
					Map<String, String> tableToKeys = new HashMap<String, String>();
					
					tableToKeys.put("accounts", "number");
					tableToKeys.put("cards", "cardNo");
					tableToKeys.put("blackListCards", "cardNo");
					tableToKeys.put("transactions", "extTxnId");
					tableToKeys.put("countries", "code");
					tableToKeys.put("terminalTxnDate", "termId");
					tableToKeys.put("whiteListCards", "cardNo");
					
					database = new CassandraDatabase(host, readLatencyManager, writeLatencyManager, batchLatencyManager, tableToKeys);
					break;
					
				default:
					log.error("Unsupported database " + db);
					logUsage(options);
					throw new Exception("Unsupported database " + db);
					
				}
			}
			else {
				log.error("Database must be defined");
				logUsage(options);
				throw new Exception("Database must be defined");
			}
			
		}
		
		
		public static void seedDatabase(CommandLine cl) throws Exception {
			long randomSeed = Long.valueOf(cl.getOptionValue("random", "0"));
        	int nodeId = Integer.valueOf(cl.getOptionValue("seed", "1"));
        	int numNodes = properties.getInt(PropertyNames.NODE_CNT);
        	String tableString = cl.getOptionValue("tables", "all"); 
        	log.info("Node " + nodeId + " of " + numNodes);
        	ProgramDataSeeder seeder = new ProgramDataSeeder(database, namespace, nodeId, nThreads, randomSeed + 17*nodeId, properties);
			Set<String> tableNames = seeder.prepareForRun(reset, tableString.split(","));
        	seeder.generate(tableNames);
		}
		
		public static RulesEngine getRulesEngineHandle(CommandLine cl) throws Exception {
			RulesEngine RulesEngine = new RulesEngineStub();
			return RulesEngine;
		}
		
		public static MachineLearning getMachineLearningHandle(CommandLine cl) throws Exception {
			MachineLearning machineLearning = new MachineLearningStub();
			return machineLearning;
		}
		
		public static Loader configureClientTxnLoader(CommandLine cl) throws Exception {
			long randomSeed = Long.valueOf(cl.getOptionValue("random", "0")); 
			long initialTxnValue = Long.valueOf(cl.getOptionValue("initial", "0")); 
			Random random = new Random(randomSeed);

        	IdMapper<Account> accountMapper = new AccountSeeder(null, null, 0, null);
        	IdMapper<CreditCard> cardMapper = new CreditCardSeeder(null, null, 0, null);
        	IdMapper<Merchant> merchantMapper = new MerchantSeeder(null, null);
        	IdMapper<Terminal> terminalMapper = new TerminalSeeder(null, null, 0, null, 0, null);
        	IdMapper<AcctNumAndCode> acctNumAndCodeMapper = new AcctNumAndCodeSeeder(null, null, properties.getInt(PropertyNames.MERCHANTS_CNT));
			Loader loader = new InfiniteLoader(random, accountMapper, cardMapper, merchantMapper, terminalMapper, acctNumAndCodeMapper, properties, throughput, initialTxnValue);
			
        	return loader;
		}
		
		public static void startFraudOrchestrator(Loader loader, RulesEngine rulesEngine, MachineLearning machineLearning, int nThreads) throws Exception {
			final Statistics statistics = Statistics.getInstance();
			Server server = null;
			ResourceHandler resourceHandler = null;
			if (jettyPort > 0) {
				log.info("Starting up jetty on port " + jettyPort);
				server = new Server(jettyPort);
				resourceHandler = new ResourceHandler();
				resourceHandler.setDirectoriesListed(true);
				resourceHandler.setWelcomeFiles(new String[] { "index.html" });
				resourceHandler.setResourceBase(".");
			}
			
			log.info("Using " + nThreads + " threads");
			
			LatencyStatsWrapper latencyStatsWrapper = new LatencyStatsWrapper(
			 namespace, 
			 loader, 
			 database, 
			 logger, 
			 latencyManager,
			 readLatencyManager, 
			 writeLatencyManager, 
			 batchLatencyManager,
			 statistics);
			
			TxnFraudOrchestrator txnOrchestrator = new TxnFraudOrchestrator(latencyStatsWrapper, rulesEngine, machineLearning, nThreads);				

			if (server != null) {
				HandlerList handlers = new HandlerList();
				handlers.setHandlers(new Handler[] { resourceHandler, new StatisticsHandler(txnOrchestrator) } );
				server.setHandler(handlers);
				server.start();
			}
			
			txnOrchestrator.start();
			if (server != null) {
				server.join();
			}
//				LatencyManager.printHeader(System.out);
//				LatencyManager.printResults(System.out, "Txns");
//				readLatencyManager.printResults(System.out, "Reads");

		
	}
	
	/**
	 * Write usage to console.
	 */
	private static void logUsage( Options options) {
		HelpFormatter formatter = new HelpFormatter();
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		String syntax = TxnFraudClient.class.getName() + " [<options>]";
		formatter.printHelp(pw, 100, syntax, "options:", options, 0, 2, null);
		log.info(sw.toString());
	}
	
}
