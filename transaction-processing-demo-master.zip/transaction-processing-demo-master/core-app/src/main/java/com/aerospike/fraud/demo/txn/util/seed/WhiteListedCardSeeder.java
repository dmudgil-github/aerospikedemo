package com.aerospike.fraud.demo.txn.util.seed;

import java.util.Random;

import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.database.DatabaseKey;
import com.aerospike.fraud.demo.txn.database.mappers.WhiteListedCardMapper;
import com.aerospike.fraud.demo.txn.model.CreditCard;
import com.aerospike.fraud.demo.txn.model.WhiteListedCard;

public class WhiteListedCardSeeder extends Seeder implements IdMapper<WhiteListedCard> {
	private final Database database;
	private final String keySpace;
	private final WhiteListedCardMapper mapper = new WhiteListedCardMapper();
	private static final SeederUtils utils = new SeederUtils();
	private final int cardCount;
	private final IdMapper<CreditCard> cardMapper;
	private boolean seedKnownCards = true;
	
	private static final String [] whiteListReasons = {
			"VIP customer",
			"Spends lots of money with us",
			"Knows our chairman",
			"Long term customer"
	};

	public WhiteListedCardSeeder(Database database, String keySpace, IdMapper<CreditCard> cardMapper, int cardCount) {
		super("White Listed Cards");
		this.database = database;
		this.keySpace = keySpace;
		this.cardMapper = cardMapper;
		this.cardCount = cardCount;
	}
	
	public String getIdForLogicalId(long id) {
		throw new UnsupportedOperationException("Should not call getIdForLogicalId on WhiteListSeeder");
	}
	
	private void whiteListCard(Random r, String cardNumber) {
		WhiteListedCard whiteCard = new WhiteListedCard(
				cardNumber,
				whiteListReasons[r.nextInt(whiteListReasons.length)],
				utils.getDate(r, -5 * 365, 0, false));
		
		DatabaseKey key = new DatabaseKey(keySpace, "whiteListCards", cardNumber);
		this.database.put(null, key, mapper.toRecord(whiteCard));
	}
	
	@Override
	protected int doSeed(Random r, long startId, long endId) {
		int count = 0;
		for (long i = startId; i < endId; i++) {
			String cardNumber;
			if (seedKnownCards) {
				cardNumber = cardMapper.getIdForLogicalId(r.nextInt(cardCount));
			}
			else {
				// seed a card which is unknown.
				cardNumber = "54026" + utils.formatNumber(r.nextInt(100000000), 11, 319, 1241108201);
			}
			this.whiteListCard(r, cardNumber);
			count++;
		}
		return count;
	}

	public void setKnownCards(boolean seedKnownCards) {
		this.seedKnownCards = seedKnownCards;
	}
}
