package com.aerospike.fraud.demo.txn.eventpublisher;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import com.aerospike.fraud.demo.txn.client.Statistics;
import com.aerospike.fraud.demo.txn.client.Statistics.OperationStatistics;
import com.aerospike.fraud.demo.txn.client.TxnFraudClient;
import com.aerospike.fraud.demo.txn.database.Column;
import com.aerospike.fraud.demo.txn.database.DataElement;
import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.database.DatabaseKey;
import com.aerospike.fraud.demo.txn.database.mappers.SpendingHabitsMapper;
import com.aerospike.fraud.demo.txn.database.mappers.TransactionMapper;
import com.aerospike.fraud.demo.txn.database.refdata.ReferenceData;
import com.aerospike.fraud.demo.txn.eventpublisher.impl.PostEventHandlerImplLocal;
import com.aerospike.fraud.demo.txn.model.ClientHydratedTransaction;
import com.aerospike.fraud.demo.txn.model.ClientHydratedTransaction.TransactionType;
import com.aerospike.fraud.demo.txn.model.FraudFactsModel;
import com.aerospike.fraud.demo.txn.model.LatencyStatsWrapper;
import com.aerospike.fraud.demo.txn.model.events.Event;
import com.aerospike.fraud.demo.txn.model.events.PostTxnEvent;
import com.aerospike.fraud.demo.txn.util.logging.Logger;

public class PostEventManager implements Runnable {
	
	
		private Event event;

		private PostEventHandler postEventHandler;
		public PostEventManager (Event event) {
			this.event = event;

		}
	
		private void handleEvent() throws EventException {
			postEventHandler = getPostEventHandler();
			postEventHandler.handleEvent();
		
		}

		@Override
		public void run() {
			try {
				this.handleEvent();
				
			} catch (Exception e) {
				org.apache.log4j.Logger.getLogger(TxnFraudClient.class)
						.error("Error writing to database: " + e.getMessage(), e);
			}
		}
		
		/*
		 * AS of now this is hard coding to handle event locally.
		 * A proper Factory will be created later to pick the right instance 
		 */
		private PostEventHandler getPostEventHandler()  {
			
			return new PostEventHandlerImplLocal(event);
		}		
}