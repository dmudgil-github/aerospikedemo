package com.aerospike.fraud.demo.txn.database.aerospike;

import com.aerospike.fraud.demo.txn.database.Column;
import com.aerospike.fraud.demo.txn.database.DatabaseKey;
import com.aerospike.fraud.demo.txn.database.PreparedDatabaseStatement;
import com.aerospike.fraud.demo.txn.database.RecordData;

/**
 * The Aerospike implementation of a prepared statement. As this is not supported
 * in Aerospike, this is a very simple class.
 * @author Tim
 *
 */
class AerospikePreparedStatement implements PreparedDatabaseStatement {
	private AerospikeDatabase database;
	public AerospikePreparedStatement(AerospikeDatabase db) {
		this.database = db;
	}
	@Override
	public RecordData get(DatabaseKey key) {
		return this.database.get(key);
	}
}
