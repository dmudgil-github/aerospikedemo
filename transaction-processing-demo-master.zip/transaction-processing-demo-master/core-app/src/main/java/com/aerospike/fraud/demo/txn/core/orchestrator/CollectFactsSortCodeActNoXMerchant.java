package com.aerospike.fraud.demo.txn.core.orchestrator;

import java.util.concurrent.Callable;

import com.aerospike.fraud.demo.txn.client.Statistics;
import com.aerospike.fraud.demo.txn.client.Statistics.OperationStatistics;
import com.aerospike.fraud.demo.txn.core.orchestrator.TxnFraudOrchestrator.FraudResult;
import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.database.DatabaseKey;
import com.aerospike.fraud.demo.txn.database.PreparedDatabaseStatement;
import com.aerospike.fraud.demo.txn.database.RecordData;
import com.aerospike.fraud.demo.txn.database.mappers.AcctNumAndCodeMapper;
import com.aerospike.fraud.demo.txn.model.AcctNumAndCode;
import com.aerospike.fraud.demo.txn.model.FraudFactsModel;
import com.aerospike.fraud.demo.txn.model.LatencyStatsWrapper;
import com.aerospike.fraud.demo.txn.util.logging.Logger;
import com.aerospike.fraud.demo.txn.util.seed.AcctNumAndCodeSeeder;

class CollectFactsSortCodeActNoXMerchant implements Callable<FraudResult> {


		private String txnId;
		private String merchantName;
		private String acctNum;
		private String sCode;
		private FraudFactsModel fraudFacts;
		
		private Database database;
		private Logger logger;
		private String namespace;
		private AcctNumAndCodeMapper acctAndSCodeMapper = new AcctNumAndCodeMapper();
		private AcctNumAndCodeSeeder acctAndSCodeSeeder = new AcctNumAndCodeSeeder(null, null, 0);
		private final LatencyStatsWrapper latencyStatsWrapper;
		private static PreparedDatabaseStatement preparedStatement = null;


		public CollectFactsSortCodeActNoXMerchant(String txnId, String merchantName, String acctNum, String sCode, FraudFactsModel fraudFacts,
				LatencyStatsWrapper latencyStatsWrapper) {
			this.txnId = txnId;
			this.merchantName = merchantName;
			this.acctNum = acctNum;
			this.sCode = sCode;
			this.fraudFacts = fraudFacts;
			this.latencyStatsWrapper = latencyStatsWrapper;
			this.logger = latencyStatsWrapper.getLogger();
			this.database = latencyStatsWrapper.getDatabase();
			this.namespace = latencyStatsWrapper.getNamespace();
			synchronized(CollectFactsSortCodeActNoXMerchant.class) {
				if (preparedStatement == null) {
					preparedStatement = database.prepare("select id,acctNum,s_code,merchName,txnCount,txnDate from " + namespace + ".accountNumAndCode where id = ?");
				}
			}
		}

		@Override
		public FraudResult call() throws Exception {
			String compoundKey = acctNum + "|" + sCode + "|" + merchantName;

			OperationStatistics acctCodeStats = Statistics.getInstance().getStats(Statistics.ACCT_CODE_STATS);
			DatabaseKey key = new DatabaseKey(namespace, "accountNumAndCode", compoundKey);
			long time = acctCodeStats.beginMeasure();
			RecordData record = preparedStatement.get(key);
			acctCodeStats.endMeasure(time);
			AcctNumAndCode merchant = acctAndSCodeMapper.fromRecord(record);
			fraudFacts.setAcctNumAndCode(merchant);
			if (merchant != null) {
				logger.log("Txn %s: found matching account code for %s", txnId, compoundKey);
				acctCodeStats.addHit();
			}
			else {
				logger.log("Txn %s: could not find matching account code for %s", txnId, compoundKey);
			}
			return FraudResult.OK;
		}
	}
