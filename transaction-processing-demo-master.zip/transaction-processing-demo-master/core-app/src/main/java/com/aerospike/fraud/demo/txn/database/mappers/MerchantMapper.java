package com.aerospike.fraud.demo.txn.database.mappers;

import java.util.ArrayList;
import java.util.List;

import com.aerospike.fraud.demo.txn.database.Column;
import com.aerospike.fraud.demo.txn.database.DataElement;
import com.aerospike.fraud.demo.txn.database.RecordData;
import com.aerospike.fraud.demo.txn.model.Merchant;
import com.aerospike.fraud.demo.txn.model.Merchant.MerchantType;

/**
 * This class performs mapping from database records to Merchants and back.
 * This could be done with a lot less code using annotations and introspection, but
 * this has a runtime performance penalty and this is key in this use case.
 * @author Tim
 *
 */
public class MerchantMapper {
	public Merchant fromRecord(RecordData record) {
		Merchant result = null;
		if (record != null) {
			result = new Merchant();
			result.setCountry(record.getString("country"));
			result.setPostalCode(record.getString("pc"));
			result.setId(record.getString("id"));
			result.setName(record.getString("name"));
			result.setMerchantType(MerchantType.fromType(record.getString("type")));
			result.setTimesTransacted(record.getInt("timesUsed"));
		}
		return result;
	}
	
	public Column[] toRecord(Merchant merchant) {
		List<Column> elements = new ArrayList<Column>();
		elements.add(new Column("country", DataElement.get(merchant.getCountry())));
		elements.add(new Column("pc", DataElement.get(merchant.getPostalCode())));
		elements.add(new Column("id", DataElement.get(merchant.getId())));
		elements.add(new Column("name", DataElement.get(merchant.getName())));
		elements.add(new Column("type", DataElement.get(merchant.getMerchantType().getType())));
		elements.add(new Column("timesUsed", DataElement.get(merchant.getTimesTransacted())));
		return elements.toArray(new Column[0]);
	}

}
