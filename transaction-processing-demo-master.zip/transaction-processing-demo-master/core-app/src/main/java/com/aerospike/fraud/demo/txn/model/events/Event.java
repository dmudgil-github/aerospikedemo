package com.aerospike.fraud.demo.txn.model.events;

public class Event {
	


}
