package com.aerospike.fraud.demo.txn.model;

import java.util.Date;

/**
 * Customers have accounts, accounts have cards associated with them
 * @author Tim
 *
 */
public class Account {

	private String number;
	private String nameOnAccount;
	private String customerId;
	private Date dateOpened;
	// used to fill out the object to the appropriate size, eg 2k
	private String[] padding;
	
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getNameOnAccount() {
		return nameOnAccount;
	}
	public void setNameOnAccount(String nameOnAccount) {
		this.nameOnAccount = nameOnAccount;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public Date getDateOpened() {
		return dateOpened;
	}
	public void setDateOpened(Date dateOpened) {
		this.dateOpened = dateOpened;
	}
	public String[] getPadding() {
		return padding;
	}
	public void setPadding(String[] padding) {
		this.padding = padding;
	}
}
