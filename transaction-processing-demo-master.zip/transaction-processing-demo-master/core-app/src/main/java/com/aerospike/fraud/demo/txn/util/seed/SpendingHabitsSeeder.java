package com.aerospike.fraud.demo.txn.util.seed;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.database.DatabaseKey;
import com.aerospike.fraud.demo.txn.database.WriteOptions;
import com.aerospike.fraud.demo.txn.database.mappers.SpendingHabitsMapper;
import com.aerospike.fraud.demo.txn.database.refdata.ReferenceData;
import com.aerospike.fraud.demo.txn.model.AmountRange;
import com.aerospike.fraud.demo.txn.model.Customer;
import com.aerospike.fraud.demo.txn.model.Merchant;
import com.aerospike.fraud.demo.txn.model.SpendingHabits;
import com.aerospike.fraud.demo.txn.model.Terminal;
import com.aerospike.fraud.demo.txn.model.SpendingHabits.SpendingHabit;

public class SpendingHabitsSeeder extends Seeder {

	private final String keySpace;
	private final Database database;
	private final IdMapper<Customer> customerMapper;
	private final IdMapper<Merchant> merchantMapper;
	private final IdMapper<Terminal> terminalMapper;
	private final int maxTxnsPerCustomer;
	private final long maxTxnKeepTimeMs;
	private final int numTerminals;
	private final int numMerchants;
	private final SpendingHabitsMapper mapper = new SpendingHabitsMapper();
	
	public SpendingHabitsSeeder(Database database, String keySpace, IdMapper<Customer> customerMapper, IdMapper<Merchant> merchantMapper, IdMapper<Terminal> terminalMapper, int maxTxnsPerCustomer, long maxTxnKeepTimeMs, int numTerminals, int numMerchants) {
		super("Spending Habits History");
		this.keySpace = keySpace;
		this.database = database;
		this.customerMapper = customerMapper;
		this.terminalMapper = terminalMapper;
		this.merchantMapper = merchantMapper;
		this.maxTxnsPerCustomer = maxTxnsPerCustomer;
		this.maxTxnKeepTimeMs = maxTxnKeepTimeMs;
		this.numTerminals = numTerminals;
		this.numMerchants = numMerchants;
	}
	
	@Override
	public String getIdForLogicalId(long id) {
		throw new UnsupportedOperationException("SpendingHabitsSeeder.getIdForLogicalId should not be called.");
	}
	
	private void addToMaps(Map<String, SpendingHabits> maps, String[] keys, double amount) {
		for (String key : keys) {
			this.addToMaps(maps, key, amount);
		}
	}
	
	private void addToMaps(Map<String, SpendingHabits> maps, String key, double amount) {
		SpendingHabits habits = maps.get(key);
		if (habits == null) {
			habits = new SpendingHabits();
			maps.put(key, habits);
		}
		habits.getTotal().setAmount(habits.getTotal().getAmount() + amount);
		habits.getTotal().setCount(habits.getTotal().getCount() + 1);
		AmountRange range = ReferenceData.getRangeForAmount(amount);
		SpendingHabit habit = habits.getSpendingHabitForRange(range.getRangeId());
		// This returns an actual reference to the object.
		habit.setAmount(habit.getAmount() + amount);
		habit.setCount(habit.getCount() + 1);
	}
	
	/**
	 * For a customer, we need amounts, time, merchant type
	 */
	@Override
	protected int doSeed(Random random, long startId, long endId) {
		int count = 0;
		for (long i = startId; i < endId; i++) {
			String custId = customerMapper.getIdForLogicalId(i);
			
			// For each customer we need to store:
			//	1) Customer:[time] -> SpendingHabits
			//	2) Customer:merchant:[time] -> SpendingHabits
			//	3) Customer:terminalId:[time] -> SpendingHabits
			// Where time is each of: Day, Week, Month, Year.
			
			// Most customers have a long way short of the maximum number of transactions
			int txnsThisCustomer = (int)(random.nextDouble() * random.nextDouble() * random.nextDouble() * maxTxnsPerCustomer);
			Calendar cal = new GregorianCalendar();
			long now = new Date().getTime();
			Map<String, SpendingHabits> habits = new HashMap<String, SpendingHabits>(100);
			for (int j = 0; j < txnsThisCustomer; j++) {
				double txnAmount = random.nextDouble() * random.nextDouble() * random.nextDouble() * random.nextDouble() * 25000;
				txnAmount = ((double)(Math.round(txnAmount * 100))) / 100.0;
				// Just normally distribute over the ranges. This doesn't mirror real-world spending habits.
				Date txnDate = new Date((long)(now - random.nextDouble() * maxTxnKeepTimeMs));
				cal.setTime(txnDate);
				String terminalId = terminalMapper.getIdForLogicalId(random.nextInt(numTerminals));
				String merchantId = merchantMapper.getIdForLogicalId(random.nextInt(numMerchants));

//				String hr = pad(cal.get(Calendar.HOUR_OF_DAY));
//				String day = pad(cal.get(Calendar.DAY_OF_MONTH));
//				String week = pad(cal.get(Calendar.WEEK_OF_YEAR));
//				String month = pad(cal.get(Calendar.MONTH)+1);
//				String year = Integer.toString(cal.get(Calendar.YEAR));
//				
//				String custKey = custId;
//				String terminalKey = custId + "-T" + terminalId;
//				String merchantKey = custId + "-M" + merchantId;
//
//				String[] keys = {custKey,terminalKey,merchantKey}; 
//				for (int a = 0; a < keys.length; a++) {
//					keys[a] += "y" + year;
//					addToMaps(habits, keys[a], txnAmount);
//					addToMaps(habits, keys[a]+"w"+week, txnAmount);
//					keys[a] += "m" + month;
//					addToMaps(habits, keys[a], txnAmount);
//					keys[a] += "d" + day;
//					addToMaps(habits, keys[a], txnAmount);
//					keys[a] += "h" + hr;
//					addToMaps(habits, keys[a], txnAmount);
//				}
				addToMaps(habits, mapper.formKeys(custId, null, null, cal), txnAmount);
				if (terminalId != null) {
					addToMaps(habits, mapper.formKeys(custId, terminalId, null, cal), txnAmount);
				}
				if (merchantId != null) {
					addToMaps(habits, mapper.formKeys(custId, null, merchantId, cal), txnAmount);
				}
			}
			
			// Write out the data
			for (String key : habits.keySet()) {
				// TODO: Set a TTL on these records
				WriteOptions options = new WriteOptions();
				options.setTimeToLive(3*365*86400);
				DatabaseKey dbKey = new DatabaseKey(keySpace, "spendingHabits", key);
				this.database.put(options, dbKey, mapper.toRecord(key, habits.get(key)));
				count++;
			}
		}

		return count;
	}
	
	
}
