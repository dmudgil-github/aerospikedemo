package com.aerospike.fraud.demo.txn.model;

import java.util.Date;

public class AcctNumAndCode {
	private String id;	// Not needed for Aerospike, but needed for Cassandra as we do not support the syntax for compound primary keys
	private String acctNum;
	private String s_code;
	private String merchantName;
	private long txnCount;
	private Date lastTransactionDate;
	public String getAcctNum() {
		return acctNum;
	}
	public void setAcctNum(String acctNum) {
		this.acctNum = acctNum;
	}
	public String getS_code() {
		return s_code;
	}
	public void setS_code(String s_code) {
		this.s_code = s_code;
	}
	public String getMerchantName() {
		return merchantName;
	}
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}
	public long getTxnCount() {
		return txnCount;
	}
	public void setTxnCount(long txnCount) {
		this.txnCount = txnCount;
	}
	public Date getLastTransactionDate() {
		return lastTransactionDate;
	}
	public void setLastTransactionDate(Date lastTransactionDate) {
		this.lastTransactionDate = lastTransactionDate;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
}
