package com.aerospike.fraud.demo.txn.model;

public class RawTransaction {

}
