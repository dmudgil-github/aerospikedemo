package com.aerospike.fraud.demo.txn.model;

import java.util.Date;

public class HistoryEntry {
	private Date start;
	private Date end;
	private int count;
	private double amount;
	private int fraudCount;
	private double fraudAmount;
	
	public HistoryEntry(Date start, Date end, int count, double amount, int fraudCount, double fraudAmount) {
		super();
		this.start = start;
		this.end = end;
		this.count = count;
		this.amount = amount;
		this.fraudCount = fraudCount;
		this.fraudAmount = fraudAmount;
	}
	public Date getStart() {
		return start;
	}
	public Date getEnd() {
		return end;
	}
	public int getCount() {
		return count;
	}
	public double getAmount() {
		return amount;
	}
	public int getFraudCount() {
		return fraudCount;
	}
	public double getFraudAmount() {
		return fraudAmount;
	}
	
}