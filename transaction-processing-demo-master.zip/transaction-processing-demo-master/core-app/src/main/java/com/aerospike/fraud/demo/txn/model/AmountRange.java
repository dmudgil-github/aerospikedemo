package com.aerospike.fraud.demo.txn.model;

public class AmountRange {
	private final int min;	// inclusive
	private final int max; 	// exclusive
	private final int rangeId;
	public AmountRange(int min, int max, int rangeId) {
		super();
		this.min = min;
		this.max = max;
		this.rangeId = rangeId;
	}
	public int getMin() {
		return min;
	}
	public int getMax() {
		return max;
	}
	public int getRangeId() {
		return rangeId;
	}
}