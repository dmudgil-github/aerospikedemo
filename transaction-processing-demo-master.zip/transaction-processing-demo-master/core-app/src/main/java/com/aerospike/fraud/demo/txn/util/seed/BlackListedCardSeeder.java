package com.aerospike.fraud.demo.txn.util.seed;

import java.util.Random;

import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.database.DatabaseKey;
import com.aerospike.fraud.demo.txn.database.mappers.BlackListedCardMapper;
import com.aerospike.fraud.demo.txn.model.BlackListedCard;
import com.aerospike.fraud.demo.txn.model.CreditCard;

public class BlackListedCardSeeder extends Seeder implements IdMapper<BlackListedCard> {
	private final Database database;
	private final String keySpace;
	private final BlackListedCardMapper mapper = new BlackListedCardMapper();
	private static final SeederUtils utils = new SeederUtils();
	private final int cardCount;
	private final IdMapper<CreditCard> cardMapper;
	private boolean seedKnownCards = true;
	
	private static final String [] blackListReasons = {
			"Low credit rating",
			"Unpaid balances",
			"Too many disputes",
			"Bankrupt",
			"Debt to income ratio"
	};

	public BlackListedCardSeeder(Database database, String keySpace, IdMapper<CreditCard> cardMapper, int cardCount) {
		super("Black Listed Cards");
		this.database = database;
		this.keySpace = keySpace;
		this.cardMapper = cardMapper;
		this.cardCount = cardCount;
	}
	
	public String getIdForLogicalId(long id) {
		throw new UnsupportedOperationException("Should not call getIdForLogicalId on BlackListSeeder");
	}
	
	private void blackListCard(Random r, String cardNumber) {
		BlackListedCard blackCard = new BlackListedCard(
				cardNumber,
				blackListReasons[r.nextInt(blackListReasons.length)],
				utils.getDate(r, -5 * 365, 0, false));
		
		DatabaseKey key = new DatabaseKey(keySpace, "blackListCards", cardNumber);
		this.database.put(null, key, mapper.toRecord(blackCard));
	}
	
	@Override
	protected int doSeed(Random r, long startId, long endId) {
		int count = 0;
		for (long i = startId; i < endId; i++) {
			String cardNumber;
			if (seedKnownCards) {
				cardNumber = cardMapper.getIdForLogicalId(r.nextInt(cardCount));
			}
			else {
				// seed a card which is unknown.
				cardNumber = "54026" + utils.formatNumber(r.nextInt(100000000), 11, 319, 1241108201);
			}
			this.blackListCard(r, cardNumber);
			count++;
		}
		return count;
	}

	public void setKnownCards(boolean seedKnownCards) {
		this.seedKnownCards = seedKnownCards;
	}
}
