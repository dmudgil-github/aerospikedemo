package com.aerospike.fraud.demo.txn.database.cassandra;

import java.util.List;

import com.aerospike.fraud.demo.txn.database.RecordData;
import com.datastax.driver.core.Row;

class CassandraRecord implements RecordData {
	Row row;
	public CassandraRecord(Row row) {
		this.row = row;		
	}
	
	@Override
	public Object get(String columnName) {
		return row == null ? null : row.getObject(columnName.toLowerCase());
	}
	
	@Override
	public int getInt(String columnName) {
		return row == null ? null : row.getInt(columnName.toLowerCase());
	}
	
	@Override
	public long getLong(String columnName) {
		return row == null ? null : row.getLong(columnName.toLowerCase());
	}
	
	@Override
	public String getString(String columnName) {
		return row == null ? null : row.getString(columnName.toLowerCase());
	}

	@Override
	public <T> List<T> getList(String columnName, Class<T> clazz) {
		return row == null ? null : row.getList(columnName.toLowerCase(), clazz);
	}

	@Override
	public double getDouble(String columnName) {
		return row == null ? null : row.getDouble(columnName.toLowerCase());
	}
}