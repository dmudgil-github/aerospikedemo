package com.aerospike.fraud.demo.txn.client;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.log4j.Logger;

import com.aerospike.fraud.demo.txn.util.latency.MsMultiplyerLatencyManager;
import com.aerospike.fraud.demo.txn.util.latency.MsMultiplyerLatencyManager.TimingResults;

public class Statistics {
	public static final int WINDOW_SIZE_MS = 5000;
	
	// Names of the statistics collectors. This will also appear as the stats filename
	public static final String BLACK_LIST_STATS = "blackListRead";
	public static final String WHITE_LIST_STATS = "whiteListRead";
	public static final String ACCT_CODE_STATS = "acctCodeRead";
	public static final String TXN_WRITE_STATS = "txnWrite";
	public static final String MERCHANT_READ_STATS = "merchantRead";
	public static final String TERMINAL_READ_STATS = "terminalRead";
	public static final String TERMINAL_HISTORY_WRITE_STATS = "termHistWrite";
	public static final String TERMINAL_HISTORY_READ_STATS = "termHistRead";
	public static final String STORE_READ_STATS = "storeRead";
	public static final String LOCATION_READ_STATS = "locationRead";
	public static final String SPENDING_HABITS_UPDATE_STATS = "spndHabitsUpd";
	public static final String SPENDING_HABITS_READ_STATS = "spndHabitsRead";
	public static final String CARD_READ_STATS = "cardRead";
	public static final String CUSTOMER_READ_STATS = "customerRead";
	public static final String ACCOUNT_READ_STATS = "accountRead";
	
	public static final String PROCESS_TRANSACTION_STATS = "processTransactions";
	
	public static class Current {
		AtomicInteger count = new AtomicInteger();
		AtomicInteger timeouts = new AtomicInteger();
		AtomicInteger errors = new AtomicInteger();
		AtomicInteger min = new AtomicInteger(-1);
		AtomicInteger max = new AtomicInteger(-1);
	}	

	public static enum StatisticsOptions {
		HIT_COUNT,
		SUB_OBJECT_COUNT,
		NONE
	};

	public static class OperationStatistics {
		private static final Logger logger = Logger.getLogger(Statistics.class);
		private final String name;
		private final MsMultiplyerLatencyManager latency;
		private AtomicLong hitCount;
		private AtomicLong windowHitCount;
		private AtomicLong counter;
		private AtomicLong windowCounter;
		private Writer logFile;
		private String fileName;
		private String results = "";
		
		public OperationStatistics(String name, StatisticsOptions options, boolean log, String dirName) {
			this.name = name;
			this.latency = new MsMultiplyerLatencyManager(100, 1, false);
			if (StatisticsOptions.HIT_COUNT == options) {
				hitCount = new AtomicLong(0);
				windowHitCount = new AtomicLong(0);
			}
			else if (StatisticsOptions.SUB_OBJECT_COUNT == options) {
				counter = new AtomicLong(0);
				windowCounter = new AtomicLong(0);
			}
			if (log) {
				if (dirName == null) {
					dirName = Statistics.getInstance().getDefaultLogDirectory();
				}
				fileName = ((dirName == null) ? "" : dirName + "/") + name + ".csv";
				try {
					logFile = new BufferedWriter(new FileWriter(fileName));
					String header = "date," + (hitCount != null ? "hits,hitsWindow," : "")+ (counter != null ? "counts,countsWindow," : "") + TimingResults.getCsvHeading(100);
					logFile.write(header);
				} catch (Exception e) {
					logger.error("Could not open output file " + fileName + ": " + e.getMessage(), e);
				}
			}
		}
		public String getName() {
			return name;
		}
		
		public long beginMeasure() {
			return System.nanoTime();
		}

		public void endMeasure(long info) {
			long diff = System.nanoTime() - info;
			latency.add(diff);
		}
		
		public void addHit() {
			if (hitCount != null) {
				this.hitCount.incrementAndGet();
				this.windowHitCount.incrementAndGet();
			}
		}
		
		public void addHitIfNotNull(Object o) {
			if (o != null && hitCount != null) {
				this.hitCount.incrementAndGet();
				this.windowHitCount.incrementAndGet();
			}
		}

		public void addCount(long count) {
			if (counter != null) {
				this.counter.addAndGet(count);
				this.windowCounter.addAndGet(count);
			}
		}
		private String getAsJsonAndLog() {
			TimingResults results = latency.getResults();
			StringBuffer sb = new StringBuffer( "\"").append(name).append("\": {").append(results.toJson());
			if (hitCount != null) {
				sb.append(",\"hits\":").append(hitCount);
				sb.append(",\"hitsWindow\":").append(windowHitCount);
			}
			if (counter != null) {
				sb.append(",\"counts:\":").append(counter);
				sb.append(",\"countsWindow\":").append(windowCounter);
			}
			sb.append("}");
			String resultsStr = sb.toString();
			if (logFile != null) {
				try {
					DateFormat df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM);
					logFile.write(df.format(new Date()) + "," + (hitCount != null ? (hitCount + "," + windowHitCount + ",") : "") + (counter != null ? (counter + "," + windowCounter + ",") : "") + results.toCsv() + "\n");
					logFile.flush();
				} catch (IOException e) {
					logger.error("Could not write to file " + fileName + ": " + e.getMessage(), e);
				}
			}
			if (windowHitCount != null) {
				this.windowHitCount.set(0);
			}
			if (windowCounter !=  null) {
				this.windowCounter.set(0);
			}
			this.results = resultsStr;
			return resultsStr;
		}
		
		public String getResults() {
			return results;
		}
	}

	private Map<String, OperationStatistics> stats = new HashMap<String, OperationStatistics>();

	/**
	 * Singleton pattern
	 * @return
	 */
	public static Statistics getInstance() {
		return instance;
	}
	private final static Statistics instance = new Statistics();
	private Statistics() {
		// Start up a thread to log the statistics every so often.
		new Thread(new Runnable() {
			@Override
			public void run() {
				System.out.println("Stats collector starting");
				while (true) {
					for (String key : stats.keySet()) {
						OperationStatistics thisStats = stats.get(key);
						thisStats.getAsJsonAndLog();
					}
					// TODO: Make this parameter driven
					try {
						Thread.sleep(WINDOW_SIZE_MS);
					} catch (InterruptedException e) {
					}
				}
			}
		}).start();
	}

	public OperationStatistics createStats(String name, StatisticsOptions options) {
		return createStats(name, options, true, null);
	}
	
	public synchronized OperationStatistics createStats(String name, StatisticsOptions options, boolean log, String dirName) {
		if (!stats.containsKey(name)) {
			stats.put(name, new OperationStatistics(name, options, log, dirName));
		}
		return stats.get(name);
	}
	
	public OperationStatistics getStats(String name) {
		return stats.get(name);
	}
	
	public String getAllStats() {
		StringBuffer sb = new StringBuffer();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd-hhmmss");
		sb.append("{\"date\":\"" ).append(sdf.format(new Date())).append("\",\"windowSize\":").append(WINDOW_SIZE_MS);
		for (String key : stats.keySet()) {
			sb.append(",");
			OperationStatistics thisStats = stats.get(key);
			sb.append(thisStats.getResults());
		}
		sb.append("}");
		return sb.toString();
	}
	
	private Current read;
	private Current write;
	private Current transactionsThisSecond = new Current();
	private Current transactions = new Current();
	
	private AtomicLong periodBegin = new AtomicLong();	
	AtomicInteger readNotFound = new AtomicInteger();
	AtomicInteger valueMismatchCnt = new AtomicInteger();
	AtomicInteger loadValuesFinishedTasks = new AtomicInteger();
	AtomicBoolean loadValuesFinished = new AtomicBoolean(false);
	private String defaultLogDirectory = ".";
	
	public void setDefaultLogDirectory(String defaultLogDirectory) {
		if (defaultLogDirectory == null) {
			throw new IllegalArgumentException("defaultLogDirectory cannot be null");
		}
		this.defaultLogDirectory = defaultLogDirectory;
	}
	
	public String getDefaultLogDirectory() {
		return defaultLogDirectory;
	}
	
	public Current getTransactionsThisSecond() {
		return transactionsThisSecond;
	}
	
	public int getTransactionsThisSecond(int value) {
		return getTransactionsThisSecond().count.getAndSet(value);
	}
	
	public Current getTransactions() {
		return this.transactions;
	}
	
	public AtomicLong getPeriodBegin() {
		return periodBegin;
	}

}
