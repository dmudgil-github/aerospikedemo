package com.aerospike.fraud.demo.txn.core.machinelearning;

import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.model.ClientHydratedTransaction;
import com.aerospike.fraud.demo.txn.model.FraudFactsModel;

public class MachineLearningStub implements MachineLearning {

	private static final int PROCESSING_TIME_MS = 15;
	public void processData(Database database, String keySpae, ClientHydratedTransaction transaction, FraudFactsModel components, int score) {
		long now = System.nanoTime();
			
		try {
			Thread.sleep(PROCESSING_TIME_MS);
		} catch (InterruptedException e) {
		}
		long time = System.nanoTime() - now;
		int msTime = (int)(time / 1000000);
		if (msTime > PROCESSING_TIME_MS * 1.5) {
			System.out.printf("Accuracy of time is not great enough for %dms delay (received %dms)\n", PROCESSING_TIME_MS, msTime);
		}
	}

}
