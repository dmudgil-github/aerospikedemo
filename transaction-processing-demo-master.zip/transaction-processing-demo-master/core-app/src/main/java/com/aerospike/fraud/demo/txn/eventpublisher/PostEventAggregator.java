package com.aerospike.fraud.demo.txn.eventpublisher;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import com.aerospike.fraud.demo.txn.client.Statistics;
import com.aerospike.fraud.demo.txn.client.Statistics.OperationStatistics;
import com.aerospike.fraud.demo.txn.client.TxnFraudClient;
import com.aerospike.fraud.demo.txn.database.Column;
import com.aerospike.fraud.demo.txn.database.DataElement;
import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.database.DatabaseKey;
import com.aerospike.fraud.demo.txn.database.mappers.SpendingHabitsMapper;
import com.aerospike.fraud.demo.txn.database.mappers.TransactionMapper;
import com.aerospike.fraud.demo.txn.database.refdata.ReferenceData;
import com.aerospike.fraud.demo.txn.model.ClientHydratedTransaction;
import com.aerospike.fraud.demo.txn.model.ClientHydratedTransaction.TransactionType;
import com.aerospike.fraud.demo.txn.model.FraudFactsModel;
import com.aerospike.fraud.demo.txn.model.LatencyStatsWrapper;
import com.aerospike.fraud.demo.txn.model.events.Event;
import com.aerospike.fraud.demo.txn.model.events.PostTxnEvent;
import com.aerospike.fraud.demo.txn.util.logging.Logger;

public class PostEventAggregator implements Runnable {
	
	
		private ClientHydratedTransaction record;
		private FraudFactsModel fraudFacts;
		private Date txnDate;
		private Logger logger;

		private final Database database;
		private TransactionMapper transactionMapper = new TransactionMapper();		
		private SpendingHabitsMapper spendingHabitsMapper = new SpendingHabitsMapper();
		

		private final LatencyStatsWrapper latencyStatsWrapper;


		public PostEventAggregator (Event event) {
//		 PostEventAggregator(ClientHydratedTransaction txn, FraudFactsModel fraudFacts, LatencyStatsWrapper latencyStatsWrapper) {
			
			PostTxnEvent postTxnEvent = (PostTxnEvent)event;
			this.record = postTxnEvent.getTxn();
			this.fraudFacts = postTxnEvent.getFraudFacts();
			this.latencyStatsWrapper = postTxnEvent.getLatencyStatsWrapper();
			
			this.database = latencyStatsWrapper.getDatabase();
//			this.logger = logger;
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd:hhmmss");
			try {
				this.txnDate = sdf.parse(record.getTransactionDate() + ":" + record.getTransactionTime());
			} catch (ParseException e) {
				logger.log("Txn %s: Error turning transaction date strings to date (%s, %s): %s",
						record.getExternalTransactionId(), record.getTransactionDate(), record.getTransactionTime(),
						e.getMessage());
			}
		}

		private void updateTerminalStats() {
			GregorianCalendar cal = new GregorianCalendar();
			cal.setTime(txnDate);
			DatabaseKey key = new DatabaseKey(latencyStatsWrapper.getNamespace(), "terminalTxnDate",
					this.record.getTerminalId() + ":" + cal.get(Calendar.YEAR) + cal.get(Calendar.DAY_OF_YEAR));
			String binName = "hr" + cal.get(Calendar.HOUR_OF_DAY);
			double value = Double.valueOf(record.getTransactionAmount());
			
			OperationStatistics stats = Statistics.getInstance().getStats(Statistics.TERMINAL_HISTORY_WRITE_STATS);
			Column countCol = new Column("count", DataElement.get(1));
			Column amountCol = new Column("amount", DataElement.get(value));
			Column refundCnt = new Column("refundCnt",	DataElement.get(this.record.getTransactionType() == TransactionType.REFUND ? 1 : 0));
			Column refundAmt = new Column("refundAmt",	DataElement.get(this.record.getTransactionType() == TransactionType.REFUND ? value : 0));
			long time = stats.beginMeasure();
			database.incrementMany(key, binName, countCol,
					amountCol,
					refundCnt,
					refundAmt
					);
			stats.endMeasure(time);
		}

		private void saveTransaction() {
			OperationStatistics transactionWriteStats = Statistics.getInstance().getStats(Statistics.TXN_WRITE_STATS);
			long time = transactionWriteStats.beginMeasure();
			database.put(null, new DatabaseKey(latencyStatsWrapper.getNamespace(), "transactions", record.getExternalTransactionId()),
					transactionMapper.toRecord(record));
			transactionWriteStats.endMeasure(time);
		}

		private void updateSpendingHabits() {
			GregorianCalendar cal = new GregorianCalendar();
			cal.setTime(txnDate);
			for (int i = 0; i < 3; i++) {
				String terminalId = null;
				String merchantId = null;
				switch (i) {
				case 1:
					if (record.getTerminalId() == null) {
						continue;
					}
					terminalId = record.getTerminalId();
					break;
					
				case 2:
					if (record.getMerchantId() == null) {
						continue;
					}
					terminalId = record.getMerchantId();
					break;
				}
				String[] keys = spendingHabitsMapper.formKeys(fraudFacts.getCustomer().getCustomerId(), terminalId, merchantId, cal);
				double amount = Double.valueOf(record.getTransactionAmount());
				int amountRange = ReferenceData.getRangeForAmount(amount).getRangeId();
				for (String key : keys) {
					DatabaseKey dbKey = new DatabaseKey(latencyStatsWrapper.getNamespace(), "spendingHabits", key);
					Column[] columns = new Column[4];
					columns[0] = new Column("amtTotal", DataElement.get(amount));
					columns[1] = new Column("cntTotal", DataElement.get(1));
					columns[2] = new Column("amt"+amountRange, DataElement.get(amount));
					columns[3] = new Column("cnt"+amountRange, DataElement.get(1));
					
					OperationStatistics stats = Statistics.getInstance().getStats(Statistics.SPENDING_HABITS_UPDATE_STATS);
					long time = stats.beginMeasure();
					database.incrementMany(dbKey, columns);
					stats.endMeasure(time);
				}
			}
		}

		@Override
		public void run() {
			try {
				this.saveTransaction();
				this.updateTerminalStats();
				this.updateSpendingHabits();
			} catch (Exception e) {
				org.apache.log4j.Logger.getLogger(TxnFraudClient.class)
						.error("Error writing to database: " + e.getMessage(), e);
			}
		}
}