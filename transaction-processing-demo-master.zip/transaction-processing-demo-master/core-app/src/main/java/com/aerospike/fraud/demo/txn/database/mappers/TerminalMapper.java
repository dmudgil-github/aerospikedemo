package com.aerospike.fraud.demo.txn.database.mappers;

import java.util.ArrayList;
import java.util.List;

import com.aerospike.fraud.demo.txn.database.Column;
import com.aerospike.fraud.demo.txn.database.DataElement;
import com.aerospike.fraud.demo.txn.database.RecordData;
import com.aerospike.fraud.demo.txn.model.Terminal;

public class TerminalMapper {
	public Terminal fromRecord(RecordData record) {
		Terminal result = null;
		if (record != null) {
			result = new Terminal();
			result.setId(record.getString("id"));
			result.setLocationId(record.getString("locId"));
			result.setType(record.getString("type"));
			result.setStoreId(record.getString("storeId"));
		}
		return result;
	}
	
	public Column[] toRecord(Terminal terminal) {
		List<Column> elements = new ArrayList<Column>();
		elements.add(new Column("id", DataElement.get(terminal.getId())));
		elements.add(new Column("locId", DataElement.get(terminal.getLocationId())));
		elements.add(new Column("type", DataElement.get(terminal.getType())));
		elements.add(new Column("storeId", DataElement.get(terminal.getStoreId())));
		
		return elements.toArray(new Column[0]);
	}
}
