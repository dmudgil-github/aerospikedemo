package com.aerospike.fraud.demo.txn.eventpublisher;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import com.aerospike.fraud.demo.txn.client.Statistics;
import com.aerospike.fraud.demo.txn.client.Statistics.OperationStatistics;
import com.aerospike.fraud.demo.txn.client.TxnFraudClient;
import com.aerospike.fraud.demo.txn.database.Column;
import com.aerospike.fraud.demo.txn.database.DataElement;
import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.database.DatabaseKey;
import com.aerospike.fraud.demo.txn.database.mappers.SpendingHabitsMapper;
import com.aerospike.fraud.demo.txn.database.mappers.TransactionMapper;
import com.aerospike.fraud.demo.txn.database.refdata.ReferenceData;
import com.aerospike.fraud.demo.txn.model.ClientHydratedTransaction;
import com.aerospike.fraud.demo.txn.model.ClientHydratedTransaction.TransactionType;
import com.aerospike.fraud.demo.txn.model.FraudFactsModel;
import com.aerospike.fraud.demo.txn.model.LatencyStatsWrapper;
import com.aerospike.fraud.demo.txn.model.events.Event;
import com.aerospike.fraud.demo.txn.model.events.PostTxnEvent;
import com.aerospike.fraud.demo.txn.util.logging.Logger;

public abstract class PostEventHandler {
	
	
	protected ClientHydratedTransaction record;
	protected FraudFactsModel fraudFacts;
	protected Date txnDate;
	protected Logger logger;

	protected final Database database;
	protected TransactionMapper transactionMapper = new TransactionMapper();		
	protected SpendingHabitsMapper spendingHabitsMapper = new SpendingHabitsMapper();
	

	protected final LatencyStatsWrapper latencyStatsWrapper;



	public PostEventHandler(Event event) {
	
		PostTxnEvent postTxnEvent = (PostTxnEvent)event;
		this.record = postTxnEvent.getTxn();
		this.fraudFacts = postTxnEvent.getFraudFacts();
		this.latencyStatsWrapper = postTxnEvent.getLatencyStatsWrapper();
		
		this.database = latencyStatsWrapper.getDatabase();
		this.logger = latencyStatsWrapper.getLogger();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd:hhmmss");
		try {
			this.txnDate = sdf.parse(record.getTransactionDate() + ":" + record.getTransactionTime());
		} catch (ParseException e) {
			logger.log("Txn %s: Error turning transaction date strings to date (%s, %s): %s",
					record.getExternalTransactionId(), record.getTransactionDate(), record.getTransactionTime(),
					e.getMessage());
		}
	}

		abstract public void handleEvent() throws EventException;

}