package com.aerospike.fraud.demo.txn.util.seed;

import java.util.Random;

import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.database.DatabaseKey;
import com.aerospike.fraud.demo.txn.database.mappers.MerchantMapper;
import com.aerospike.fraud.demo.txn.database.mappers.StoreMapper;
import com.aerospike.fraud.demo.txn.model.Location;
import com.aerospike.fraud.demo.txn.model.Merchant;
import com.aerospike.fraud.demo.txn.model.Store;
import com.aerospike.fraud.demo.txn.model.Merchant.MerchantType;
import com.aerospike.fraud.demo.txn.util.seed.SeederUtils.Alphabet;

public class StoreSeeder extends Seeder implements IdMapper<Store> {
	private final Database database;
	private final String keySpace;
	private final int numLocations;
	private StoreMapper mapper = new StoreMapper();
	private IdMapper<Location> locationMapper;
	private static final SeederUtils utils = new SeederUtils();
	
	public StoreSeeder(Database database, String keySpace, int numLocations, IdMapper<Location> locationMapper) {
		super("Stores");
		this.database = database;
		this.keySpace = keySpace;
		this.numLocations = numLocations;
		this.locationMapper = locationMapper;
	}
	
	private Store generateStore(Random r, long id) {
		Store store = new Store();
		store.setId(getIdForLogicalId(id));
		store.setLocationId(locationMapper.getIdForLogicalId(r.nextInt(numLocations)));
		store.setName(utils.getName(r) + " Store");
		store.setTaxId(utils.getString(r, 9, Alphabet.ALPHA_NUM_UPPER));
		store.setNumEmployees(r.nextInt(3000));
		return store;
	}
	
	public String getIdForLogicalId(long id) {
		return utils.formatNumber(id, 9, 3, 145574231);
	}
	
	@Override
	protected int doSeed(Random r, long startId, long endId) {
		int count = 0;
		for (long i = startId; i < endId; i++) {
			Store store = generateStore(r, i);
			DatabaseKey key = new DatabaseKey(keySpace, "stores", store.getId());
			this.database.put(null, key, mapper.toRecord(store));
			count++;
		}
		return count;
	}
}
