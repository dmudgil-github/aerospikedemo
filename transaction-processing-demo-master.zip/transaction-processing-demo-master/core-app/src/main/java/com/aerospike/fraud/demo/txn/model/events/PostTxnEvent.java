package com.aerospike.fraud.demo.txn.model.events;

import com.aerospike.fraud.demo.txn.model.ClientHydratedTransaction;
import com.aerospike.fraud.demo.txn.model.FraudFactsModel;
import com.aerospike.fraud.demo.txn.model.LatencyStatsWrapper;

public class PostTxnEvent extends TxnEvent {
	
	private ClientHydratedTransaction txn;
	private FraudFactsModel fraudFacts;
	private LatencyStatsWrapper latencyStatsWrapper;
	
	
	public PostTxnEvent(ClientHydratedTransaction txn, FraudFactsModel fraudFacts, LatencyStatsWrapper latencyStatsWrapper) {
		this.txn = txn;
		this.fraudFacts = fraudFacts;
		this.latencyStatsWrapper = latencyStatsWrapper;
		
	}


	public ClientHydratedTransaction getTxn() {
		return txn;
	}


	public void setTxn(ClientHydratedTransaction txn) {
		this.txn = txn;
	}


	public FraudFactsModel getFraudFacts() {
		return fraudFacts;
	}


	public void setFraudFacts(FraudFactsModel fraudFacts) {
		this.fraudFacts = fraudFacts;
	}


	public LatencyStatsWrapper getLatencyStatsWrapper() {
		return latencyStatsWrapper;
	}


	public void setLatencyStatsWrapper(LatencyStatsWrapper latencyStatsWrapper) {
		this.latencyStatsWrapper = latencyStatsWrapper;
	}
	

}
