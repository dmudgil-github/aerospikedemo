package com.aerospike.fraud.demo.txn.database.mappers;

import java.util.ArrayList;
import java.util.List;

import com.aerospike.fraud.demo.txn.database.Column;
import com.aerospike.fraud.demo.txn.database.DataElement;
import com.aerospike.fraud.demo.txn.database.RecordData;
import com.aerospike.fraud.demo.txn.model.Store;

/**
 * This class performs mapping from database records to Store and back.
 * This could be done with a lot less code using annotations and introspection, but
 * this has a runtime performance penalty and this is key in this use case.
 * @author Tim
 *
 */
public class StoreMapper {
	public Store fromRecord(RecordData record) {
		Store result = null;
		if (record != null) {
			result = new Store();
			result.setId(record.getString("id"));
			result.setLocationId(record.getString("locId"));
			result.setName(record.getString("name"));
			result.setTaxId(record.getString("taxId"));
			result.setNumEmployees(record.getInt("numEmpl"));
		}
		return result;
	}
	
	public Column[] toRecord(Store store) {
		List<Column> elements = new ArrayList<Column>();
		elements.add(new Column("id", DataElement.get(store.getId())));
		elements.add(new Column("locId", DataElement.get(store.getLocationId())));
		elements.add(new Column("name", DataElement.get(store.getName())));
		elements.add(new Column("taxId", DataElement.get(store.getTaxId())));
		elements.add(new Column("numEmpl", DataElement.get(store.getNumEmployees())));
		return elements.toArray(new Column[0]);
	}

}
