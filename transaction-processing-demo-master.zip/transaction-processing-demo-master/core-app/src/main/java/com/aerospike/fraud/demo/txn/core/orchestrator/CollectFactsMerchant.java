package com.aerospike.fraud.demo.txn.core.orchestrator;

import java.util.concurrent.Callable;

import com.aerospike.fraud.demo.txn.client.Statistics;
import com.aerospike.fraud.demo.txn.client.Statistics.OperationStatistics;
import com.aerospike.fraud.demo.txn.core.orchestrator.TxnFraudOrchestrator.FraudResult;
import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.database.DatabaseKey;
import com.aerospike.fraud.demo.txn.database.PreparedDatabaseStatement;
import com.aerospike.fraud.demo.txn.database.RecordData;
import com.aerospike.fraud.demo.txn.database.mappers.MerchantMapper;
import com.aerospike.fraud.demo.txn.model.FraudFactsModel;
import com.aerospike.fraud.demo.txn.model.LatencyStatsWrapper;
import com.aerospike.fraud.demo.txn.model.Merchant;
import com.aerospike.fraud.demo.txn.model.Merchant.MerchantType;
import com.aerospike.fraud.demo.txn.util.logging.Logger;

public class CollectFactsMerchant implements Callable<FraudResult> {

 
		private String txnId;
		private String merchantId;
		private FraudFactsModel fraudFacts;
		private MerchantMapper merchantMapper = new MerchantMapper();
		
		private Database database;
		private Logger logger;
		private String namespace;
//		private AcctNumAndCodeMapper acctAndSCodeMapper = new AcctNumAndCodeMapper();
//		private AcctNumAndCodeSeeder acctAndSCodeSeeder = new AcctNumAndCodeSeeder(null, null, 0);
		private final LatencyStatsWrapper latencyStatsWrapper;
		private static PreparedDatabaseStatement preparedStatement = null;

		public CollectFactsMerchant(String txnId, String merchantId, FraudFactsModel fraudFacts,LatencyStatsWrapper latencyStatsWrapper) {
			this.txnId = txnId;
			this.merchantId = merchantId;
			this.fraudFacts = fraudFacts;
			
			this.latencyStatsWrapper = latencyStatsWrapper;
			this.logger = latencyStatsWrapper.getLogger();
			this.database = latencyStatsWrapper.getDatabase();
			this.namespace = latencyStatsWrapper.getNamespace();
			synchronized(CollectFactsMerchant.class) {
				if (preparedStatement == null) {
					preparedStatement = database.prepare("select id,country,pc,name,type,timesUsed from " + namespace + ".merchants where id = ?");
				}
			}
	
		}

		@Override
		public FraudResult call() throws Exception {
			OperationStatistics stats = Statistics.getInstance().getStats(Statistics.MERCHANT_READ_STATS);
			long time = stats.beginMeasure();
			RecordData result = preparedStatement.get(new DatabaseKey(namespace, "merchants", merchantId));
			stats.endMeasure(time);
			Merchant merchant = merchantMapper.fromRecord(result);
			fraudFacts.setMerchant(merchant);
			if (merchant == null) {
				logger.log("Txn %s: could not find merchant %s", txnId, merchantId);
				return FraudResult.MISSING_DATA;
			}
			else {
				stats.addHit();
			}
			MerchantType type = merchant.getMerchantType();
			fraudFacts.setMerchant(merchant);
			fraudFacts.setMerchantType(type);
			return FraudResult.OK;
		}
	}
