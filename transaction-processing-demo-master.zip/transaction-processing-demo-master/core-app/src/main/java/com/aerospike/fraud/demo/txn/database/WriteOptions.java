package com.aerospike.fraud.demo.txn.database;

public class WriteOptions extends Options {
	private boolean replaceExistingData = true;
	private int timeToLive = -1;
	
	public void setReplaceExistingData(boolean replaceExistingData) {
		this.replaceExistingData = replaceExistingData;
	}
	
	public boolean replaceExistingData() {
		return this.replaceExistingData;
	}
	
	/**
	 * Set the time to live in seconds
	 * @param timeToLive
	 */
	public void setTimeToLive(int timeToLive) {
		this.timeToLive = timeToLive;
	}
	public int getTimeToLive() {
		return timeToLive;
	}
}
