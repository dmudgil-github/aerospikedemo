package com.aerospike.fraud.demo.txn.util.seed;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.database.DatabaseKey;
import com.aerospike.fraud.demo.txn.database.WriteOptions;
import com.aerospike.fraud.demo.txn.database.mappers.TransactionMapper;
import com.aerospike.fraud.demo.txn.model.Account;
import com.aerospike.fraud.demo.txn.model.AcctNumAndCode;
import com.aerospike.fraud.demo.txn.model.ClientHydratedTransaction;
import com.aerospike.fraud.demo.txn.model.CreditCard;
import com.aerospike.fraud.demo.txn.model.Customer;
import com.aerospike.fraud.demo.txn.model.Merchant;
import com.aerospike.fraud.demo.txn.model.Terminal;
import com.aerospike.fraud.demo.txn.model.ClientHydratedTransaction.TransactionType;
import com.aerospike.fraud.demo.txn.util.configuration.PropertiesManager;
import com.aerospike.fraud.demo.txn.util.configuration.PropertyNames;
import com.aerospike.fraud.demo.txn.util.seed.SeederUtils.Alphabet;

public class InboundTransactionSeeder extends Seeder {
	private final Database database;
	private final String keySpace;
	private final IdMapper<Account> accountIdMapper;
	private final IdMapper<Customer> customerIdMapper;
	private final IdMapper<CreditCard> cardIdMapper;
	private final IdMapper<Merchant> merchantIdMapper;
	private final IdMapper<Terminal> terminalIdMapper;
	private final IdMapper<AcctNumAndCode> acctNumAndCodeMapper;
	private final TransactionMapper transactionMapper;
	private final PropertiesManager properties;
	private final int timeToLiveDays;
	private static final SeederUtils utils = new SeederUtils();
	
	private static String _getIdForLogicalId(long id) {
		return "102017091" + utils.formatNumber(id, 12, 17137, 2751241);
	}

	public static ClientHydratedTransaction createTransaction(
			Random r,
			IdMapper<Account> accountMapper, 
			IdMapper<CreditCard> cardMapper,
			IdMapper<Merchant> merchantMapper,
			IdMapper<Terminal> terminalMapper,
			IdMapper<AcctNumAndCode> acctNumAndCodeMapper,
			PropertiesManager properties,
			long id) {
		return createTransaction(r, accountMapper, cardMapper, merchantMapper, terminalMapper, acctNumAndCodeMapper, properties, null, id);
	}
	
	public static ClientHydratedTransaction createTransaction(
			Random r,
			IdMapper<Account> accountMapper, 
			IdMapper<CreditCard> cardMapper,
			IdMapper<Merchant> merchantMapper,
			IdMapper<Terminal> terminalMapper,
			IdMapper<AcctNumAndCode> acctNumAndCodeMapper,
			PropertiesManager properties,
			Date transactionDate,
			long id) {
		ClientHydratedTransaction txn = new ClientHydratedTransaction();

		double percentageRefunds = properties.getPercentage(PropertyNames.TERMIANALS_REFUND_PCT);
		if (percentageRefunds < 0 || percentageRefunds > 1) {
			percentageRefunds = 0;
		}
		SimpleDateFormat sdfDate = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat sdfTime = new SimpleDateFormat("hhmmss");

		txn.setRecordType("TRAN_TYPE2");
		txn.setDataSpecificationVersion("2.5");
		txn.setClientIdFromHeader("SOMEBANK");
		Date recordCreation = (transactionDate == null) ? new Date() : transactionDate;
		txn.setRecordCreationDate(sdfDate.format(recordCreation));
		txn.setRecordCreationTime(sdfTime.format(recordCreation));
		txn.setRecordCreationMilliseconds("456");
		txn.setGmtOffset("0.00");
		txn.setCustomerIdFromHeader("0000000000");
		txn.setCustomerAcctNumber(accountMapper.getIdForLogicalId(r.nextInt(properties.getInt(PropertyNames.ACCOUNTS_CNT))));
		txn.setExternalTransactionId(_getIdForLogicalId((int)id));
		txn.setPan(cardMapper.getIdForLogicalId(r.nextInt(properties.getInt(PropertyNames.CARDS_CNT))));
		txn.setAuthPostFlag("A");
		Date dob = utils.getDate(r, -75*365, -16*365, true);
		txn.setCustomerDateOfBirth(sdfDate.format(dob));
		// Date txnDate = utils.getDate(r, -1, 0, false);
		Date txnDate = recordCreation;
		txn.setTransactionDate(sdfDate.format(txnDate));
		txn.setTransactionTime(sdfTime.format(txnDate));
		txn.setTransactionAmount(Integer.toString(r.nextInt(30)*r.nextInt(30) * 10));
		txn.setTransactionCurrencyCode("826");
		txn.setTransactionCurrencyConversionR("1.000000");
		txn.setAuthDecisionCode("A");
		
		// Set some of the transactions to be (R)efunds instead of (C)redit
		txn.setTransactionType(r.nextDouble() < percentageRefunds ? TransactionType.REFUND : TransactionType.CREDIT);
		txn.setMcc("6009");
		txn.setMerchantPostalCode(utils.getString(r, 6, Alphabet.ALPHA_NUM_UPPER));
		txn.setMerchantCity(utils.getCity(r));
		txn.setMerchantCountryCode("826");
		txn.setMerchantId(merchantMapper.getIdForLogicalId(r.nextInt(properties.getInt(PropertyNames.MERCHANTS_CNT))));
		// This is hard coded to Merchant1 for now to ensure matching
		//txn.setMerchantName(utils.getCompanyName(r));
		txn.setMerchantName("Merchant1");
		txn.setPinVerifyCode("Z");
		txn.setCvvVerifyCode("V");
		txn.setPosEntryMode("D");

		txn.setTerminalId(terminalMapper.getIdForLogicalId(r.nextInt(properties.getInt(PropertyNames.TERMINALS_CNT))));
		txn.setAcquirerId(Integer.toString(r.nextInt(10000)));
//		System.out.printf("%s - %s\n", txn.getTerminalId(), txnDate.toString());

		txn.setAvailableBalance("");
		txn.setAvailableDailyCashLimit("");
		txn.setAvailableDailyMerchandiseLimit("");
		txn.setAcquirerCountry("");
		txn.setTerminalVerificationResults("");
		txn.setCardVerificationResults("");
		txn.setAcquirerBin("");
		txn.setAcctExpireDate("");
		
		long longId = properties.getLong(PropertyNames.S_CODES_TOTAL_CNT);
		while (longId > Integer.MAX_VALUE) {
			longId -= Integer.MAX_VALUE;
		}
		String acctNumAndCodeId = acctNumAndCodeMapper.getIdForLogicalId(r.nextInt((int)longId));
		txn.setAccountCode(acctNumAndCodeId.substring(0, 8));
		txn.setS_code(acctNumAndCodeId.substring(8));

		return txn;
	}
	
	public InboundTransactionSeeder(Database database, 
			String keySpace, 
			IdMapper<Customer> customerIdMapper, 
			IdMapper<Account> accountIdMapper,
			IdMapper<CreditCard> cardIdMapper,
			IdMapper<Merchant> merchantIdMapper,
			IdMapper<Terminal> terminalIdMapper,
			IdMapper<AcctNumAndCode> acctNumAndCodeMapper,
			PropertiesManager properties,
			long timeToLiveMs
			) {
		super("InboundTransactions");
		this.database = database;
		this.keySpace = keySpace;
		this.customerIdMapper = customerIdMapper;
		this.accountIdMapper = accountIdMapper;
		this.cardIdMapper = cardIdMapper;
		this.transactionMapper = new TransactionMapper();
		this.merchantIdMapper = merchantIdMapper;
		this.terminalIdMapper = terminalIdMapper;
		this.acctNumAndCodeMapper = acctNumAndCodeMapper;
		this.properties = properties;
		this.timeToLiveDays = (int)(timeToLiveMs / (24 * 60 * 60 * 1000));
	}
	
	@Override
	protected int doSeed(Random r, long startId, long endId) {
		int count = 0;
		for (long i = startId; i < endId; i++) {
			Date txnDate = utils.getDate(r, -this.timeToLiveDays, 0, false);
			Date now = new Date();
			ClientHydratedTransaction transaction = createTransaction(r, accountIdMapper, cardIdMapper, merchantIdMapper, terminalIdMapper, acctNumAndCodeMapper, properties, txnDate, i);
			DatabaseKey key = new DatabaseKey(keySpace, "transactions", transaction.getExternalTransactionId());
			WriteOptions options = new WriteOptions();
			options.setTimeToLive((int)((now.getTime() - txnDate.getTime()) / 1000));
			this.database.put(options, key, transactionMapper.toRecord(transaction));
			count++;
		}
		return count;
	}

	@Override
	public String getIdForLogicalId(long id) {
		return _getIdForLogicalId(id);
	}

}
