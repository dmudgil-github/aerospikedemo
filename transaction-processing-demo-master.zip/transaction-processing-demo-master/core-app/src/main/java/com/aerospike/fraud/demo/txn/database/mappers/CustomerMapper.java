package com.aerospike.fraud.demo.txn.database.mappers;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.aerospike.fraud.demo.txn.database.Column;
import com.aerospike.fraud.demo.txn.database.DataElement;
import com.aerospike.fraud.demo.txn.database.RecordData;
import com.aerospike.fraud.demo.txn.model.Account;
import com.aerospike.fraud.demo.txn.model.Customer;

public class CustomerMapper {
	public Customer fromRecord(RecordData record) {
		Customer result = null;
		if (record != null) {
			result = new Customer();
			result.setCustomerId(record.getString("id"));
			result.setFirstName(record.getString("firstName"));
			result.setLastName(record.getString("lastName"));
//			result.setPreferredSalutation(record.getString("greeting"));
			result.setAddress(record.getString("addr"));
			result.setCity(record.getString("city"));
			result.setPostCode(record.getString("postcode"));
			result.setJoinedBank(new Date(record.getLong("joined")));
			result.setNumAccounts(record.getInt("numAccounts"));
			List<String> accountIds = record.getList("accounts", String.class);
			String[] paddingStrings = new String[10];
			for (int i = 0; i < 10; i++) {
				String s = record.getString("padding" + i);
				if (s != null) {
					paddingStrings[i] = s;
				}
				else {
					break;
				}
			}
			result.setPadding(paddingStrings);
			if (accountIds == null) {
				accountIds = new ArrayList<String>();
			}
			List<Account> accounts = new ArrayList<Account>();
			for (String id: accountIds) {
				Account thisAccount = new Account();
				thisAccount.setNumber(id);
				accounts.add(thisAccount);
			}
			result.setAccounts(accounts);
		}
		return result;
	}
	
	public Column[] toRecord(Customer customer) {
		List<Column> elements = new ArrayList<Column>();
		elements.add(new Column("id", DataElement.get(customer.getCustomerId())));
		elements.add(new Column("firstName", DataElement.get(customer.getFirstName())));
		elements.add(new Column("lastName", DataElement.get(customer.getLastName())));
		elements.add(new Column("addr", DataElement.get(customer.getAddress())));
		elements.add(new Column("city", DataElement.get(customer.getCity())));
		elements.add(new Column("postcode", DataElement.get(customer.getPostCode())));
		elements.add(new Column("joined", DataElement.get(customer.getJoinedBank().getTime())));
		elements.add(new Column("numAccounts", DataElement.get(customer.getNumAccounts())));
		
		for (int i = 0; i < customer.getPadding().length; i++) {
			elements.add(new Column("padding" + i, DataElement.get(customer.getPadding()[i])));
		}

		return elements.toArray(new Column[0]);
	}
}
