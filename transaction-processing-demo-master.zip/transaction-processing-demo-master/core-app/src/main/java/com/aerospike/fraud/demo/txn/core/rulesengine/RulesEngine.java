package com.aerospike.fraud.demo.txn.core.rulesengine;

import com.aerospike.fraud.demo.txn.core.orchestrator.TxnFraudOrchestrator.FraudResult;
import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.model.ClientHydratedTransaction;
import com.aerospike.fraud.demo.txn.model.FraudFactsModel;

public interface RulesEngine {
	
	public static final int FAILURE_SCORE = 0;
	public static final int SUCCESS_SCORE = 1000;
	
	/**
	 * Process the data from the transaction. Return an integer representing the score.
	 * Assume 0 is a failure, 1000 is a guaranteed pass and numbers between this represent a range of scores with higher being better
	 * @param database
	 * @param keySpace
	 * @param transaction
	 * @param components
	 * @return
	 */
	int processData(Database database, String keySpace, ClientHydratedTransaction transaction, FraudFactsModel components, FraudResult result);
}
