package com.aerospike.fraud.demo.txn.database.mappers;

import java.util.ArrayList;
import java.util.List;

import com.aerospike.fraud.demo.txn.database.Column;
import com.aerospike.fraud.demo.txn.database.DataElement;
import com.aerospike.fraud.demo.txn.database.RecordData;
import com.aerospike.fraud.demo.txn.model.Country;

public class CountryMapper {
	public Country fromRecord(RecordData record) {
		return new Country(record.getString("code"), record.getString("name"), record.getString("language"));
	}
	
	public Column[] toRecord(Country country) {
		List<Column> elements = new ArrayList<Column>();
		elements.add(new Column("code", DataElement.get(country.getCountryCode())));
		elements.add(new Column("name", DataElement.get(country.getCountryName())));
		elements.add(new Column("language", DataElement.get(country.getLanguage())));
		return elements.toArray(new Column[0]);
	}
}

