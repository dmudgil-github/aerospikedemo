package com.aerospike.fraud.demo.txn.client;

import com.aerospike.fraud.demo.txn.model.ClientHydratedTransaction;

public interface Loader {
	boolean hasMoreRecords();
	ClientHydratedTransaction nextRecord();
}
