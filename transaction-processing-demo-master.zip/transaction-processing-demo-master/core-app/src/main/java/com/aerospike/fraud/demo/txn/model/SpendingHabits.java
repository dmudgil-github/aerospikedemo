package com.aerospike.fraud.demo.txn.model;

import java.util.HashMap;
import java.util.Map;

public class SpendingHabits {
	public static class SpendingHabit {
		private int count;
		private double amount;
		public int getCount() {
			return count;
		}
		public void setCount(int count) {
			this.count = count;
		}
		public double getAmount() {
			return amount;
		}
		public void setAmount(double amount) {
			this.amount = amount;
		}
		@Override
		public String toString() {
			return "{count:" + count + ",amount:" + amount +"}";
		}
	}
	private SpendingHabit total = new SpendingHabit();
	private Map<Integer, SpendingHabit> perAmountRange = new HashMap<Integer, SpendingHabit>();
	public SpendingHabit getTotal() {
		return total;
	}
	public void setTotal(SpendingHabit total) {
		this.total = total;
	}
	public Map<Integer, SpendingHabit> getPerAmountRange() {
		return perAmountRange;
	}
	public void setPerAmountRange(Map<Integer, SpendingHabit> perAmountRange) {
		this.perAmountRange = perAmountRange;
	}
	/**
	 * Return the actual spending habit for an amount range. This method cannot return null
	 * @param i
	 * @return
	 */
	public SpendingHabit getSpendingHabitForRange(int i) {
		SpendingHabit habit = this.perAmountRange.get(i);
		if (habit == null) {
			habit = new SpendingHabit();
			this.perAmountRange.put(i, habit);
		}
		return habit;
	}
	public void setSpendingHabitForRange(int i, SpendingHabit habit) {
		this.perAmountRange.put(i, habit);
	}
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("{Total:").append(this.total.toString());
		for (Integer key : perAmountRange.keySet()) {
			sb.append(" ").append(key).append(":").append(perAmountRange.get(key));
		}
		sb.append("}");
		
		return sb.toString();
	}
}
