package com.aerospike.fraud.demo.txn.database;

public class DatabaseKey {
	private String keyspace;
	private String table;
	private String id;
	public DatabaseKey(String keyspace, String table, String id) {
		super();
		this.keyspace = keyspace;
		this.table = table;
		this.id = id;
	}
	public String getKeyspace() {
		return keyspace;
	}
	public String getTable() {
		return table;
	}
	public String getId() {
		return id;
	}
}
