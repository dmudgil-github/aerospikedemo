package com.aerospike.fraud.demo.txn.model;

public class Country {
	private String countryCode;
	private String countryName;
	private String language;

	public Country(String countryCode, String countryName, String language) {
		super();
		this.countryCode = countryCode;
		this.countryName = countryName;
		this.language = language;
	}

	public String getCountryCode() {
		return countryCode;
	}
	public String getCountryName() {
		return countryName;
	}
	public String getLanguage() {
		return language;
	}
	
	@Override
	public String toString() {
		return this.countryCode + " [" + this.countryCode + "]";
	}
}

