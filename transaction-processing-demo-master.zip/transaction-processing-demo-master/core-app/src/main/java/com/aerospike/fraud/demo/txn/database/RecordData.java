package com.aerospike.fraud.demo.txn.database;

import java.util.List;

/**
 * This class is similar to a Record in Aerospike -- it contains the results of a select statement,
 * typically a map sorted by name
 * @author Tim
 *
 */
public interface RecordData {
	Object get(String columnName);
	String getString(String columnName);
	int getInt(String columnName);
	long getLong(String columnName);
	double getDouble(String string);
	<T> List<T> getList(String columnName, Class<T> clazz);
}
