package com.aerospike.fraud.demo.txn.core.orchestrator;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import com.aerospike.fraud.demo.txn.client.Control;
import com.aerospike.fraud.demo.txn.client.Loader;
import com.aerospike.fraud.demo.txn.client.OperationMode;
import com.aerospike.fraud.demo.txn.client.Statistics;
import com.aerospike.fraud.demo.txn.client.Statistics.OperationStatistics;
import com.aerospike.fraud.demo.txn.client.Statistics.StatisticsOptions;
import com.aerospike.fraud.demo.txn.core.machinelearning.MachineLearning;
import com.aerospike.fraud.demo.txn.core.rulesengine.RulesEngine;
import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.database.DatabaseKey;
import com.aerospike.fraud.demo.txn.database.RecordData;
import com.aerospike.fraud.demo.txn.eventpublisher.PostEventAggregator;
import com.aerospike.fraud.demo.txn.model.ClientHydratedTransaction;
import com.aerospike.fraud.demo.txn.model.FraudFactsModel;
import com.aerospike.fraud.demo.txn.model.LatencyStatsWrapper;
import com.aerospike.fraud.demo.txn.model.events.PostTxnEvent;
import com.aerospike.fraud.demo.txn.threadmanager.ThreadManager;
import com.aerospike.fraud.demo.txn.util.latency.LatencyManager;
import com.aerospike.fraud.demo.txn.util.latency.LatencyManager.TimingInfo;
import com.aerospike.fraud.demo.txn.util.logging.Logger;

public class TxnFraudOrchestrator {

	public enum FraudResult {
		WHITE_LISTED, BLACK_LISTED, OK, DATABASE_ISSUE, MISSING_DATA;

		public FraudResult merge(FraudResult newRes) {
			if (this == BLACK_LISTED || newRes == BLACK_LISTED) {
				return FraudResult.BLACK_LISTED;
			}
			else if (this == WHITE_LISTED || newRes == WHITE_LISTED) {
				return FraudResult.WHITE_LISTED;
			}
			else if (this == OK) {
				return newRes;
			}
			else if (newRes == OK) {
				return this;
			}
			else if (this == FraudResult.DATABASE_ISSUE || newRes == FraudResult.DATABASE_ISSUE) {
				return FraudResult.DATABASE_ISSUE;
			}
			else {
				return FraudResult.MISSING_DATA;
			}
		}
	};

	ExecutorService executor;
	private Loader loader;
	private Database database;
	private Logger logger;
	private String namespace;
	private RulesEngine rulesEngine;
	private MachineLearning machineLearning;

	private int nThreads;
	private LatencyManager latencyManager;
	private LatencyManager readLatencyManager;
	private LatencyManager writeLatencyManager;
	private LatencyManager batchLatencyManager;
//	private MerchantMapper merchantMapper = new MerchantMapper();
//	private AcctNumAndCodeMapper acctAndSCodeMapper = new AcctNumAndCodeMapper();
//	private AcctNumAndCodeSeeder acctAndSCodeSeeder = new AcctNumAndCodeSeeder(null, null, 0);
//	private TransactionMapper transactionMapper = new TransactionMapper();
//	private CreditCardMapper cardMapper = new CreditCardMapper();
//	private AccountMapper accountMapper = new AccountMapper();
//	private CustomerMapper customerMapper = new CustomerMapper();
//	private SpendingHabitsMapper spendingHabitsMapper = new SpendingHabitsMapper();
	private final CollectFactsConsumer collectFactsConsumer;
	private final Statistics statistics;
	private final LatencyStatsWrapper latencyStatsWrapper;
	private final OperationStatistics transactionStatistics;

	public TxnFraudOrchestrator(LatencyStatsWrapper latencyStatsWrapper, RulesEngine rulesEngine, MachineLearning machineLearning, int nThreads) {
		createStatistics();

		this.executor = Executors.newFixedThreadPool(nThreads * 5);
		this.rulesEngine = rulesEngine;
		this.machineLearning = machineLearning;
		this.latencyStatsWrapper = latencyStatsWrapper;
		this.nThreads = nThreads;

		this.loader = latencyStatsWrapper.getLoader();
		this.database = latencyStatsWrapper.getDatabase();
		this.namespace = latencyStatsWrapper.getNamespace();
		this.logger = latencyStatsWrapper.getLogger();
		this.latencyManager = latencyStatsWrapper.getLatencyManager();
		this.readLatencyManager = latencyStatsWrapper.getReadLatencyManager();
		this.writeLatencyManager = latencyStatsWrapper.getWriteLatencyManager();
		this.batchLatencyManager = latencyStatsWrapper.getBatchLatencyManager();
		this.statistics = latencyStatsWrapper.getStatistics();
		this.transactionStatistics = Statistics.getInstance().createStats(Statistics.PROCESS_TRANSACTION_STATS, StatisticsOptions.NONE);
		this.collectFactsConsumer = new CollectFactsConsumer(database, logger, namespace);
	}
	
	private void createStatistics() {
		Statistics.getInstance().createStats(Statistics.BLACK_LIST_STATS, StatisticsOptions.HIT_COUNT);
		Statistics.getInstance().createStats(Statistics.WHITE_LIST_STATS, StatisticsOptions.HIT_COUNT);
		Statistics.getInstance().createStats(Statistics.ACCT_CODE_STATS, StatisticsOptions.HIT_COUNT);
		Statistics.getInstance().createStats(Statistics.TXN_WRITE_STATS, StatisticsOptions.NONE);
		Statistics.getInstance().createStats(Statistics.MERCHANT_READ_STATS, StatisticsOptions.HIT_COUNT);
		Statistics.getInstance().createStats(Statistics.TERMINAL_READ_STATS, StatisticsOptions.NONE);
		Statistics.getInstance().createStats(Statistics.TERMINAL_HISTORY_READ_STATS, StatisticsOptions.SUB_OBJECT_COUNT);
		Statistics.getInstance().createStats(Statistics.TERMINAL_HISTORY_WRITE_STATS, StatisticsOptions.NONE);
		Statistics.getInstance().createStats(Statistics.SPENDING_HABITS_UPDATE_STATS, StatisticsOptions.NONE);
		Statistics.getInstance().createStats(Statistics.SPENDING_HABITS_READ_STATS, StatisticsOptions.SUB_OBJECT_COUNT);
		Statistics.getInstance().createStats(Statistics.CARD_READ_STATS, StatisticsOptions.HIT_COUNT);
		Statistics.getInstance().createStats(Statistics.CUSTOMER_READ_STATS, StatisticsOptions.HIT_COUNT);
		Statistics.getInstance().createStats(Statistics.ACCOUNT_READ_STATS, StatisticsOptions.HIT_COUNT);
		Statistics.getInstance().createStats(Statistics.STORE_READ_STATS, StatisticsOptions.NONE);
		Statistics.getInstance().createStats(Statistics.LOCATION_READ_STATS, StatisticsOptions.NONE);
		System.out.println("done stats create");
	}

	public void start() {

		ThreadManager tm = new ThreadManager(this);
		tm.startProcessing();
		while (true) {
			long time = System.currentTimeMillis();

			statistics.getPeriodBegin().set(time);
			
			this.latencyManager.printHeader(System.out);
			this.latencyManager.printResults(System.out, "Txns");
			this.readLatencyManager.printResults(System.out, "Reads");
			this.writeLatencyManager.printResults(System.out, "Writes");
			this.batchLatencyManager.printResults(System.out, "Batch");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// tm.cleanUp();

		// database.close();
	}

	/**
	 * Load data into the database
	 */
	public Loader getLoader() {
		return loader;
	}

	public void setLoader(Loader loader) {
		this.loader = loader;
	}

	public int getnThreads() {
		return nThreads;
	}

	public void setnThreads(int nThreads) {
		this.nThreads = nThreads;
	}
	
	public void processIncomingTransaction(ClientHydratedTransaction crntTxn) {
		try {
			if (Control.getInstance().getMode() == OperationMode.READONLY) {
				FraudFactsModel fraudFacts = new FraudFactsModel();
				
				TimingInfo data = latencyManager.beginMeasure();
				Long time = transactionStatistics.beginMeasure();
				// Do not need a result here...
				new CollectFactsSortCodeActNoXMerchant(crntTxn.getExternalTransactionId(), crntTxn.getMerchantName(), crntTxn.getAccountCode(), crntTxn.getS_code(), fraudFacts,latencyStatsWrapper).call();
				transactionStatistics.endMeasure(time);
				latencyManager.endMeasure(data);
			}
			else if (Control.getInstance().getMode() == OperationMode.MAINREADS) {
				FraudFactsModel fraudFacts = new FraudFactsModel();
				TimingInfo data = latencyManager.beginMeasure();
				Long time = transactionStatistics.beginMeasure();
				FraudResult result = FraudResult.OK;
				
				// Read the Account / Sort Codes
				result = result.merge(new CollectFactsSortCodeActNoXMerchant(crntTxn.getExternalTransactionId(), crntTxn.getMerchantName(), crntTxn.getAccountCode(), crntTxn.getS_code(), fraudFacts,latencyStatsWrapper).call());
				
				// Read the BlackList, WhiteList, Card, Account, Customer
				result = result.merge(collectFactsConsumer.collectCustomerAccountCardInfo(crntTxn.getExternalTransactionId(), crntTxn.getPan(), fraudFacts));

				transactionStatistics.endMeasure(time);
				latencyManager.endMeasure(data);
			}
			else {
				FraudResult result = FraudResult.OK;
	
				TimingInfo data = latencyManager.beginMeasure();
				Long time = transactionStatistics.beginMeasure();
	
				logger.log("%s: Received inbound transaction", crntTxn.getExternalTransactionId());
	
				FraudFactsModel fraudFacts = new FraudFactsModel();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd:hhmmss");
				Date txnDate = sdf.parse(crntTxn.getTransactionDate() + ":" + crntTxn.getTransactionTime());
	
				// Launch the Async tasks
				Future<FraudResult> merchantLoaderTask = null;
				if (crntTxn.getMerchantId() != null) {
					merchantLoaderTask = executor.submit(new CollectFactsMerchant(crntTxn.getExternalTransactionId(), crntTxn.getMerchantId(), fraudFacts, latencyStatsWrapper));
				}
				
				Future<FraudResult> terminalLoaderTask = null;
				if (crntTxn.getTerminalId() != null) {
					terminalLoaderTask = executor.submit(new CollectFactsTerminal(crntTxn.getExternalTransactionId(), crntTxn.getTerminalId(),
								crntTxn.getTerminalType(), txnDate, fraudFacts, latencyStatsWrapper));
				}
				
				Future<FraudResult> acctNumAndCodeTask = null;
				if (crntTxn.getAccountCode() != null && crntTxn.getMerchantName() != null && crntTxn.getS_code() != null) {
					acctNumAndCodeTask = executor.submit(new CollectFactsSortCodeActNoXMerchant(crntTxn.getExternalTransactionId(), crntTxn.getMerchantName(), crntTxn.getAccountCode(), crntTxn.getS_code(), fraudFacts,latencyStatsWrapper));
				}
	
				FraudResult customerResult = collectFactsConsumer.collectCustomerAccountCardInfo(crntTxn.getExternalTransactionId(), crntTxn.getPan(), fraudFacts);
				CollectFactsConsumerSpendingHabit collectFactsConsumerSpendingHabit = null;

				Future<FraudResult> spendingHabitsLoaderTask = null;
				// Load the consumer spending habits. This must be done AFTER the customer information is collected.
				if (fraudFacts.getCustomer() != null) {
					collectFactsConsumerSpendingHabit = new CollectFactsConsumerSpendingHabit(crntTxn.getExternalTransactionId(), fraudFacts.getCustomer().getCustomerId(), 
							crntTxn.getMerchantId(), crntTxn.getTerminalId(), fraudFacts,latencyStatsWrapper);
					
					spendingHabitsLoaderTask = executor.submit(collectFactsConsumerSpendingHabit);
				}
				
				if (customerResult != null) {
					result = result.merge(customerResult);
				}

				// Now sync back up with the async fraudFacts;
				try {
					if (merchantLoaderTask != null) {
						result = result.merge(merchantLoaderTask.get());
					}
					if (terminalLoaderTask != null) {
						result = result.merge(terminalLoaderTask.get());
					}
					result = result.merge(spendingHabitsLoaderTask.get());
					if (acctNumAndCodeTask != null) {
						result = result.merge(acctNumAndCodeTask.get());
					}
				} catch (InterruptedException | ExecutionException e) {
					result = result.merge(FraudResult.DATABASE_ISSUE);
				}
	
				int score = rulesEngine.processData(database, this.namespace, crntTxn, fraudFacts, result);
				logger.log("%s: rules engine returned %d", crntTxn.getExternalTransactionId(), score);
				machineLearning.processData(database, this.namespace, crntTxn, fraudFacts, score);
	
				latencyManager.endMeasure(data);
				transactionStatistics.endMeasure(time);
	
				// Now update the information for the next run. This is done async
				// and can take longer.
				PostTxnEvent postTxnEvent = new PostTxnEvent(crntTxn, fraudFacts,latencyStatsWrapper);
				executor.submit(new PostEventAggregator(postTxnEvent));
			}
		} catch (Exception e) {
			logger.log("Txn %s: exception thrown: %s", crntTxn.getExternalTransactionId(), e.getMessage());
			org.apache.log4j.Logger.getLogger(TxnFraudOrchestrator.class)
					.error("Txn " + crntTxn.getExternalTransactionId() + ": exception thrown: " + e.getMessage(), e);
		}
	}	
}
