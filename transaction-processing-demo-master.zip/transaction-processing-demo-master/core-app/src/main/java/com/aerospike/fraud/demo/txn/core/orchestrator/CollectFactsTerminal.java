package com.aerospike.fraud.demo.txn.core.orchestrator;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;

import com.aerospike.fraud.demo.txn.client.Statistics;
import com.aerospike.fraud.demo.txn.client.Statistics.OperationStatistics;
import com.aerospike.fraud.demo.txn.core.orchestrator.TxnFraudOrchestrator.FraudResult;
import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.database.DatabaseKey;
import com.aerospike.fraud.demo.txn.database.PreparedDatabaseStatement;
import com.aerospike.fraud.demo.txn.database.RecordData;
import com.aerospike.fraud.demo.txn.database.mappers.LocationMapper;
import com.aerospike.fraud.demo.txn.database.mappers.StoreMapper;
import com.aerospike.fraud.demo.txn.database.mappers.TerminalMapper;
import com.aerospike.fraud.demo.txn.model.FraudFactsModel;
import com.aerospike.fraud.demo.txn.model.HistoryEntry;
import com.aerospike.fraud.demo.txn.model.LatencyStatsWrapper;
import com.aerospike.fraud.demo.txn.model.Location;
import com.aerospike.fraud.demo.txn.model.Store;
import com.aerospike.fraud.demo.txn.model.Terminal;
import com.aerospike.fraud.demo.txn.util.logging.Logger;

class CollectFactsTerminal implements Callable<FraudResult> {

//	private class ProcessTerminal implements Callable<FraudResult> {
		private final String txnId;
		private final String terminalId;
		private final String terminalType;
		private final Date txnDate;
		private final FraudFactsModel fraudFacts;
		
		private Database database;
		private Logger logger;
		private String namespace;
		private final LatencyStatsWrapper latencyStatsWrapper;
		private final OperationStatistics terminalStats;
		private final OperationStatistics terminalHistoryStats;
		private final OperationStatistics storeStats;
		private final OperationStatistics locationStats;
		private final TerminalMapper terminalMapper;
		private final StoreMapper storeMapper;
		private final LocationMapper locationMapper;
		private static PreparedDatabaseStatement terminalsPreparedStatement = null;
		private static PreparedDatabaseStatement storesPreparedStatement = null;
		private static PreparedDatabaseStatement locationsPreparedStatement = null;

		public CollectFactsTerminal(String txnId, String terminalId, String terminalType, Date txnDate,
				FraudFactsModel fraudFacts, LatencyStatsWrapper latencyStatsWrapper) {
			super();
			this.txnId = txnId;
			this.terminalId = terminalId;
			this.terminalType = terminalType;
			this.txnDate = txnDate;
			this.fraudFacts = fraudFacts;
			
			this.latencyStatsWrapper = latencyStatsWrapper;
			this.logger = latencyStatsWrapper.getLogger();
			this.database = latencyStatsWrapper.getDatabase();
			this.namespace = latencyStatsWrapper.getNamespace();
			
			this.terminalHistoryStats = Statistics.getInstance().getStats(Statistics.TERMINAL_HISTORY_READ_STATS);
			this.terminalStats = Statistics.getInstance().getStats(Statistics.TERMINAL_READ_STATS);
			this.storeStats = Statistics.getInstance().getStats(Statistics.STORE_READ_STATS);
			this.locationStats = Statistics.getInstance().getStats(Statistics.LOCATION_READ_STATS);
			
			this.terminalMapper = new TerminalMapper();
			this.storeMapper = new StoreMapper();
			this.locationMapper = new LocationMapper();
			synchronized(CollectFactsTerminal.class) {
				if (terminalsPreparedStatement == null) {
					terminalsPreparedStatement = database.prepare("select id,locId,type,storeId from " + namespace + ".terminals where id = ?");
				}
				if (storesPreparedStatement == null) {
					storesPreparedStatement = database.prepare("select id,locId,type,storeId from " + namespace + ".terminals where id = ?");
				}
				if (locationsPreparedStatement == null) {
					locationsPreparedStatement = database.prepare("select id,locId,type,storeId from " + namespace + ".terminals where id = ?");
				}
			}

		}

		private FraudResult getTerminalDetails() {
			long time = terminalStats.beginMeasure();
			RecordData record = terminalsPreparedStatement.get(new DatabaseKey(namespace, "terminals", terminalId));
			terminalStats.endMeasure(time);
			if (record != null) {
				Terminal terminal = this.terminalMapper.fromRecord(record);
				fraudFacts.setTerminal(terminal);
				if (terminal.getStoreId() != null) {
					time = storeStats.beginMeasure();
					record = storesPreparedStatement.get(new DatabaseKey(namespace, "stores", terminal.getStoreId()));
					storeStats.endMeasure(time);
					if (record != null) {
						Store store = this.storeMapper.fromRecord(record);
						fraudFacts.setStore(store);
						if (store.getLocationId() != null) {
							time = locationStats.beginMeasure();
							record = locationsPreparedStatement.get(new DatabaseKey(namespace, "locations", store.getLocationId()));
							locationStats.endMeasure(time);
							Location location = this.locationMapper.fromRecord(record);
							fraudFacts.setLocation(location);
						}
					}
				}
			}
			return FraudResult.OK;
		}
		
		private FraudResult getTerminalHistory() {
			// Load all the transaction types done in the last 7 days. We want
			// to know:
			// Total number of refunds, quantity and count
			// Total number of transactions + quantity
			// Total number of transactions done each day within 1 hr of this
			// time, broken by transaction type, amount, refunds

			DatabaseKey[] keys = new DatabaseKey[7];
			GregorianCalendar cal = new GregorianCalendar();
			cal.setTime(txnDate);
			cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);
			Date[] keyDates = new Date[keys.length];
			for (int i = 0; i < keys.length; i++) {
				keyDates[i] = cal.getTime();
				keys[i] = new DatabaseKey(namespace, "terminalTxnDate",
						this.terminalId + ":" + cal.get(Calendar.YEAR) + cal.get(Calendar.DAY_OF_YEAR));
				cal.add(Calendar.HOUR, -24);
			}
			long time = terminalHistoryStats.beginMeasure();
			RecordData[] results = database.get(keys);
			terminalHistoryStats.endMeasure(time);
			terminalHistoryStats.addCount(keys.length);
			// Each crntTxn contains up to 24hours history, with bins having
			// names like HR0, HR1... HR23
			// The entries in the history list will be sorted chronologically
			// with oldest first.
			List<HistoryEntry> history = new ArrayList<HistoryEntry>();
			for (int i = 0; i < keys.length; i++) {
				if (results[i] != null) {
					for (int j = 23; j >= 0; j--) {
						String timeKey = "hr" + j;
						@SuppressWarnings("unchecked")
						Map<String, Object> hrResults = (Map<String, Object>) results[i].get(timeKey);
						if (hrResults != null) {
							HistoryEntry entry = new HistoryEntry(new Date(keyDates[i].getTime() + j * 3600 * 1000),
									new Date(keyDates[i].getTime() + (j + 1) * 3600 * 1000 - 1),
									((Long) hrResults.get("count")).intValue(), (double) hrResults.get("amount"),
									((Long) hrResults.get("refundCnt")).intValue(),
									(double) hrResults.get("refundAmt"));
							history.add(entry);
						}
					}
				}
			}
			fraudFacts.setTerminalHistory(history);
			return FraudResult.OK;
		}
		
		@Override
		public FraudResult call() throws Exception {
			if (terminalId == null) {
				// It is valid to have some inbound requests with no terminals
				return FraudResult.OK;
			}
			FraudResult result = getTerminalDetails();
			result.merge(this.getTerminalHistory());
			return result;
		}
	}


