package com.aerospike.fraud.demo.txn.database;

/**
 * This is the representation of a single value inside a record. The values are keyed by a name, similar to an Aerospike Bin
 * @author Tim
 *
 */
public class Column {
	private String name;
	private DataElement data;
	
	public Column(String name, DataElement data) {
		super();
		this.name = name;
		this.data = data;
	}

	public String getName() {
		return name;
	}

	public DataElement getData() {
		return data;
	}
}
