package com.aerospike.fraud.demo.txn.database;

import com.aerospike.fraud.demo.txn.util.logging.Logger;

public class DatabaseLogger extends Logger {
	private Database database; 
	private String keyspace;
	private String table;
	
	public DatabaseLogger(Database destination, String keyspace, String table) {
		this.database = destination;
		this.keyspace = keyspace;
		this.table = table;
	}
	
	@Override
	public void log(String value) {
		this.database.log(this.keyspace, this.table, value);
	}
}
