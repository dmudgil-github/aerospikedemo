package com.aerospike.fraud.demo.txn.database.aerospike;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.aerospike.client.AerospikeClient;
import com.aerospike.client.Bin;
import com.aerospike.client.Host;
import com.aerospike.client.Key;
import com.aerospike.client.Operation;
import com.aerospike.client.Record;
import com.aerospike.client.Value;
import com.aerospike.client.cdt.ListOperation;
import com.aerospike.client.cdt.MapOperation;
import com.aerospike.client.cdt.MapOrder;
import com.aerospike.client.cdt.MapPolicy;
import com.aerospike.client.cdt.MapWriteMode;
import com.aerospike.client.policy.RecordExistsAction;
import com.aerospike.client.policy.WritePolicy;
import com.aerospike.fraud.demo.txn.client.Control;
import com.aerospike.fraud.demo.txn.client.OperationMode;
import com.aerospike.fraud.demo.txn.database.Column;
import com.aerospike.fraud.demo.txn.database.DataElement;
import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.database.DatabaseKey;
import com.aerospike.fraud.demo.txn.database.PreparedDatabaseStatement;
import com.aerospike.fraud.demo.txn.database.RecordData;
import com.aerospike.fraud.demo.txn.database.WriteOptions;
import com.aerospike.fraud.demo.txn.util.latency.LatencyManager;
import com.aerospike.fraud.demo.txn.util.latency.LatencyManager.TimingInfo;

public class AerospikeDatabase implements Database {
	private AerospikeClient client;
	private long idValueRead = -1L;
	private long currentId = -1L;
	private static final long ID_COUNTS_TO_ALLOCATE = 10000;
	private LatencyManager readLatencyManager;
	private LatencyManager writeLatencyManager;
	private LatencyManager batchLatencyManager;
	
	public AerospikeDatabase(String host, int port, LatencyManager readLatencyManager, LatencyManager writeLatencyManager, LatencyManager batchLatencyManager) {
		client = new AerospikeClient(host, port);
		this.readLatencyManager = readLatencyManager;
		this.writeLatencyManager = writeLatencyManager;
		this.batchLatencyManager = batchLatencyManager;
	}
	
	public AerospikeDatabase(String[] hosts) {
		List<Host> theseHosts = new ArrayList<Host>();
		for (String thisHost: hosts) {
			theseHosts.add(new Host(thisHost, 3000));
		}
		client = new AerospikeClient(null, theseHosts.toArray(new Host[0]));
	}
	
	Value mapToValue(DataElement element) {
		return Value.get(element.getObject());
	}

	@Override
	public RecordData get(DatabaseKey key) {
		Key asKey = new Key(key.getKeyspace(), key.getTable(), key.getId());
		TimingInfo info = readLatencyManager.beginMeasure();
		Record result = client.get(null, asKey);
		readLatencyManager.endMeasure(info);
		return result == null ? null : new AerospikeRecord(result);
	}
	
	@Override
	public RecordData get(DatabaseKey key, String... columns) {
		Key asKey = new Key(key.getKeyspace(), key.getTable(), key.getId());
		TimingInfo info = readLatencyManager.beginMeasure();
		Record result = client.get(null, asKey, columns);
		readLatencyManager.endMeasure(info);
		return result == null ? null : new AerospikeRecord(result);
	}

	@Override
	public RecordData[] get(DatabaseKey[] keys) {
		Key[] asKeys = new Key[keys.length];
		for (int i = 0; i < keys.length; i++) {
			asKeys[i] = new Key(keys[i].getKeyspace(), keys[i].getTable(), keys[i].getId());
		}
		TimingInfo info = batchLatencyManager.beginMeasure();
		Record[] asResults = client.get(null, asKeys);
		batchLatencyManager.endMeasure(info);
		RecordData[] results = new RecordData[keys.length];
		for (int i = 0; i < keys.length; i++) {
			results[i] = asResults[i] == null ? null : new AerospikeRecord(asResults[i]);
		}
		return results;
	}

	@Override
	public RecordData[] get(DatabaseKey[] keys, String ... columns) {
		Key[] asKeys = new Key[keys.length];
		for (int i = 0; i < keys.length; i++) {
			asKeys[i] = new Key(keys[i].getKeyspace(), keys[i].getTable(), keys[i].getId());
		}
		TimingInfo info = batchLatencyManager.beginMeasure();
		Record[] asResults = client.get(null, asKeys, columns);
		batchLatencyManager.endMeasure(info);
		RecordData[] results = new RecordData[keys.length];
		for (int i = 0; i < keys.length; i++) {
			results[i] = asResults[i] == null ? null : new AerospikeRecord(asResults[i]);
		}
		return results;
	}

	@Override
	public PreparedDatabaseStatement prepare(String statement) {
		// There is no "prepare" style semantics in Aerospike, just pass it through to the driver.
		return new AerospikePreparedStatement(this);
	}

	@Override
	public void put(WriteOptions options, DatabaseKey key, Column... elements) {
		Bin[] bins = new Bin[elements.length];
		for (int i = 0; i < elements.length; i++) {
			Column thisElement = elements[i];
			bins[i] = new Bin(thisElement.getName(), mapToValue(thisElement.getData()));
		}

		WritePolicy wp = new WritePolicy();
		wp.recordExistsAction = (options != null && options.replaceExistingData() == false) ? RecordExistsAction.UPDATE : RecordExistsAction.REPLACE;
		if (options != null && options.getTimeToLive() > 0) {
			wp.expiration = options.getTimeToLive();
		}
		TimingInfo info = writeLatencyManager.beginMeasure();
		client.put(wp, new Key(key.getKeyspace(), key.getTable(), key.getId()), bins);
		writeLatencyManager.endMeasure(info);
	}

	private Key getCounterKey(String keyspace) {
		return new Key(keyspace, "ids", "logMessages");
	}
	
	private synchronized long getUniqueId(String keySpace) {
		if (currentId < 0 || idValueRead < 0 || (currentId - idValueRead) >= ID_COUNTS_TO_ALLOCATE) {
			// Fetch the next block from the database
			Record result = client.operate(null, getCounterKey(keySpace), 
					Operation.get("counter"),
					Operation.add(new Bin("counter", ID_COUNTS_TO_ALLOCATE))	
			);
			idValueRead = result.getLong("counter");
			currentId = idValueRead;
		}
		return currentId++;
	}
	
	public void log(String keySpace, String table, String log) {
		Bin date = new Bin("date", new Date().getTime());
		Bin message = new Bin("message", log);
		
		long id = getUniqueId(keySpace);
		Bin idBin = new Bin("id", id);
		TimingInfo info = writeLatencyManager.beginMeasure();
		client.put(null, new Key(keySpace, table, id), idBin, date, message);
		writeLatencyManager.endMeasure(info);
	}
	
	/**
	 * Close the connection to the underlying database.
	 */
	@Override
	public void close() {
		client.close();
	}

	@Override
	public void dropTable(String keySpace, String table) {
		client.truncate(null, keySpace, table, null);
	}

	@Override
	public void runDdlCommand(String command) {
		// Aerospike does not prepare DDL commands, so this is a no-op.
	}

	@Override
	public void addIdToList(DatabaseKey databaseKey, String column, String id, String counter) {
		// Cassandra cannot implement this method.
		if (Control.getInstance().getMode() == OperationMode.FULL) {
			Operation[] ops;
			Key key = new Key(databaseKey.getKeyspace(), databaseKey.getTable(), databaseKey.getId());
			if (counter == null) {
				ops = new Operation[1];
			}
			else {
				ops = new Operation[2];
				ops[1] = Operation.add(new Bin(counter, 1));
			}
			ops[0] = ListOperation.append(column, Value.get(id));
			TimingInfo info = writeLatencyManager.beginMeasure();
			client.operate(null, key, ops);
			writeLatencyManager.endMeasure(info);
		}
	}

	@Override
	public void incrementMany(DatabaseKey databaseKey, String binName, Column... columns) {
		// Cassandra cannot implement this method.
		if (Control.getInstance().getMode() == OperationMode.FULL) {
			Operation[] ops = new Operation[columns.length+1];
			Key key = new Key(databaseKey.getKeyspace(), databaseKey.getTable(), databaseKey.getId());
			MapPolicy mp = new MapPolicy(MapOrder.KEY_ORDERED, MapWriteMode.UPDATE);
			for (int i = 0; i < columns.length; i++) {
				ops[i] = MapOperation.increment(mp, binName, Value.get(columns[i].getName()), mapToValue(columns[i].getData()));
			}
			// Also insert an "id" for the name of this record if it doesn't exist
			ops[columns.length] = Operation.put(new Bin("id", databaseKey.getId()));
			TimingInfo info = writeLatencyManager.beginMeasure();
			client.operate(null, key, ops);
			writeLatencyManager.endMeasure(info);
		}
	}
	
	@Override
	public void incrementMany(DatabaseKey databaseKey, Column... columns) {
		// Cassandra cannot implement this method.
		if (Control.getInstance().getMode() == OperationMode.FULL) {
			Operation[] ops = new Operation[columns.length+1];
			Key key = new Key(databaseKey.getKeyspace(), databaseKey.getTable(), databaseKey.getId());
			for (int i = 0; i < columns.length; i++) {
				ops[i] = Operation.add(new Bin(columns[i].getName(), mapToValue(columns[i].getData())));
			}
			// Also insert an "id" for the name of this record if it doesn't exist
			ops[columns.length] = Operation.put(new Bin("id", databaseKey.getId()));
			TimingInfo info = writeLatencyManager.beginMeasure();
			client.operate(null, key, ops);
			writeLatencyManager.endMeasure(info);
		}
	}

	@Override
	public RecordData get(DatabaseKey key, PreparedDatabaseStatement stmt) {
		TimingInfo info = readLatencyManager.beginMeasure();
		RecordData record = stmt.get(key);
		readLatencyManager.endMeasure(info);
		return record;
	}
}
