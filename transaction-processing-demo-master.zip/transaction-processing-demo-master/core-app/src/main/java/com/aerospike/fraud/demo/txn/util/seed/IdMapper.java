package com.aerospike.fraud.demo.txn.util.seed;

public interface IdMapper<T> {
	String getIdForLogicalId(long id);
}
