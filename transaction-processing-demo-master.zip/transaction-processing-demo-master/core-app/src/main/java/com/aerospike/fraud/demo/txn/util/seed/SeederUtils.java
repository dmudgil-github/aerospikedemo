package com.aerospike.fraud.demo.txn.util.seed;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Random;
import java.util.concurrent.TimeUnit;

/**
 * Helper class to generate data
 * @author Tim
 *
 */
public class SeederUtils {
//	private static final String LOWER_LETTERS = "abcdefghijklmnopqrstuvwxyz";
//	private static final String UPPER_LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
//	private static final String NUMBERS = "0123456789";
//	private static final String ALPHABET = LOWER_LETTERS + UPPER_LETTERS;
//	private static final String ALPHA_NUM = ALPHABET + NUMBERS;
	
	public static enum Alphabet {
		LOWER_LETTERS("abcdefghijklmnopqrstuvwxyz"),
		UPPER_LETTERS("ABCDEFGHIJKLMNOPQRSTUVWXYZ"),
		NUMBERS("0123456789"),
		ALPHABET(LOWER_LETTERS.getMembers() + UPPER_LETTERS.getMembers()),
		ALPHA_NUM_UPPER(UPPER_LETTERS.getMembers() + NUMBERS.getMembers()),
		ALPHA_NUM(ALPHABET.getMembers() + NUMBERS.getMembers());
		
		private final String members;
		private Alphabet(String s) {
			this.members = s;
		}
		
		public String getMembers() {
			return members;
		}
	};
	
	private static final String[] FIRST_NAMES = {
			"Albert",
			"Alfred",
			"Catherine",
			"Cindy",
			"James",
			"Jessica",
			"Michael",
			"Michelle",
			"Rachel",
			"Stephen",
			"Valerie",
			"Wendy",
			"Wilma",
			"Zeta"
	};
	
	private static final String[] LAST_NAMES = {
			"Beagley",
			"Brown",
			"Emery",
			"Fox",
			"Grossman",
			"Hague",
			"Jones",
			"Kim",
			"Park",
			"Queen",
			"Reacher",
			"Smith"
	};
	
	private static final String[] CITY_NAMES = {
		"London",
		"Detroit",
		"Maine",
		"Northampton",
		"Dover",
		"Peterborough",
		"Milton Keynes"
	};
	
	public String getFirstName(Random r) {
		int index = r.nextInt(FIRST_NAMES.length);
		return FIRST_NAMES[index];
	}
	
	public String getLastName(Random r) {
		int index = r.nextInt(LAST_NAMES.length);
		return LAST_NAMES[index];
	}
	
	public String getAddress(Random r) {
		return r.nextInt(2000) + " " + getFirstName(r) + " St";
	}
	public String getCity(Random r) {
		return CITY_NAMES[r.nextInt(CITY_NAMES.length)];
	}
	
	public String getName(Random r) {
		return getFirstName(r) + " " + getLastName(r);
	}
	
	public String getNumber(Random r, int limit, int padding) {
		return formatNumber(r.nextInt(limit), padding);
	}
	public String formatNumber(long n, int padding) {
		return formatNumber(n, padding, 1, 0);
	}
	
	public String formatNumber(long n, int padding, long multiplier, long offset) {
		long number = offset + n * multiplier;
		if (padding > 0) {
			String format = "%0" + padding + "d";
			return String.format(format, number);
		}
		else {
			return Long.toString(number);
		}
	}
	
	public String getString(Random r, int length, Alphabet alphabet) {
		StringBuilder sb = new StringBuilder(length);
		String s = alphabet.getMembers();
		int len = s.length();
		for (int i = 0; i < length; i++) {
			sb.append(s.charAt(r.nextInt(len)));
		}
		return sb.toString();
	}
	
	/**
	 * Distribute a set of values over the given percentages. The return value is an integer in the range
	 * 0 .. percentages.length()-1, which indicates which range the next random number falls into.
	 * <pre>
	 * 		SeederUtils u = new SeederUtils();
	 * 		int a = 0, b = 0, c= 0;
	 * 		for (int i = 0; i < 10000; i++) {
	 * 			switch(u.distribute(random, 80,15,5)) {
	 * 			case 0: a++; break;
	 * 			case 1: b++; break;
	 * 			case 2: c++; break;
	 * 			}
	 * 		}
	 * 		System.out.printf("a = %d, b = %d, c = %d\n", a, b, c);
	 * </pre>
	 * 
	 * Should output something similar to:
	 * a = 8025, b = 1482, c = 493
	 * 
	 * @param r
	 * @param percentages
	 * @return
	 */
	public int distribute(Random r, int ... percentages) {
		int sum = 0;
		for (int i = 0; i < percentages.length; i++) {
			if (percentages[i] < 0) {
				throw new IllegalArgumentException("percentages must be > 0, not " + percentages[i]);
			}
			sum += percentages[i];
		}
		int next = r.nextInt(sum);
		int count = 0;
		for (int i = 0; i < percentages.length; i++) {
			count += percentages[i];
			if (next < count) {
				return i;
			}
		}
		// Cannot logically happen
		return -1;
	}
	
	/**
	 * Return a random date within the specified date range. The offsets are relative to the current date
	 * so getDate(r, -30, -5, true) will return a date from 30 days ago to 5 days ago 
	 * @param r
	 * @param startDayOffset
	 * @param endDayOffset
	 * @param removeTimeComponent
	 * @return
	 */
	public Date getDate(Random r, int startDayOffset, int endDayOffset, boolean removeTimeComponent) {
		Date currentDate = new Date();
		if (removeTimeComponent) {
			Calendar cal = new GregorianCalendar();
			cal.setTime(currentDate);
			cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);
			currentDate = cal.getTime();
		}
		long now = currentDate.getTime();
		long start = now + TimeUnit.MILLISECONDS.convert(startDayOffset, TimeUnit.DAYS);
		long end = now + TimeUnit.MILLISECONDS.convert(endDayOffset, TimeUnit.DAYS);
		if (end < start) {
			long temp = start;
			start = end;
			end = temp;
		}
		if (end == start) {
			return new Date(start);
		}
		long diff = end - start;
		long next = r.nextLong();
		if (next < 0) {
			next = next + Long.MAX_VALUE;
		}
		return new Date(start + (next%diff) );
	}

	public String getCompanyName(Random r) {
		return getName(r) + " & Co";
	}
	
	public String[] generateString(Random r, int numberOfStrings, int totalLength) {
		String[] results = new String[numberOfStrings];
		int lengthRemaining = totalLength;
		for (int i = 0; i < numberOfStrings; i++) {
			int chars;
			if (i == numberOfStrings -1) {
				chars = lengthRemaining;
			}
			else {
				chars = 1 + r.nextInt(lengthRemaining - (numberOfStrings-i));
			}
			results[i] = getString(r, chars, Alphabet.LOWER_LETTERS);
		}
		return results;
	}

}
