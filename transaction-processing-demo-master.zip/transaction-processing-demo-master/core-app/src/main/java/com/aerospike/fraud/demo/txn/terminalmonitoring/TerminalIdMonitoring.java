package com.aerospike.fraud.demo.txn.terminalmonitoring;

import com.aerospike.fraud.demo.txn.database.Database;

public interface TerminalIdMonitoring {
	
	/*
	 * Thinking about using the terminal ID as the key, each transaction type will be a map element with a count associated with a txn type
	 */
	public void addNewTransaction( Database database, String keyspace, String termId, String txnType);
	public void printTransactionStatsByID( Database database, String keyspace, String txnType );
}
