package com.aerospike.fraud.demo.txn.util.seed;

import java.util.Date;
import java.util.Random;

import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.database.DatabaseKey;
import com.aerospike.fraud.demo.txn.database.mappers.AccountMapper;
import com.aerospike.fraud.demo.txn.model.Account;
import com.aerospike.fraud.demo.txn.model.Customer;

public class AccountSeeder extends Seeder implements IdMapper<Account> {
	private final Database database;
	private final String keySpace;
	private final int numCustomers;
	private final AccountMapper mapper = new AccountMapper();
	private final IdMapper<Customer> customerIdMapper;
	private static final SeederUtils utils = new SeederUtils();
	
	
	public AccountSeeder(Database database, String keySpace, int numCustomers, IdMapper<Customer> customerIdMapper) {
		super("Accounts");
		this.database = database;
		this.keySpace = keySpace;
		this.numCustomers = numCustomers;
		this.customerIdMapper = customerIdMapper;
	}
	
	private Account generateAccount(Random r, long id) {
		Account account = new Account();
		
		// The id must be repeatable so it can be referenced later
		account.setNumber(getIdForLogicalId(id));
		// Make the expiration to be future dated except for a handful.
		Date dateOpened = utils.getDate(r, -1500, +1, false);
		account.setDateOpened(dateOpened);
		account.setNameOnAccount(utils.getName(r));
		account.setCustomerId(customerIdMapper.getIdForLogicalId(r.nextInt(this.numCustomers)));

		// Pad the records so they're around 1.5k - 2k
		int bytesRemaining = 1400 + r.nextInt(500);
		String[] paddingStrings = utils.generateString(r, 10, bytesRemaining);
		account.setPadding(paddingStrings);
		
		return account;
	}
	
	@Override
	protected int doSeed(Random r, long startId, long endId) {
		int count = 0;
		for (long i = startId; i < endId; i++) {
			Account account = generateAccount(r, i);
			DatabaseKey key = new DatabaseKey(keySpace, "accounts", account.getNumber());
			this.database.put(null, key, mapper.toRecord(account));
			
			// Now we need to update the customer to have an updated count and references to the account.
			DatabaseKey customerKey = new DatabaseKey(keySpace, "customers", account.getCustomerId());
			database.addIdToList(customerKey, "accounts", account.getNumber(), "numAccounts");
			count++;
		}
		return count;
	}

	@Override
	public String getIdForLogicalId(long id) {
		return "2" + utils.formatNumber(id, 8, 9, 2751241);
	}
}
