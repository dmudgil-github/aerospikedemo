package com.aerospike.fraud.demo.txn.database;

public abstract class Options {

}
