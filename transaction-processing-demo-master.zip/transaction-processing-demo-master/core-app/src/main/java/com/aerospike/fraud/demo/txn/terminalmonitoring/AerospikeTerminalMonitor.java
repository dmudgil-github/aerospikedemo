package com.aerospike.fraud.demo.txn.terminalmonitoring;



import java.util.HashMap;

import com.aerospike.fraud.demo.txn.database.Column;
import com.aerospike.fraud.demo.txn.database.DataElement;
import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.database.DatabaseKey;
import com.aerospike.fraud.demo.txn.database.RecordData;



public class AerospikeTerminalMonitor implements TerminalIdMonitoring {

	@Override
	public void addNewTransaction(Database database, String keySpace, String termId, String txnType) {
		DatabaseKey txnKey = new DatabaseKey (keySpace, "terminalmon", termId);
		RecordData record = database.get(txnKey);
		if ( record == null ){
			/*
			 * If the terminal ID does not exist, create it
			 */
			HashMap mapElt = new HashMap<Object,Object>();
			
			//List<Column> elements = new ArrayList<Column>();
			//elements.add(new Column("type", DataElement.get(txn.getRecordType())));
			mapElt.put(txnType, 1);
			
			Column[] cols = new Column[1];
			cols[0] = new Column("txnType", DataElement.get(mapElt));
			database.put(null, txnKey, cols);
		}
		else {
			/*
			 * if it exists increment the existing txnType or create a new map element
			 */
		}

	}

	@Override
	public void printTransactionStatsByID(Database database, String keySpace, String txnType) {
		// TODO Auto-generated method stub

	}

}
