package com.aerospike.fraud.demo.txn.util.seed;

import java.util.Random;

public abstract class Seeder {
	private final String objectName;
	public Seeder(String objectName) {
		this.objectName = objectName;
	}
	public abstract String getIdForLogicalId(long id);
	protected abstract int doSeed(Random random, long startId, long endId);
	
	public long seed(Random r, long startId, long endId, boolean silent) {
		if (!silent) {
			System.out.printf("Creating %s: ", objectName);
		}
		long now = System.nanoTime();
		
		// Do the actual work.
		long numCreated = this.doSeed(r, startId, endId);
		
		if (!silent) {
			long diff = System.nanoTime() - now;
			System.out.printf("%d created in %dms\n", numCreated, diff / 1000000L);
		}
		return numCreated;
	}
	
	public String getName() {
		return this.objectName;
	}
}
