package com.aerospike.fraud.demo.txn.database;

public interface Database {

	/**
	 * Prepare a statement for later execution
	 * @param statement
	 * @return
	 */
	PreparedDatabaseStatement prepare(String statement);
	
	/**
	 * Remove the table and all the data in it.
	 * @param keySpace
	 * @param table
	 */
	void dropTable(String keySpace, String table);
	
	/**
	 * Execute some arbitrary DDL
	 * @param command
	 */
	void runDdlCommand(String command);
	
	/**
	 * Put information into the database. The record is identified by the key
	 * @param key
	 * @param elements
	 */
	void put(WriteOptions options, DatabaseKey key, Column ... elements);
	
	/**
	 * Return all columns in a database record, identified by the key
	 * @param key - the primary key of the record
	 * @return the data matching that record
	 */
	RecordData get(DatabaseKey key);
	/**
	 * Return selected columns in a database record, identified by the key
	 * @param key - the primary key of the record
	 * @param columns - the names of the columns to return
	 * @return the data matching that record
	 */
	RecordData get(DatabaseKey key, String ... columns);

	/**
	 * Return specified columns in a database records, identified by the keys, in the same
	 * order as the passed keys. If a key is not found, null will be in the corresponding location in the output array 
	 * @param key - the primary key of the record
	 * @return the data matching that record
	 */
	RecordData[] get(DatabaseKey[] key, String ... columns);

	/**
	 * Return all columns in a database records, identified by the keys, in the same
	 * order as the passed keys. If a key is not found, null will be in the corresponding location in the output array 
	 * @param key - the primary key of the record
	 * @return the data matching that record
	 */
	RecordData[] get(DatabaseKey[] key);

	/**
	 * Get a unique number which can be used as an id, given a "counter record"
	 * @param idGenerationKey
	 * @return
	 */
	//String getUniqueId(DatabaseKey idGenerationKey);
	
	/**
	 * Log a command to the underlying data store
	 * @param log
	 */
	void log(String keySpace, String table, String log);
	
	/**
	 * Add an id to the list in the column specified by a parameter. Does not 
	 * necessarily de-dup the list. If counter is specified, the column speficied
	 * in the counter parameter is incremented as part of this operation.
	 */
	void addIdToList(DatabaseKey key, String column, String id, String counter);
	
	/**
	 * Increment several keys in a map on the passed bin for the passed record.
	 * @param key
	 * @param binName
	 * @param columns
	 */
	void incrementMany(DatabaseKey key, String binName, Column ... columns);
	
	/**
	 * Increment several keys in a map on the passed bin for the passed record.
	 * @param key
	 * @param binName
	 * @param columns
	 */
	void incrementMany(DatabaseKey key, Column ... columns);
	
	/**
	 * Close the connection to the underlying database.
	 */
	void close();

	RecordData get(DatabaseKey key, PreparedDatabaseStatement stmt);
	
}
