package com.aerospike.fraud.demo.txn.util.latency;

import java.io.PrintStream;

public class NullLatencyManager implements LatencyManager {

	@Override
	public void add(long elapsed) {
	}

	@Override
	public void printHeader(PrintStream stream) {
	}

	@Override
	public void printResults(PrintStream stream, String prefix) {
	}

	@Override
	public TimingInfo beginMeasure() {
		return null;
	}

	@Override
	public void endMeasure(TimingInfo info) {
	}
}
