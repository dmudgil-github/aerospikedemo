package com.aerospike.fraud.demo.txn.util.seed;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.util.configuration.PropertiesManager;
import com.aerospike.fraud.demo.txn.util.configuration.PropertyNames;

/**
 * This class is designed to seed data into the database. It is designed to be multithreaded
 * @author Tim
 *
 */
public class ProgramDataSeeder {
	private final Random random;
	private final String keySpace;
	private final Database database;
	private final int numThreads;
	private final int nodeId;
	private final ExecutorService executor;
	private final PropertiesManager properties;
	
	private final MerchantSeeder merchantSeeder;
	private final CreditCardSeeder cardSeeder;
	private final AccountSeeder accountSeeder;
	private final CustomerSeeder customerSeeder;
	private final LocationSeeder locationSeeder;
	private final StoreSeeder storeSeeder;
	private final TerminalSeeder terminalSeeder;
	private final TerminalHistorySeeder terminalHistorySeeder;
	private final InboundTransactionSeeder transactionSeeder;
	private final SpendingHabitsSeeder spendingHabitsSeeder;
	private final BlackListedCardSeeder blackListedCardSeeder;
	private final WhiteListedCardSeeder whiteListedCardSeeder;
	private final AcctNumAndCodeSeeder acctNumAndCodeSeeder;
	
	private final static Logger log = Logger.getLogger(ProgramDataSeeder.class); 
	
	public ProgramDataSeeder(Database database, String keySpace, int nodeId, int numThreads, long randomSeed, PropertiesManager properties) {
		super();
		log.info("Starting seeder node with " + numThreads + " threads");
		this.keySpace = keySpace;
		this.database = database;
		this.numThreads = numThreads;
		this.random = new Random(randomSeed);
		this.executor = Executors.newFixedThreadPool(numThreads);
		this.properties = properties;
		this.nodeId = nodeId;
		
		this.merchantSeeder = new MerchantSeeder(database, keySpace);
		this.locationSeeder = new LocationSeeder(database, keySpace);
		this.storeSeeder = new StoreSeeder(database, keySpace, this.properties.getInt(PropertyNames.LOCATIONS_CNT), locationSeeder);
		this.terminalSeeder = new TerminalSeeder(database, keySpace, this.properties.getInt(PropertyNames.TERMINALS_CNT), locationSeeder, this.properties.getInt(PropertyNames.STORES_CNT), storeSeeder);
		this.customerSeeder = new CustomerSeeder(database, keySpace, properties.getPercentage(PropertyNames.CUSTOMER_VIP_PCT));
		this.accountSeeder = new AccountSeeder(database, keySpace, properties.getInt(PropertyNames.CUSTOMER_CNT), this.customerSeeder);
		this.terminalHistorySeeder = new TerminalHistorySeeder(database, keySpace, properties.getPercentage(PropertyNames.TERMIANALS_REFUND_PCT), properties.getPercentage(PropertyNames.TERMINALS_FRAUD_PCT), properties.getInt(PropertyNames.TERMINAL_HISTORY_ENTRY_CNT),this.terminalSeeder);
		this.cardSeeder = new CreditCardSeeder(database, keySpace, properties.getInt(PropertyNames.ACCOUNTS_CNT), accountSeeder);
		this.blackListedCardSeeder = new BlackListedCardSeeder(database, keySpace, cardSeeder, this.properties.getInt(PropertyNames.CARDS_CNT));
		this.whiteListedCardSeeder = new WhiteListedCardSeeder(database, keySpace, cardSeeder, this.properties.getInt(PropertyNames.CARDS_CNT));
		this.acctNumAndCodeSeeder = new AcctNumAndCodeSeeder(database, keySpace, properties.getInt(PropertyNames.MERCHANTS_CNT));
		
		String ttl = properties.getString(PropertyNames.SPEND_HABITS_TTL).trim();
		long multiplier = 1L;
		if (ttl.endsWith("d")) {
			multiplier = TimeUnit.DAYS.toMillis(1);
		}
		else if (ttl.endsWith("h")) {
			multiplier = TimeUnit.HOURS.toMillis(1);
		}
		else if (ttl.endsWith("y")) {
			multiplier = TimeUnit.DAYS.toMillis(365);
		}
		if (multiplier > 1) {
			ttl = ttl.substring(0, ttl.length()-1);
		}
		long durationInMs = Long.valueOf(ttl) * multiplier;
		this.spendingHabitsSeeder = new SpendingHabitsSeeder(database, keySpace, customerSeeder, merchantSeeder, terminalSeeder, properties.getInt(PropertyNames.SPEND_HABITS_MAX_TXNS), durationInMs, properties.getInt(PropertyNames.TERMINALS_CNT), properties.getInt(PropertyNames.MERCHANTS_CNT));
		this.transactionSeeder = new InboundTransactionSeeder(database, keySpace, customerSeeder, accountSeeder, cardSeeder, merchantSeeder, terminalSeeder, acctNumAndCodeSeeder, properties, durationInMs);
	}
	
	private void seedAccounts() {
		startSeeding(accountSeeder, 0, properties.getInt(PropertyNames.ACCOUNTS_CNT), true);
	}
	
	private void seedBlackListedCards() {
		int knownCardCount = this.properties.getInt(PropertyNames.BLACKLIST_KNOWN_CNT);
		blackListedCardSeeder.setKnownCards(true);
		startSeeding(blackListedCardSeeder, 0, knownCardCount, true);
		blackListedCardSeeder.setKnownCards(false);
		startSeeding(blackListedCardSeeder, 0, this.properties.getInt(PropertyNames.BLACKLIST_TOTAL_CNT) - knownCardCount, true);
	}
	
	private void seedCountries() {
		new CountrySeeder(database, keySpace).seed(this.random, 0, 0, false);
	}
	
	private void seedCreditCards() {
		startSeeding(cardSeeder, 0, properties.getInt(PropertyNames.CARDS_CNT), true);
	}
	
	private void seedCustomers() {
		startSeeding(customerSeeder, 0, properties.getInt(PropertyNames.CUSTOMER_CNT), true);
	}
	
	private void seedLocations() {
		startSeeding(locationSeeder, 0, properties.getInt(PropertyNames.LOCATIONS_CNT), true);
	}
	
	private void seedMerchants() {
		startSeeding(merchantSeeder, 0, properties.getInt(PropertyNames.MERCHANTS_CNT), true);
	}
	
	private void seedSpendingHabits() {
		startSeeding(spendingHabitsSeeder, 0, properties.getInt(PropertyNames.CUSTOMER_CNT), true);
	}
	
	private void seedStores() {
		startSeeding(storeSeeder, 0, properties.getInt(PropertyNames.STORES_CNT), true);
	}
	
	private void seedTerminals() {
		startSeeding(terminalSeeder, 0, properties.getInt(PropertyNames.TERMINALS_CNT), true);
	}
	
	private void seedTerminalHistory() {
		startSeeding(terminalHistorySeeder, 0, properties.getInt(PropertyNames.TERMINALS_CNT), true);
	}
	
	private void seedTransactions() {
		startSeeding(transactionSeeder, 0, properties.getInt(PropertyNames.EXISTING_TXNS_CNT), true);
	}
	
	private void seedWhiteListedCards() {
		int knownCardCount = this.properties.getInt(PropertyNames.WHITELIST_KNOWN_CNT);
		whiteListedCardSeeder.setKnownCards(true);
		startSeeding(whiteListedCardSeeder, 0, knownCardCount, true);
		whiteListedCardSeeder.setKnownCards(false);
		startSeeding(whiteListedCardSeeder, 0, this.properties.getInt(PropertyNames.WHITELIST_TOTAL_CNT) - knownCardCount, true);
	}
	
	private void seedAcctNumAndCodes() {
		long knownCodeCount = this.properties.getLong(PropertyNames.S_CODES_KNOWN_CNT);
		acctNumAndCodeSeeder.setKnownCodes(true);
		startSeeding(acctNumAndCodeSeeder, 0, knownCodeCount, true);
		acctNumAndCodeSeeder.setKnownCodes(false);
		startSeeding(acctNumAndCodeSeeder, 0, this.properties.getLong(PropertyNames.S_CODES_TOTAL_CNT) - knownCodeCount, true);
	}
		
	public void generate(Set<String> tables) {
		// Do the single-threaded ones first, but only on node 1 (to avoid conflicts)
		if (this.nodeId == 1) {
			if (tables.contains("countries"))
			this.seedCountries();
		}

		// Now the multithreaded ones
		if (tables.contains("merchants")) 			this.seedMerchants();
		if (tables.contains("customers")) 			this.seedCustomers();
		if (tables.contains("accounts")) 			this.seedAccounts();
		if (tables.contains("cards")) 				this.seedCreditCards();
		if (tables.contains("locations")) 			this.seedLocations();
		if (tables.contains("terminals")) 			this.seedTerminals();
		if (tables.contains("terminalTxnDate")) 	this.seedTerminalHistory();
		if (tables.contains("spendingHabits")) 		this.seedSpendingHabits();
		if (tables.contains("stores")) 				this.seedStores();
		if (tables.contains("blackListCards")) 		this.seedBlackListedCards();
		if (tables.contains("whiteListCards")) 		this.seedWhiteListedCards();
		if (tables.contains("transactions")) 		this.seedTransactions();
		if (tables.contains("accountNumAndCode")) 	this.seedAcctNumAndCodes();
				
		this.executor.shutdown();
		try {
			if ( !this.executor.awaitTermination(5, TimeUnit.MINUTES) ) {
				System.err.println("TransactionProcessorDataSeeder.generate() timed out");
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private int startSeeding(Seeder seeder, long start, long end, boolean waitTilComplete) {
		if (end < start) {
			return 0;
		}
		System.out.printf("Creating %s: ", seeder.getName());
		// Determine, based on this node number and the total node count, how much to actually generate
		int totalNodes = properties.getInt(PropertyNames.NODE_CNT);
		double perNodeRecordCounts = (end-start+0.4) / totalNodes;
		double startRecordCount = (this.nodeId-1) * perNodeRecordCounts;
		end = (long)(start+startRecordCount+perNodeRecordCounts);
		start = (long)(start + startRecordCount);

		long now = System.nanoTime();
		List<Future<Long>> futures = new ArrayList<Future<Long>>();
		if (numThreads <= 0) {
			futures.add(startSeeding(start, end, seeder));
		}
		else {
			long totalRecords = end - start;
			// Add an offset to prevent rounding errors causing a record to be skipped
			double recordsPerThread = (totalRecords+0.4) / numThreads;
			double rangeStart = start;

			int rangeEnd;
			do {
				rangeEnd = (int)(rangeStart + recordsPerThread);
				futures.add(startSeeding((int)rangeStart, rangeEnd, seeder));
				
				rangeStart += recordsPerThread;
				
			} while ( rangeEnd < end );
				
			// This should not happen, but just to make sure.
			if ( (int)rangeStart < rangeEnd ) {
				futures.add(startSeeding((int)rangeStart, end, seeder));
			}
		}
		int count = 0;
		StringBuffer sb = new StringBuffer();
		if (waitTilComplete) {
			sb.append("Per Thread:");
			for (Future<Long> thisFuture : futures) {
				try {
					long thisCount = thisFuture.get();
					count += thisCount;
					sb.append(" ").append(thisCount);
				}
				catch (Exception ee) {
					log.error("Exception raised seeding " + seeder.getName() + "(" + start + ", " + end +"): " + ee.getMessage(), ee);
				}
			}
		}
		long diff = System.nanoTime() - now;
		System.out.printf("%d created in %dms\t%s\n", count, diff / 1000000L, sb.toString());
		return count;
	}

	public Future<Long> startSeeding(final long start, final long end, Seeder seeder) {
	    return executor.submit(new Callable<Long>() {
	        @Override
	        public Long call() throws Exception {
	            long result = seeder.seed(ProgramDataSeeder.this.random, start, end, true);
	            return result;
	        }
	    });
	}
	
	/**
	 * This method will create the tables being used by the run.
	 * @param namespace
	 * @param database
	 */
	public Set<String> prepareForRun(boolean resetAll, String[] tables) {
		String[] tableList = {
				"accounts",
				"accountNumAndCode",
				"blackListCards",
				"cards",
				"countries",
				"customers",
				"ids",
				"locations",
				"logging",
				"merchants",
				"spendingHabits",
				"stores",
				"terminals",
				"terminalTxnDate",
				"transactions",
				"whiteListCards",
				};
		Set<String> actualTables = new HashSet<String>();
		for (String thisTable : tables) {
			if ("all".equalsIgnoreCase(thisTable)) {
				for (String tableName : tableList) {
					actualTables.add(tableName);
				}
			}
			else {
				// Make sure this table is valid
				boolean found = false;
				for (String tableName : tableList) {
					if (tableName.equalsIgnoreCase(thisTable)) {
						actualTables.add(tableName);
						found = true;
						break;
					}
				}
				if (!found) {
					log.error("Table " + thisTable + " is unknown");
					throw new IllegalArgumentException("Table " + thisTable + " is unknown");
				}
			}
		}
		if (actualTables.size() > 0) {
			if (nodeId != 1) {
				try {
					// Give the first node a chance to initialise the tables
					log.info("Sleeping to let tables be initialised");
					Thread.sleep(20000);
					log.info("Done sleeping");
				} catch (InterruptedException e) {
				}
			}
			else {
				if (resetAll) {
					for (String thisTable : actualTables) {
						database.dropTable(this.keySpace, thisTable);
					}
				}
				
				try {
					// Don't need to do the tables individually, if they exist an exception would be thrown
					database.runDdlCommand("create table " + this.keySpace + ".accounts(number varchar primary key, cards list<varchar>, name varchar, custId varchar, opened bigint, padding0 varchar, padding1 varchar, padding2 varchar, padding3 varchar, padding4 varchar, padding5 varchar, "
																			+ "padding6 varchar, padding7 varchar, padding8 varchar, padding9 varchar)");
					database.runDdlCommand("create table " + this.keySpace + ".accountNumAndCode(id varchar primary key, acctNum varchar, s_code varchar, merchName varchar, txnCount bigint, txnDate varchar)");
					database.runDdlCommand("create table " + this.keySpace + ".blackListCards(cardNo varchar primary key, reason varchar, date bigint)");
					database.runDdlCommand("create table " + this.keySpace + ".cards(cardNo varchar primary key, expYear int, nameOnCard varchar, expMon int,"
																			+ "accountId varchar, padding0 varchar, padding1 varchar, padding2 varchar, padding3 varchar, padding4 varchar, padding5 varchar, "
																			+ "padding6 varchar, padding7 varchar, padding8 varchar, padding9 varchar)");
					database.runDdlCommand("create table " + this.keySpace + ".countries(code varchar primary key, name varchar, language varchar)");
					database.runDdlCommand("create table " + this.keySpace + ".customers(id varchar primary key, firstName varchar, lastName varchar, city varchar,"
																			+ "joined bigint, postcode varchar, accounts list<varchar>, addr varchar, numAccounts int, "
																			+ "padding0 varchar, padding1 varchar, padding2 varchar, padding3 varchar, padding4 varchar, padding5 varchar, "
																			+ "padding6 varchar, padding7 varchar, padding8 varchar, padding9 varchar)" );
					database.runDdlCommand("create table " + this.keySpace + ".ids(id varchar primary key, comment varchar)");
					database.runDdlCommand("create table " + this.keySpace + ".locations(id varchar primary key, country varchar, pc varchar, address varchar, lat double, lng double)");
					database.runDdlCommand("create table " + this.keySpace + ".logging(id bigint primary key, date bigint, message varchar)");
					database.runDdlCommand("create table " + this.keySpace + ".merchants(id varchar primary key, name varchar, country varchar, pc varchar, timesused int, type varchar)");
					database.runDdlCommand("create table " + this.keySpace + ".spendingHabits(id varchar primary key, amtTotal double, cntTotal int,"
																			+ "amt1 double, cnt1 int, "
																			+ "amt2 double, cnt2 int, "
																			+ "amt3 double, cnt3 int, "
																			+ "amt4 double, cnt4 int, "
																			+ "amt5 double, cnt5 int, "
																			+ "amt6 double, cnt6 int, "
																			+ "amt7 double, cnt7 int, "
																			+ "amt8 double, cnt8 int, "
																			+ "amt9 double, cnt9 int, "
																			+ "amt10 double, cnt10 int, "
																			+ "amt11 double, cnt11 int)");
					database.runDdlCommand("create table " + this.keySpace + ".stores(id varchar primary key, locId varchar, name varchar, taxId varchar, numEmpl int)");
					database.runDdlCommand("create table " + this.keySpace + ".terminals(id varchar primary key, type varchar, locId varchar, storeId varchar)");
					database.runDdlCommand("create table " + this.keySpace + ".terminalTxnDate(termId varchar primary key, hr0 map<varchar,double>, hr1 map<varchar,double>,"
																			+ "hr2 map<varchar,double>, hr3 map<varchar,double>, hr4 map<varchar,double>, hr5 map<varchar,double>,"
																			+ "hr6 map<varchar,double>, hr7 map<varchar,double>, hr8 map<varchar,double>, hr9 map<varchar,double>,"
																			+ "hr10 map<varchar,double>, hr11 map<varchar,double>, hr12 map<varchar,double>, hr13 map<varchar,double>,"
																			+ "hr14 map<varchar,double>, hr15 map<varchar,double>, hr16 map<varchar,double>, hr17 map<varchar,double>,"
																			+ "hr18 map<varchar,double>, hr19 map<varchar,double>, hr20 map<varchar,double>, hr21 map<varchar,double>,"
																			+ "hr22 map<varchar,double>, hr23 map<varchar,double>)");
					
					database.runDdlCommand("create table " + this.keySpace + ".transactions(extTxnId varchar primary key, type varchar, dataspcver varchar,"
																			+ " pan varchar,custAcctNo varchar, availBal varchar, availCashLmt varchar,"
																			+ " availMerchLmt varchar, termId varchar, termVerf varchar, cardVerf varchar,"
																			+ " acqId varchar, acqBin varchar, acctExpDate varchar, acqCountry varchar,"
																			+ " txnDate varchar, txnTime varchar, txnType varchar, txnAmt varchar, txnCurCde varchar,"
																			+ " txnCurCnvRte varchar, merchId varchar, merchCity varchar, merchCountryCd varchar, merchName varchar, acctCode varchar, s_code varchar)");
					database.runDdlCommand("create table " + this.keySpace + ".whiteListCards(cardNo varchar primary key, reason varchar, date bigint)");
				}
				catch (Exception e) {
					log.error("Error creating tables... continuing anyway: " + e.getMessage(), e);
				}
			}
		}
		return actualTables;
	}
}
