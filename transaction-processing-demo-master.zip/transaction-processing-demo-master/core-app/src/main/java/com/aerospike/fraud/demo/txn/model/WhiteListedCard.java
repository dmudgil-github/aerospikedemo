package com.aerospike.fraud.demo.txn.model;

import java.util.Date;

public class WhiteListedCard {
	private final String cardNumber;
	private final String reason;
	private final Date date;
	
	public WhiteListedCard(String cardNumber, String reason, Date date) {
		this.cardNumber = cardNumber;
		this.reason = reason;
		this.date = date;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public String getReason() {
		return reason;
	}

	public Date getDate() {
		return date;
	}
}
