package com.aerospike.fraud.demo.txn.database;

public interface PreparedDatabaseStatement {
	RecordData get(DatabaseKey key);
}
