package com.aerospike.fraud.demo.txn.database;

import java.util.List;
import java.util.Map;

public abstract class DataElement {
	public enum ParticleType {
		NULL,
		STRING,
		INTEGER,
		DOUBLE,
		FLOAT,
		LIST,
		MAP
	};
	
	/**
	 * Get string or null value instance.
	 */
	public static DataElement get(String value) {
		return (value == null)? NullValue.INSTANCE : new StringValue(value);
	}

	/**
	 * Get integer value instance.
	 */
	public static DataElement get(int value) {
		return new IntegerValue(value);
	}
	
	/**
	 * Get long value instance.
	 */
	public static DataElement get(long value) {
		return new LongValue(value);
	}

	/**
	 * Get double value instance.
	 */
	public static DataElement get(double value) {
		return new DoubleValue(value);
	}

	/**
	 * Get float value instance.
	 */
	public static DataElement get(float value) {
		return new FloatValue(value);
	}

	/**
	 * Get boolean value instance.
	 */
	public static DataElement get(boolean value) {
		return new BooleanValue(value);
	}

	/**
	 * Get list or null value instance.
	 */
	public static DataElement get(List<?> value) {
		return (value == null)? NullValue.INSTANCE : new ListValue(value);
	}

	/**
	 * Get map or null value instance.
	 */
	public static DataElement get(Map<?,?> value) {
		return (value == null)? NullValue.INSTANCE : new MapValue(value);
	}

	/**
	 * Get null value instance.
	 */
	public static DataElement getAsNull() {
		return NullValue.INSTANCE;
	}
	
	/**
	 * Determine value given generic object.
	 * This is the slowest of the Value get() methods.
	 * Useful when copying records from one cluster to another.
	 */
	public static DataElement get(Object value) {
		if (value == null) {
			return NullValue.INSTANCE;
		}
		
		if (value instanceof DataElement) {
			return (DataElement)value;
		}

		if (value instanceof String) {
        	return new StringValue((String)value);
		}
		
		if (value instanceof Integer) {
        	return new IntegerValue((Integer)value);
		}
		
		if (value instanceof Long) {
        	return new LongValue((Long)value);
		}
		
		if (value instanceof Double) {
        	return new DoubleValue((Double)value);
		}
		
		if (value instanceof Float) {
        	return new FloatValue((Float)value);
		}
		
		if (value instanceof Boolean) {
        	return new BooleanValue((Boolean)value);
		}
		
		if (value instanceof List<?>) {
        	return new ListValue((List<?>)value);
		}
		
		if (value instanceof Map<?,?>) {
        	return new MapValue((Map<?,?>)value);
		}
		throw new IllegalArgumentException("Unknown data type " + value.getClass().getSimpleName());
	}
	
	/**
	 * Get wire protocol value type.
	 */
	public abstract ParticleType getType();
	
	/**
	 * Return original value as an Object.
	 */
	public abstract Object getObject();
	
	/**
	 * Return value as an integer.
	 */
	public int toInteger() {
		return 0;
	}
	
	/**
	 * Return value as a long.
	 */
	public long toLong() {
		return 0;
	}

	/**
	 * Return a string suitable for inserting into a database.
	 * @return
	 */
	public String toFormattedString() {
		return toString();
	}

	/**
	 * Empty value.
	 */
	public static final class NullValue extends DataElement {
		public static final NullValue INSTANCE = new NullValue();
		
		@Override
		public ParticleType getType() {
			return ParticleType.NULL;
		}
		
		@Override
		public Object getObject() {
			return null;
		}
		
		@Override
		public String toString() {
			return null;
		}
		
		@Override
		public String toFormattedString() {
			return "null";
		}
		
		@Override
		public boolean equals(Object other) {
			if (other == null) {
				return true;
			}			
			return this.getClass().equals(other.getClass());
		}

		@Override
		public final int hashCode() {
			return 0;
		}
	}
	
	/**
	 * String value.
	 */
	public static final class StringValue extends DataElement {		
		private final String value;

		public StringValue(String value) {
			this.value = value;
		}

		@Override
		public ParticleType getType() {
			return ParticleType.STRING;
		}
		
		@Override
		public Object getObject() {
			return value;
		}
		
		public String toString() {
			return value;
		}
		
		/**
		 * Note that this is a poor mans version, there are many escape sequences that this doesn't do
		 */
		@Override
		public String toFormattedString() {
			return "'" + value.replaceAll("'", "\\'") + "'";
		}
		
		@Override
		public boolean equals(Object other) {
			return (other != null &&
				this.getClass().equals(other.getClass()) &&
				this.value.equals(((StringValue)other).value));
		}

		@Override
		public int hashCode() {
	        return value.hashCode();
		}	
	}
	
	/**
	 * Integer value.
	 */
	public static final class IntegerValue extends DataElement {		
		private final int value;

		public IntegerValue(int value) {
			this.value = value;
		}
		
		@Override
		public ParticleType getType() {
			return ParticleType.INTEGER;
		}
		
		@Override
		public Object getObject() {
			return value;
		}
		
		@Override
		public String toString() {
			return Integer.toString(value);
		}
		
		@Override
		public boolean equals(Object other) {
			return (other != null &&
				this.getClass().equals(other.getClass()) &&
				this.value == ((IntegerValue)other).value);
		}

		@Override
		public int hashCode() {
	        return value;
		}	

		@Override
		public int toInteger() {
			return value;
		}

		@Override
		public long toLong() {
			return value;
		}
	}

	/**
	 * Long value.
	 */
	public static final class LongValue extends DataElement {		
		private final long value;

		public LongValue(long value) {
			this.value = value;
		}
		
		@Override
		public ParticleType getType() {
			return ParticleType.INTEGER;
		}
		
		@Override
		public Object getObject() {
			return value;
		}
		
		@Override
		public String toString() {
			return Long.toString(value);
		}
		
		@Override
		public boolean equals(Object other) {
			return (other != null &&
				this.getClass().equals(other.getClass()) &&
				this.value == ((LongValue)other).value);
		}

		@Override
		public int hashCode() {
	        return (int)(value ^ (value >>> 32));
		}	

		@Override
		public int toInteger() {
			return (int)value;
		}

		@Override
		public long toLong() {
			return value;
		}
	}

	/**
	 * Double value.
	 */
	public static final class DoubleValue extends DataElement {		
		private final double value;

		public DoubleValue(double value) {
			this.value = value;
		}
		
		@Override
		public ParticleType getType() {
			return ParticleType.DOUBLE;
		}
		
		@Override
		public Object getObject() {
			return value;
		}
		
		@Override
		public String toString() {
			return Double.toString(value);
		}
		
		@Override
		public boolean equals(Object other) {
			return (other != null &&
				this.getClass().equals(other.getClass()) &&
				this.value == ((DoubleValue)other).value);
		}

		@Override
		public int hashCode() {
	        long bits = Double.doubleToLongBits(value);
	        return (int)(bits ^ (bits >>> 32));
		}	

		@Override
		public int toInteger() {
			return (int)value;
		}

		@Override
		public long toLong() {
			return (long)value;
		}
	}

	/**
	 * Float value.
	 */
	public static final class FloatValue extends DataElement {		
		private final float value;

		public FloatValue(float value) {
			this.value = value;
		}
		
		@Override
		public ParticleType getType() {
			return ParticleType.DOUBLE;
		}
		
		@Override
		public Object getObject() {
			return value;
		}
		
		@Override
		public String toString() {
			return Float.toString(value);
		}
		
		@Override
		public boolean equals(Object other) {
			return (other != null &&
				this.getClass().equals(other.getClass()) &&
				this.value == ((FloatValue)other).value);
		}

		@Override
		public int hashCode() {
	        return Float.floatToIntBits(value);
		}	

		@Override
		public int toInteger() {
			return (int)value;
		}

		@Override
		public long toLong() {
			return (long)value;
		}
	}

	/**
	 * Boolean value.  
	 */
	public static final class BooleanValue extends DataElement {		
		private final boolean value;

		public BooleanValue(boolean value) {
			this.value = value;
		}
		
		@Override
		public ParticleType getType() {
			// The server does not natively handle boolean, so store as long (8 byte integer).
			return ParticleType.INTEGER;
		}
		
		@Override
		public Object getObject() {
			return value;
		}
		
		@Override
		public String toString() {
			return Boolean.toString(value);
		}
		
		@Override
		public boolean equals(Object other) {
			return (other != null &&
				this.getClass().equals(other.getClass()) &&
				this.value == ((BooleanValue)other).value);
		}

		@Override
		public int hashCode() {
	        return value ? 1231 : 1237;
		}	

		@Override
		public int toInteger() {
			return value? 1 : 0;
		}

		@Override
		public long toLong() {
			return value? 1L : 0L;
		}
	}

	
	/**
	 * List value.
	 */
	public static final class ListValue extends DataElement {
		private final List<?> list;

		public ListValue(List<?> list) {
			this.list = list;
		}
		
		@Override
		public ParticleType getType() {
			return ParticleType.LIST;
		}
		
		@Override
		public Object getObject() {
			return list;
		}

		@Override
		public String toString() {
			return list.toString();
		}
		
		@Override
		public boolean equals(Object other) {
			return (other != null &&
				this.getClass().equals(other.getClass()) &&
				this.list.equals(((ListValue)other).list));
		}
		
		@Override
		public int hashCode() {
	        return list.hashCode();
		}	
	}

	/**
	 * Map value.
	 */
	public static final class MapValue extends DataElement {
		private final Map<?,?> map;

		public MapValue(Map<?,?> map)  {
			this.map = map;
		}
		
		@Override
		public ParticleType getType() {
			return ParticleType.MAP;
		}
		
		@Override
		public Object getObject() {
			return map;
		}
		
		@Override
		public String toString() {
			return map.toString();
		}
	
		
		@Override
		public String toFormattedString(){
			StringBuilder builder = new StringBuilder();
	
			for ( Map.Entry<?, ?> entry : map.entrySet() ) {
				if ( builder.length() > 0 ) { builder.append(", "); };
				builder.append(String.format("\'%s\':%s", entry.getKey(), entry.getValue()));

			}
			builder.insert(0, "{").append("}");
			return builder.toString();
			
		}
	
		
		@Override
		public boolean equals(Object other) {
			return (other != null &&
				this.getClass().equals(other.getClass()) &&
				this.map.equals(((MapValue)other).map));
		}
		
		@Override
		public int hashCode() {
	        return map.hashCode();
		}	
	}
}
