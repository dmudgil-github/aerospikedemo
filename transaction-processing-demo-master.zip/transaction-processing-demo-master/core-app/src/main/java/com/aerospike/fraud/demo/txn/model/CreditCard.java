package com.aerospike.fraud.demo.txn.model;

public class CreditCard {
	private String cardNumber;
	private int expiryMonth;
	private int expiryYear;
	private String nameOnCard;
	private String accountId;
	// used to fill out the object to the appropriate size, eg 2k
	private String[] padding;

	public CreditCard (String inNum, int expiryMonth, int expiryYear, String nameOnCard, String accountId){
		this.cardNumber = inNum;
		this.expiryMonth = expiryMonth;
		this.expiryYear = expiryYear;
		this.nameOnCard = nameOnCard;
		this.accountId = accountId;
	}

	public CreditCard() {
	}
	
	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public int getExpiryMonth() {
		return expiryMonth;
	}

	public void setExpiryMonth(int expiryMonth) {
		this.expiryMonth = expiryMonth;
	}

	public int getExpiryYear() {
		return expiryYear;
	}

	public void setExpiryYear(int expiryYear) {
		this.expiryYear = expiryYear;
	}

	public String getNameOnCard() {
		return nameOnCard;
	}

	public void setNameOnCard(String nameOnCard) {
		this.nameOnCard = nameOnCard;
	}
	
	public String getAccountId() {
		return accountId;
	}
	
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	
	public String[] getPadding() {
		return padding;
	}
	public void setPadding(String[] padding) {
		this.padding = padding;
	}
}
