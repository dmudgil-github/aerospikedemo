package com.aerospike.fraud.demo.txn.model;

import com.aerospike.fraud.demo.txn.client.Loader;
import com.aerospike.fraud.demo.txn.client.Statistics;
import com.aerospike.fraud.demo.txn.core.machinelearning.MachineLearning;
import com.aerospike.fraud.demo.txn.core.rulesengine.RulesEngine;
import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.database.mappers.AccountMapper;
import com.aerospike.fraud.demo.txn.database.mappers.AcctNumAndCodeMapper;
import com.aerospike.fraud.demo.txn.database.mappers.CreditCardMapper;
import com.aerospike.fraud.demo.txn.database.mappers.CustomerMapper;
import com.aerospike.fraud.demo.txn.database.mappers.MerchantMapper;
import com.aerospike.fraud.demo.txn.database.mappers.SpendingHabitsMapper;
import com.aerospike.fraud.demo.txn.database.mappers.TransactionMapper;
import com.aerospike.fraud.demo.txn.util.latency.LatencyManager;
import com.aerospike.fraud.demo.txn.util.logging.Logger;
import com.aerospike.fraud.demo.txn.util.seed.AcctNumAndCodeSeeder;

public class LatencyStatsWrapper {
	
	private LatencyManager latencyManager;
	private LatencyManager readLatencyManager;
	private LatencyManager writeLatencyManager;
	private LatencyManager batchLatencyManager;
	private final Statistics statistics;
	private Logger logger;
	private Loader loader;
	private Database database;
	private String namespace;
	

	public LatencyStatsWrapper(
			String namespace, 
			Loader loader, 
			Database database, 
			Logger logger, 
			LatencyManager latencyManager,
			LatencyManager readLatencyManager, 
			LatencyManager writeLatencyManager, 
			LatencyManager batchLatencyManager,
			Statistics statistics) {
		this.loader = loader;
		this.database = database;
		this.namespace = namespace;
		this.logger = logger;
		this.latencyManager = latencyManager;
		this.readLatencyManager = readLatencyManager;
		this.writeLatencyManager = writeLatencyManager;
		this.batchLatencyManager = batchLatencyManager;
		this.statistics = statistics;	
	}


	public LatencyManager getLatencyManager() {
		return latencyManager;
	}


	public void setLatencyManager(LatencyManager latencyManager) {
		this.latencyManager = latencyManager;
	}


	public LatencyManager getReadLatencyManager() {
		return readLatencyManager;
	}


	public void setReadLatencyManager(LatencyManager readLatencyManager) {
		this.readLatencyManager = readLatencyManager;
	}


	public LatencyManager getWriteLatencyManager() {
		return writeLatencyManager;
	}


	public void setWriteLatencyManager(LatencyManager writeLatencyManager) {
		this.writeLatencyManager = writeLatencyManager;
	}


	public LatencyManager getBatchLatencyManager() {
		return batchLatencyManager;
	}


	public void setBatchLatencyManager(LatencyManager batchLatencyManager) {
		this.batchLatencyManager = batchLatencyManager;
	}


	public Logger getLogger() {
		return logger;
	}


	public void setLogger(Logger logger) {
		this.logger = logger;
	}


	public Loader getLoader() {
		return loader;
	}


	public void setLoader(Loader loader) {
		this.loader = loader;
	}


	public Database getDatabase() {
		return database;
	}


	public void setDatabase(Database database) {
		this.database = database;
	}


	public String getNamespace() {
		return namespace;
	}


	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}


	public Statistics getStatistics() {
		return statistics;
	}
	
	
	
	
}
