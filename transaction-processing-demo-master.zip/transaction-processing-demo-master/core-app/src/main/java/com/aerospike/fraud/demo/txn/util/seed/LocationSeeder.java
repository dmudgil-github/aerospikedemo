package com.aerospike.fraud.demo.txn.util.seed;

import java.util.Random;

import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.database.DatabaseKey;
import com.aerospike.fraud.demo.txn.database.mappers.LocationMapper;
import com.aerospike.fraud.demo.txn.model.Location;
import com.aerospike.fraud.demo.txn.util.seed.SeederUtils.Alphabet;

public class LocationSeeder extends Seeder implements IdMapper<Location> {
	private final Database database;
	private final String keySpace;
	private LocationMapper mapper = new LocationMapper();
	private static final SeederUtils utils = new SeederUtils();
	
	private final String [] COUNTRIES = {
			"GB",
			"US",
			"GE", // Georgia
			"PY", //Paraguay
			"PA"  // Panama			
	};
	
	public LocationSeeder(Database database, String keySpace) {
		super("Locations");
		this.database = database;
		this.keySpace = keySpace;
	}
	
	private Location generateLocation(Random r, long id) {
		Location location = new Location();
		location.setId(getIdForLogicalId(id));
		location.setCountry(COUNTRIES[utils.distribute(r, 70, 20, 3,2,5)]);
		location.setAddress(utils.getAddress(r));
		location.setPostalCode(utils.getString(r, 6, Alphabet.ALPHA_NUM_UPPER));
		location.setLat((r.nextDouble()-0.5) * 120);
		location.setLng((r.nextDouble()-0.5) * 120);
		return location;
	}
	
	public String getIdForLogicalId(long id) {
		return utils.formatNumber(id, 10, 8, 1000000);
	}
	
	@Override
	protected int doSeed(Random r, long startId, long endId) {
		int count = 0;
		for (long i = startId; i < endId; i++) {
			Location location = generateLocation(r, i);
			DatabaseKey key = new DatabaseKey(keySpace, "locations", location.getId());
			this.database.put(null, key, mapper.toRecord(location));
			count++;
		}
		return count;
	}
}
