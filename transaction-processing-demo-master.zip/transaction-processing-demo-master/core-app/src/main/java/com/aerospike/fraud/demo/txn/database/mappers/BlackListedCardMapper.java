package com.aerospike.fraud.demo.txn.database.mappers;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.aerospike.fraud.demo.txn.database.Column;
import com.aerospike.fraud.demo.txn.database.DataElement;
import com.aerospike.fraud.demo.txn.database.RecordData;
import com.aerospike.fraud.demo.txn.model.BlackListedCard;


/**
 * This class performs mapping from database records to Credit cards and back.
 * This could be done with a lot less code using annotations and introspection, but
 * this has a runtime performance penalty and this is key in this use case.
 * @author Tim
 *
 */
public class BlackListedCardMapper {
	public BlackListedCard fromRecord(RecordData record, int blackList) {
		BlackListedCard result = null;
		if (record != null) {
			result = new BlackListedCard(
					record.getString("cardNo"),
					record.getString("reason"),
					new Date(record.getLong("date"))
					);
		}
		return result;
	}
	
	public Column[] toRecord(BlackListedCard card) {
		List<Column> elements = new ArrayList<Column>();
		elements.add(new Column("cardNo", DataElement.get(card.getCardNumber())));
		elements.add(new Column("reason", DataElement.get(card.getReason())));
		elements.add(new Column("date", DataElement.get(card.getDate().getTime())));
		
		return elements.toArray(new Column[0]);
	}

}
