package com.aerospike.fraud.demo.txn.model;

public class Merchant {
	public enum MerchantType {
		RETAIL("RETAIL"),
		WHOLESALE("WHSALE"),
		INTERNET("INTRNT"),
		MOBILE("MOBILE"),
		MAIL_ORDER("MAIL");
		
		private String type;
		private MerchantType(String type) {
			this.type = type;
		}
		
		public String getType() {
			return type;
		}
		
		public static MerchantType fromType(String type) {
			for (MerchantType merchantType : MerchantType.values()) {
				if (merchantType.getType().equals(type)) {
					return merchantType;
				}
			}
			throw new IllegalArgumentException("Invalid MerchantType value " + type);
		}
	}
	
	private String id;
	private String name;
	private int timesTransacted;
	private String postalCode;
	private String country;
	private MerchantType merchantType;

	public Merchant() {
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getTimesTransacted() {
		return timesTransacted;
	}

	public void setTimesTransacted(int timesTransacted) {
		this.timesTransacted = timesTransacted;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}
	
	public MerchantType getMerchantType() {
		return merchantType;
	}
	
	public void setMerchantType(MerchantType merchantType) {
		this.merchantType = merchantType;
	}
}
