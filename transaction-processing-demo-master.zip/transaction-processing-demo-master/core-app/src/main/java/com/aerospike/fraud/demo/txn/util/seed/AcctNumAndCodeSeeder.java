
package com.aerospike.fraud.demo.txn.util.seed;

import java.util.Random;

import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.database.DatabaseKey;
import com.aerospike.fraud.demo.txn.database.mappers.AcctNumAndCodeMapper;
import com.aerospike.fraud.demo.txn.model.AcctNumAndCode;

public class AcctNumAndCodeSeeder extends Seeder implements IdMapper<AcctNumAndCode> {
	private final Database database;
	private final String keySpace;
	private AcctNumAndCodeMapper mapper = new AcctNumAndCodeMapper();
	private int numMerchants;
	private static final SeederUtils utils = new SeederUtils();
	private boolean knownCodes = true;
	
	public AcctNumAndCodeSeeder(Database database, String keySpace, int numMerchants) {
		super("Account Number and S_Code");
		this.database = database;
		this.keySpace = keySpace;
		this.numMerchants = numMerchants;
	}
	
	private AcctNumAndCode generateAcctNumAndCode(Random r, long id) {
		AcctNumAndCode acctNumAndCode = new AcctNumAndCode();
		String code = getIdForLogicalId(id);
		
		acctNumAndCode.setAcctNum(code.substring(0, 8));
		acctNumAndCode.setS_code(code.substring(8));
		acctNumAndCode.setMerchantName(getMerchantNameForId(r.nextInt(numMerchants)));
		acctNumAndCode.setTxnCount(r.nextInt(1000));
		acctNumAndCode.setLastTransactionDate(utils.getDate(r, -1000, 0, false));
		String compoundKey = acctNumAndCode.getAcctNum() + "|" + acctNumAndCode.getS_code() + "|" + acctNumAndCode.getMerchantName();
		acctNumAndCode.setId(compoundKey);
		return acctNumAndCode;
	}
	
	public String getIdForLogicalId(long id, boolean find) {
		if (find) {
			return utils.formatNumber(id, 14, 2000001, 1000001);
		}
		else {
			return utils.formatNumber(id, 14, 2000001, 10000002100001L);
		}
	}
	
	public String getIdForLogicalId(long id) {
		return getIdForLogicalId(id, knownCodes);
	}
	
	/**
	 * Get the name of the merchant, given the id.
	 * @param id
	 * @return
	 */
	public String getMerchantNameForId(long id) {
		// Not happy with this implementation, but it's expedient for now. We want to match 70%
		// of the account/scode/merchants on a compound key, so we will populate the database
		// with fixed merchant ids, and sometimes look up a different terminal.
		return "Merchant1";
	}
	
	@Override
	protected int doSeed(Random r, long startId, long endId) {
		int count = 0;
		for (long i = startId; i < endId; i++) {
			
			AcctNumAndCode acctNumAndCode = generateAcctNumAndCode(r, i);
			
			DatabaseKey key = new DatabaseKey(keySpace, "accountNumAndCode", acctNumAndCode.getId() );
			this.database.put(null, key, mapper.toRecord(acctNumAndCode));
			count++;
		}
		return count;
	}

	public void setKnownCodes(boolean b) {
		this.knownCodes = b;
	}
}
