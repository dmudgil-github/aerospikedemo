package com.aerospike.fraud.demo.txn.threadmanager;

import com.aerospike.fraud.demo.txn.client.Loader;
import com.aerospike.fraud.demo.txn.core.orchestrator.TxnFraudOrchestrator;
import com.aerospike.fraud.demo.txn.model.ClientHydratedTransaction;

public class WorkerThread implements Runnable{

	private TxnFraudOrchestrator sim;

	public WorkerThread(TxnFraudOrchestrator inSim) {
		sim = inSim;
		
	}

	public void run()
	{
		
		int count = 0;
		
		Loader loader = sim.getLoader();
		while ( loader != null && loader.hasMoreRecords()) {
			
			ClientHydratedTransaction nextTxn = loader.nextRecord();
			sim.processIncomingTransaction(nextTxn);
			
			// TODO: should be removed for actual benchmarking, just used for testing 
//			if (count++ == 10){
//				break;
//			}
			//break;
		}	
	}
}
