package com.aerospike.fraud.demo.txn.core.orchestrator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.concurrent.Callable;

import com.aerospike.fraud.demo.txn.client.Statistics;
import com.aerospike.fraud.demo.txn.client.Statistics.OperationStatistics;
import com.aerospike.fraud.demo.txn.core.orchestrator.TxnFraudOrchestrator.FraudResult;
import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.database.DatabaseKey;
import com.aerospike.fraud.demo.txn.database.RecordData;
import com.aerospike.fraud.demo.txn.database.mappers.SpendingHabitsMapper;
import com.aerospike.fraud.demo.txn.database.mappers.SpendingHabitsMapper.TimeComponent;
import com.aerospike.fraud.demo.txn.model.FraudFactsModel;
import com.aerospike.fraud.demo.txn.model.FraudFactsModel.TimeSpendingHabits;
import com.aerospike.fraud.demo.txn.model.LatencyStatsWrapper;

class CollectFactsConsumerSpendingHabit implements Callable<FraudResult> {


	private Database database;
	private String namespace;
	private final String customerId;
	private final String merchantId;
	private final String terminalId;
	private final FraudFactsModel fraudFacts;
	private SpendingHabitsMapper spendingHabitsMapper = new SpendingHabitsMapper();


	public CollectFactsConsumerSpendingHabit(String txnId, String customerId, String merchantId, String terminalId,
			FraudFactsModel fraudFacts,LatencyStatsWrapper latencyStatsWrapper) {
		this.customerId = customerId;
		this.merchantId = merchantId;
		this.terminalId = terminalId;
		this.fraudFacts = fraudFacts;
		this.database = latencyStatsWrapper.getDatabase();
		this.namespace = latencyStatsWrapper.getNamespace();
	}

	@Override
	public FraudResult call() throws Exception {
		List<String> keys = new ArrayList<String>();
		Calendar cal = new GregorianCalendar();
		String[] customerKeys = spendingHabitsMapper.formKeys(customerId, null, null, cal);
		keys.addAll(Arrays.asList(customerKeys));

		if (merchantId != null) {
			keys.addAll(Arrays.asList(spendingHabitsMapper.formKeys(customerId, null, merchantId, cal)));
		}
		if (terminalId != null) {
			keys.addAll(Arrays.asList(spendingHabitsMapper.formKeys(customerId, terminalId, null, cal)));
		}
		List<DatabaseKey> keyList = new ArrayList<DatabaseKey>(keys.size());
		for (String key: keys) {
			keyList.add(new DatabaseKey(namespace, "spendingHabits", key));
		}

		OperationStatistics stats = Statistics.getInstance().getStats(Statistics.SPENDING_HABITS_READ_STATS);
		long time = stats.beginMeasure();
		RecordData[] records = database.get(keyList.toArray(new DatabaseKey[0]));
		stats.endMeasure(time);
		stats.addCount(keyList.size());

		TimeSpendingHabits customerHabits = new TimeSpendingHabits(
				spendingHabitsMapper.fromRecord(records[TimeComponent.HOUR.getIndex()]), 
				spendingHabitsMapper.fromRecord(records[TimeComponent.DAY.getIndex()]), 
				spendingHabitsMapper.fromRecord(records[TimeComponent.WEEK.getIndex()]), 
				spendingHabitsMapper.fromRecord(records[TimeComponent.MONTH.getIndex()]),
				spendingHabitsMapper.fromRecord(records[TimeComponent.YEAR.getIndex()]));
		fraudFacts.setCustomerSpendingHabits(customerHabits);

		int offset = 5;	// Hour, Day, Week, Month, Year
		if (merchantId != null) {
			TimeSpendingHabits customerHabitsByMerchant = new TimeSpendingHabits(
					spendingHabitsMapper.fromRecord(records[offset + TimeComponent.HOUR.getIndex()]), 
					spendingHabitsMapper.fromRecord(records[offset + TimeComponent.DAY.getIndex()]), 
					spendingHabitsMapper.fromRecord(records[offset + TimeComponent.WEEK.getIndex()]), 
					spendingHabitsMapper.fromRecord(records[offset + TimeComponent.MONTH.getIndex()]),
					spendingHabitsMapper.fromRecord(records[offset + TimeComponent.YEAR.getIndex()]));
			fraudFacts.setCustomerSpendingHabitsByMerchant(customerHabitsByMerchant);
			offset += 5;
		}
		if (terminalId != null) {
			TimeSpendingHabits customerHabitsByTerminal = new TimeSpendingHabits(
					spendingHabitsMapper.fromRecord(records[offset + TimeComponent.HOUR.getIndex()]), 
					spendingHabitsMapper.fromRecord(records[offset + TimeComponent.DAY.getIndex()]), 
					spendingHabitsMapper.fromRecord(records[offset + TimeComponent.WEEK.getIndex()]), 
					spendingHabitsMapper.fromRecord(records[offset + TimeComponent.MONTH.getIndex()]),
					spendingHabitsMapper.fromRecord(records[offset + TimeComponent.YEAR.getIndex()]));
			fraudFacts.setCustomerSpendingHabitsByMerchant(customerHabitsByTerminal);
			offset += 5;
		}
		return FraudResult.OK;
	}
}