package com.aerospike.fraud.demo.txn.database.mappers;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import com.aerospike.fraud.demo.txn.database.Column;
import com.aerospike.fraud.demo.txn.database.DataElement;
import com.aerospike.fraud.demo.txn.database.RecordData;
import com.aerospike.fraud.demo.txn.database.refdata.ReferenceData;
import com.aerospike.fraud.demo.txn.model.SpendingHabits;
import com.aerospike.fraud.demo.txn.model.SpendingHabits.SpendingHabit;

public class SpendingHabitsMapper {
	public enum TimeComponent {
		HOUR(4, "h"),
		DAY(3, "d"),
		WEEK(2, "w"),
		MONTH(1, "m"),
		YEAR(0, "y");
		
		private final int index;
		private final String separator;
		private TimeComponent(int index, String separator) {
			this.index = index;
			this.separator = separator;
		}
		public int getIndex() {
			return index;
		}
		public String getSeparator() {
			return separator;
		}
	}
	
	private static final String TERMINAL_SEPARATOR = "t";
	private static final String MERCHANT_SEPARATOR = "m";
	
	private String pad(int val) {
		if (val < 10) { 
			return "0" + val;
		}
		else {
			return Integer.toString(val);
		}
	}
	
	public String formKey(String customerId, String terminalId, String merchantId, Calendar forDate, TimeComponent time) {
		if (customerId == null) {
			throw new NullPointerException("customerId cannot be null");
		}
		StringBuffer sb = new StringBuffer();
		sb.append(customerId);
		
		// Should be one or the other, but allow both.
		if (terminalId != null) {
			sb.append(TERMINAL_SEPARATOR).append(terminalId);
		}
		if (merchantId != null) {
			sb.append(MERCHANT_SEPARATOR).append(terminalId);
		}
		// Everything has a year component
		sb.append(TimeComponent.YEAR.getSeparator()).append(forDate.get(Calendar.YEAR));
		
		if (time == TimeComponent.WEEK) {
			sb.append(TimeComponent.WEEK.getSeparator()).append(forDate.get(Calendar.WEEK_OF_YEAR));
		}
		if (time == TimeComponent.MONTH) {
			sb.append(TimeComponent.MONTH.getSeparator()).append(pad(forDate.get(Calendar.MONTH)+1));
		}
		if (time == TimeComponent.DAY) {
			sb.append(TimeComponent.MONTH.getSeparator()).append(pad(forDate.get(Calendar.MONTH)+1))
				.append(TimeComponent.DAY.getSeparator()).append(pad(forDate.get(Calendar.DAY_OF_MONTH)));
		}
		if (time == TimeComponent.HOUR) {
			sb.append(TimeComponent.MONTH.getSeparator()).append(pad(forDate.get(Calendar.MONTH)+1))
			.append(TimeComponent.DAY.getSeparator()).append(pad(forDate.get(Calendar.DAY_OF_MONTH)))
			.append(TimeComponent.HOUR.getSeparator()).append(pad(forDate.get(Calendar.HOUR_OF_DAY)));
		}
		return sb.toString();
	}
	
	public String[] formKeys(String customerId, String terminalId, String merchantId, Calendar forDate) {
		String[] results = new String[TimeComponent.values().length];
		if (customerId == null) {
			throw new NullPointerException("customerId cannot be null");
		}
		StringBuffer sb = new StringBuffer();
		sb.append(customerId);
		
		// Should be one or the other, but allow both.
		if (terminalId != null) {
			sb.append(TERMINAL_SEPARATOR).append(terminalId);
		}
		if (merchantId != null) {
			sb.append(MERCHANT_SEPARATOR).append(merchantId);
		}
		// Everything has a year component
		sb.append(TimeComponent.YEAR.getSeparator()).append(forDate.get(Calendar.YEAR));
		results[TimeComponent.YEAR.getIndex()] = sb.toString();
		results[TimeComponent.WEEK.getIndex()] = results[TimeComponent.YEAR.getIndex()] + 
			TimeComponent.WEEK.getSeparator()+pad(forDate.get(Calendar.WEEK_OF_YEAR));
		sb.append(TimeComponent.MONTH.getSeparator()).append(pad(forDate.get(Calendar.MONTH)+1));
		results[TimeComponent.MONTH.getIndex()] = sb.toString();
		sb.append(TimeComponent.DAY.getSeparator()).append(pad(forDate.get(Calendar.DAY_OF_MONTH)));
		results[TimeComponent.DAY.getIndex()] = sb.toString();
		sb.append(TimeComponent.HOUR.getSeparator()).append(pad(forDate.get(Calendar.HOUR_OF_DAY)));
		results[TimeComponent.HOUR.getIndex()] = sb.toString();
		return results;
	}
	
	public Column[] toRecord(SpendingHabits spendingHabits) {
		return toRecord(null, spendingHabits);
	}
	
	public Column[] toRecord(String dbKey, SpendingHabits spendingHabits) {
		List<Column> elements = new ArrayList<Column>();
		if (dbKey != null) {
			elements.add(new Column("id", DataElement.get(dbKey)));
		}
		elements.add(new Column("amtTotal", DataElement.get(spendingHabits.getTotal().getAmount())));
		elements.add(new Column("cntTotal", DataElement.get(spendingHabits.getTotal().getCount())));
		Map<Integer, SpendingHabit>habits = spendingHabits.getPerAmountRange();
		for (Integer key : habits.keySet()) {
			// Could put it as a map, but easier just as separate bins
			elements.add(new Column("amt"+key, DataElement.get(habits.get(key).getAmount())));
			elements.add(new Column("cnt"+key, DataElement.get(habits.get(key).getCount())));
		}

		return elements.toArray(new Column[0]);
	}

	public SpendingHabits fromRecord(RecordData record) {
		SpendingHabits result = null;
		if (record != null) {
			result = new SpendingHabits();
			SpendingHabit total = new SpendingHabit();
			total.setAmount(record.getDouble("amtTotal"));
			total.setCount(record.getInt("cntTotal"));
			result.setTotal(total);
			
			for (int i = 0; i < ReferenceData.amountRangeCount(); i++) {
				SpendingHabit habit = new SpendingHabit();
				int count = record.getInt("cnt" + i);
				if (count > 0) {
					double amount = record.getDouble("amt" + i);
					habit.setAmount(amount);
					habit.setCount(count);
				}
				result.setSpendingHabitForRange(i, habit);
			}
		}
		return result;
	}
}
