package com.aerospike.fraud.demo.txn.database.mappers;

import java.util.ArrayList;
import java.util.List;

import com.aerospike.fraud.demo.txn.database.Column;
import com.aerospike.fraud.demo.txn.database.DataElement;
import com.aerospike.fraud.demo.txn.database.RecordData;
import com.aerospike.fraud.demo.txn.model.CreditCard;


/**
 * This class performs mapping from database records to Credit cards and back.
 * This could be done with a lot less code using annotations and introspection, but
 * this has a runtime performance penalty and this is key in this use case.
 * @author Tim
 *
 */
public class CreditCardMapper {
	public CreditCard fromRecord(RecordData record) {
		CreditCard result = null;
		if (record != null) {
			result = new CreditCard();
			result.setAccountId(record.getString("accountId"));
			result.setCardNumber(record.getString("cardNo"));
			result.setExpiryMonth(record.getInt("expMon"));
			result.setExpiryYear(record.getInt("expYear"));
			result.setNameOnCard(record.getString("nameOnCard"));
			String[] paddingStrings = new String[10];
			for (int i = 0; i < 10; i++) {
				String s = record.getString("padding" + i);
				if (s != null) {
					paddingStrings[i] = s;
				}
				else {
					break;
				}
			}
			result.setPadding(paddingStrings);
		}
		return result;
	}
	
	public Column[] toRecord(CreditCard card) {
		List<Column> elements = new ArrayList<Column>();
		elements.add(new Column("accountId", DataElement.get(card.getAccountId())));
		elements.add(new Column("cardNo", DataElement.get(card.getCardNumber())));
		elements.add(new Column("expMon", DataElement.get(card.getExpiryMonth())));
		elements.add(new Column("expYear", DataElement.get(card.getExpiryYear())));
		elements.add(new Column("nameOnCard", DataElement.get(card.getNameOnCard())));
				
		for (int i = 0; i < card.getPadding().length; i++) {
			elements.add(new Column("padding" + i, DataElement.get(card.getPadding()[i])));
		}
		
		return elements.toArray(new Column[0]);
	}

}
