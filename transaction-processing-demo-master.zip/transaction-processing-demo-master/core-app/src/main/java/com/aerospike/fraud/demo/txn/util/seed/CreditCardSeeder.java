package com.aerospike.fraud.demo.txn.util.seed;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Random;

import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.database.DatabaseKey;
import com.aerospike.fraud.demo.txn.database.mappers.CreditCardMapper;
import com.aerospike.fraud.demo.txn.model.Account;
import com.aerospike.fraud.demo.txn.model.CreditCard;

public class CreditCardSeeder extends Seeder implements IdMapper<CreditCard> {
	private final Database database;
	private final String keySpace;
	private final CreditCardMapper mapper = new CreditCardMapper();
	private static final SeederUtils utils = new SeederUtils();
	private final int numAccounts;
	private final IdMapper<Account> accountIdMapper;
	
	public CreditCardSeeder(Database database, String keySpace, int numAccounts, IdMapper<Account> accountIdMapper) {
		super("Credit Cards");
		this.database = database;
		this.keySpace = keySpace;
		this.accountIdMapper = accountIdMapper;
		this.numAccounts = numAccounts;
	}
	
	private CreditCard generateCreditCard(Random r, long id) {
		CreditCard card = new CreditCard();
		
		// The id must be repeatable so it can be referenced later
		card.setCardNumber(getIdForLogicalId(id));
		// Make the expiration to be future dated except for a handful.
		Date date = utils.getDate(r, -30, 1200, true);
		Calendar cal = new GregorianCalendar();
		cal.setTime(date);
		card.setExpiryMonth(cal.get(Calendar.MONTH) + 1);
		card.setExpiryYear(cal.get(Calendar.YEAR));
		card.setNameOnCard(utils.getName(r));
		card.setAccountId(accountIdMapper.getIdForLogicalId(r.nextInt(numAccounts)));
		
		// Pad the records so they're around 1.5k - 2k
		int bytesRemaining = 1400 + r.nextInt(500);
		String[] paddingStrings = utils.generateString(r, 10, bytesRemaining);
		card.setPadding(paddingStrings);
		
		// Associate the card with an account
		// Now we need to update the customer to have an updated count and references to the account.
		DatabaseKey accountKey = new DatabaseKey(keySpace, "accounts", card.getAccountId());
		database.addIdToList(accountKey, "cards", card.getCardNumber(), null);
		return card;
	}
	
	@Override
	protected int doSeed(Random r, long startId, long endId) {
		int count = 0;
		for (long i = startId; i < endId; i++) {
			CreditCard card = generateCreditCard(r, i);
			DatabaseKey key = new DatabaseKey(keySpace, "cards", card.getCardNumber());
			this.database.put(null, key, mapper.toRecord(card));
			count++;
		}
		return count;
	}

	@Override
	public String getIdForLogicalId(long id) {
		return "4397" + utils.formatNumber(id, 12, 3919, 12411201);
	}
}
