package com.aerospike.fraud.demo.txn.util.seed;

import java.util.Date;
import java.util.Random;

import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.database.DatabaseKey;
import com.aerospike.fraud.demo.txn.database.mappers.CustomerMapper;
import com.aerospike.fraud.demo.txn.model.Customer;
import com.aerospike.fraud.demo.txn.util.seed.SeederUtils.Alphabet;

public class CustomerSeeder extends Seeder implements IdMapper<Customer> {
	private final Database database;
	private final String keySpace;
	private final double vipPercent;
	private final CustomerMapper mapper = new CustomerMapper();
	private static final SeederUtils utils = new SeederUtils();
	
	public CustomerSeeder(Database database, String keySpace, double vipPercent) {
		super("Customer");
		this.database = database;
		this.keySpace = keySpace;
		this.vipPercent = vipPercent;
	}
	
	private Customer generateCustomer(Random r, long id, double vipPercent) {
		Customer customer = new Customer();
		
		// The id must be repeatable so it can be referenced later
		customer.setCustomerId(getIdForLogicalId(id));
		Date dateJoined = utils.getDate(r, -5000, +1, false);
		customer.setFirstName(utils.getFirstName(r));
		customer.setLastName(utils.getLastName(r));
		customer.setPreferredSalutation(customer.getFirstName());
		customer.setAddress("" + r.nextInt(200) + " " + utils.getFirstName(r) + " St");
		customer.setCity(utils.getCity(r));
		customer.setPostCode(utils.getString(r, 6, Alphabet.ALPHA_NUM_UPPER));
		customer.setJoinedBank(dateJoined);
		customer.setNumAccounts(0);
		customer.setVip(r.nextDouble() < vipPercent);
		
		// Pad the records so they're around 1.5k - 2k
		int bytesRemaining = 1400 + r.nextInt(500);
		String[] paddingStrings = utils.generateString(r, 10, bytesRemaining);
		customer.setPadding(paddingStrings);
		
		return customer;
	}
	
	@Override
	protected int doSeed(Random r, long startId, long endId) {
		int count = 0;
		for (long i = startId; i < endId; i++) {
			Customer customer = generateCustomer(r, i, this.vipPercent);
			DatabaseKey key = new DatabaseKey(keySpace, "customers", customer.getCustomerId());
			this.database.put(null, key, mapper.toRecord(customer));			
			count++;
		}
		return count;
	}

	@Override
	public String getIdForLogicalId(long id) {
		return utils.formatNumber(id, 10, 1, 10000000);
	}
}
