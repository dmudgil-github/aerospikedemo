package com.aerospike.fraud.demo.txn.util.seed;

import com.aerospike.fraud.demo.txn.database.DatabaseKey;

public interface KeyGenerator {
	DatabaseKey getKey(int index);
}

