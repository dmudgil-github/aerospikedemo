package com.aerospike.fraud.demo.txn.util.seed;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import com.aerospike.fraud.demo.txn.database.Column;
import com.aerospike.fraud.demo.txn.database.DataElement;
import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.database.DatabaseKey;
import com.aerospike.fraud.demo.txn.model.Terminal;

public class TerminalHistorySeeder extends Seeder {

	private static final SeederUtils utils = new SeederUtils();
	private final String keySpace;
	private final Database database;
	private final double refundsPercentage;
	private final double fraudulentPercentage;
	private final IdMapper<Terminal> mapper;
	private final int entriesPerTerminal;
	
	public TerminalHistorySeeder(Database database, String keySpace, double refundsPercentage, double fraudulentPercentage, int entriesPerTerminal, IdMapper<Terminal> mapper) {
		super("Terminal History");
		this.keySpace = keySpace;
		this.database = database;
		this.refundsPercentage = refundsPercentage;
		this.fraudulentPercentage = fraudulentPercentage;
		this.entriesPerTerminal = entriesPerTerminal;
		this.mapper = mapper;
	}
	
	@Override
	protected int doSeed(Random random, long startId, long endId) {
		int count = 0;
		for (long i = startId; i < endId; i++) {
			String termId = getIdForLogicalId(i);
			GregorianCalendar cal = new GregorianCalendar();
			long now = cal.getTimeInMillis();
			int currentHour = cal.get(Calendar.HOUR_OF_DAY);
			
			boolean isFraudulent = random.nextDouble() < fraudulentPercentage;
			int fraudulentTime = 25;	// Past end of dqy
			if (isFraudulent && random.nextDouble() < 0.2) {
				// These terminals are fraudulent in time, otherwise always fraudulent.
				fraudulentTime = random.nextInt(24);
			}
			// Create 200 history entries spanning around 30 days history per terminal
			for (int j = 0; j < entriesPerTerminal; j++) {
				Map<String, Map<String, Object>> bins = new HashMap<String, Map<String, Object>>();
				for (int k = 0; k < Math.min(24, currentHour+1); k++) {
					cal.setTime(new Date(now));
					int hour = cal.get(Calendar.HOUR_OF_DAY);
					String binName = "hr" + hour;
					int numTxns = random.nextInt(100) * (1+random.nextInt(10));
					double amount = random.nextDouble() * 200.0 * numTxns;
					// Slip in some noticeably fraudulent terminals 
					double refundPercentageToUse = this.refundsPercentage;
					if (isFraudulent && (fraudulentTime >= 24 || hour == fraudulentTime)) {
						refundPercentageToUse = 0.9;
					}
					
					// Number of transactions is +- 10% of the refundPercentage.
					int refundTxns = (int)(refundPercentageToUse * numTxns * (0.9 + 0.2 * random.nextDouble()));
					if (refundTxns < 0) {
						refundTxns = 0;
					}
					double refundAmount = numTxns > 0 ? amount * (0.9 + 0.2*random.nextDouble() * refundTxns/numTxns) : 0;
					if (refundAmount > amount) {
						refundAmount = amount;
					}
					else if (refundAmount < 0) {
						refundAmount = 0;
					}
					refundAmount = ((int)(refundAmount * 100))/100.0;
					amount = ((int)amount * 100) /100.0;
					
					Map<String, Object> map = new HashMap<String, Object>();
					map.put("count", numTxns);
					map.put("amount", amount);
					map.put("refundCnt", refundTxns);
					map.put("refundAmt", refundAmount);
					bins.put(binName, map);
					now = now - 3600*1000;
				}
				// Reset the current time so the next runs do complete (24 hr) runs
				currentHour = 100;
				Column[] columns = new Column[bins.size()+1];
				int k = 0;
				for (String key : bins.keySet()) {
					columns[k++] = new Column(key, DataElement.get(bins.get(key)));
				}
				
				DatabaseKey key = new DatabaseKey(keySpace, "terminalTxnDate", termId + ":" + cal.get(Calendar.YEAR) + cal.get(Calendar.DAY_OF_YEAR));
				columns[k] = new Column("termId", new DataElement.StringValue(key.getId()));
				database.put(null, key, columns);
				count++;
			}
		}

		return count;
	}

	@Override
	public String getIdForLogicalId(long id) {
		return mapper.getIdForLogicalId(id);
	}
	
	
}
