package com.aerospike.fraud.demo.txn.database.refdata;

import com.aerospike.fraud.demo.txn.model.AmountRange;

/**
 * This class contains reference data. Much of this infomration would make sense
 * to look up in a persistent data store rather than be hard coded, but it would be
 * loaded into a memory store from the DB and refreshed occasionally, rather than
 * incurring DB accesses for each reference.
 * @author Tim
 *
 */
public class ReferenceData {
	private static final AmountRange[] TXN_AMOUNT_RANGES = {
			new AmountRange(0, 10, 1),
			new AmountRange(10,30, 2),
			new AmountRange(30, 60, 3),
			new AmountRange(60, 100, 4),
			new AmountRange(100, 200, 5),
			new AmountRange(200, 500, 6),
			new AmountRange(500, 1000, 7),
			new AmountRange(1000, 2000, 8),
			new AmountRange(2000, 5000, 9),
			new AmountRange(5000, 10000, 10),
			new AmountRange(10000, Integer.MAX_VALUE, 11)
	};
	
	public static AmountRange getRangeForAmount(double amount) {
		for (int i = 0; i < TXN_AMOUNT_RANGES.length; i++) {
			AmountRange thisRange = TXN_AMOUNT_RANGES[i];
			if (amount >= thisRange.getMin() && amount < thisRange.getMax()) {
				return thisRange;
			}
		}
		throw new IllegalArgumentException("Cannot find an amount range for " + amount );
	}
	
	public static int amountRangeCount() {
		return TXN_AMOUNT_RANGES.length;
	}
}
