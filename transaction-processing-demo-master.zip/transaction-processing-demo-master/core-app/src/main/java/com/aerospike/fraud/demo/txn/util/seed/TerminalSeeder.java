package com.aerospike.fraud.demo.txn.util.seed;

import java.util.Random;

import com.aerospike.fraud.demo.txn.database.Database;
import com.aerospike.fraud.demo.txn.database.DatabaseKey;
import com.aerospike.fraud.demo.txn.database.mappers.TerminalMapper;
import com.aerospike.fraud.demo.txn.model.Location;
import com.aerospike.fraud.demo.txn.model.Store;
import com.aerospike.fraud.demo.txn.model.Terminal;

public class TerminalSeeder extends Seeder implements IdMapper<Terminal>{

	private static final SeederUtils utils = new SeederUtils();
	private final String keySpace;
	private final Database database;
	private final int numLocations; 
	private final int numStores;
	private final TerminalMapper mapper = new TerminalMapper();
	private final IdMapper<Location> locationMapper;
	private final IdMapper<Store> storeMapper;
	
	public TerminalSeeder(Database database, String keySpace, int numLocations, IdMapper<Location> locationIdMapper, int numStores, IdMapper<Store> storeMapper) {
		super("Terminals");
		this.keySpace = keySpace;
		this.database = database;
		this.numLocations = numLocations;
		this.numStores = numStores;
		this.locationMapper = locationIdMapper;
		this.storeMapper = storeMapper;
	}
	
	@Override
	public String getIdForLogicalId(long id) {
		return "T" + utils.formatNumber(id, 7, 1, 0);
	}

	private Terminal generateTerminal(Random r, long id) {
		Terminal terminal = new Terminal();
		
		terminal.setId(getIdForLogicalId(id));
		terminal.setLocationId(this.locationMapper.getIdForLogicalId(r.nextInt(numLocations)));
		terminal.setType("R");
		terminal.setStoreId(this.storeMapper.getIdForLogicalId(r.nextInt(numStores)));
		return terminal;
	}


	@Override
	protected int doSeed(Random r, long startId, long endId) {
		int count = 0;
		for (long i = startId; i < endId; i++) {
			Terminal terminal = generateTerminal(r, i);
			DatabaseKey key = new DatabaseKey(keySpace, "terminals", terminal.getId());
			this.database.put(null, key, mapper.toRecord(terminal));
			
			count++;
		}
		return count;
	}
}
