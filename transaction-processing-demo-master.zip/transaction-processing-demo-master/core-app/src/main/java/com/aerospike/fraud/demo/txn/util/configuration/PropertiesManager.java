package com.aerospike.fraud.demo.txn.util.configuration;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;

import com.aerospike.fraud.demo.txn.client.TxnFraudClient;

public class PropertiesManager {
	private final Properties properties;
	private static final Logger log = Logger.getLogger(PropertiesManager.class);
	private final Map<String, Object> propertiesMap = new ConcurrentHashMap<String, Object>(128);
	public static class NameWithDefault {
		String name;
		String defaultValue;
		public NameWithDefault(String name, String defaultValue) {
			super();
			this.name = name;
			this.defaultValue = defaultValue;
		}
		public String getName() {
			return name;
		}
		public String getDefaultValue() {
			return defaultValue;
		}
		
		
	}
	public PropertiesManager(String propertiesFileName) throws IOException {
		InputStream is = null;
		try {
			if (propertiesFileName.indexOf("/") > 0) {
				// This is definitely a filename
				File f = new File(propertiesFileName);
				log.info("Loading " + f.getAbsolutePath());
				is = new FileInputStream(f);
			}
			else {
				File f = new File(propertiesFileName);
				if (f.exists()) {
					log.info("Loading " + f.getAbsolutePath());
					is = new FileInputStream(f);
				}
				else {
					log.info("Loading " + propertiesFileName + " from classpath");
					is = TxnFraudClient.class.getClassLoader().getResourceAsStream(propertiesFileName);
				}
			}
			if (is == null) {
				throw new IllegalArgumentException("Could not find a properties file called " + propertiesFileName);
			}
			this.properties = new Properties();
			this.properties.load(is);
		}
		finally {
			if (is != null) {
				is.close();
			}
		}
	}
	
	public int getInt(NameWithDefault name) {
		Object value = propertiesMap.get(name.getName());
		if (value != null) {
			return (Integer)value;
		}
		else {
			Integer intValue = Integer.valueOf(this.properties.getProperty(name.getName(), name.getDefaultValue()));
			this.propertiesMap.put(name.getName(), intValue);
			return intValue;
		}
	}
	
	public long getLong(NameWithDefault name) {
		Object value = propertiesMap.get(name.getName());
		if (value != null) {
			return (Long)value;
		}
		else {
			Long longValue = Long.valueOf(this.properties.getProperty(name.getName(), name.getDefaultValue()));
			this.propertiesMap.put(name.getName(), longValue);
			return longValue;
		}
	}
	
	public double getDouble(NameWithDefault name) {
		Object value = propertiesMap.get(name.getName());
		if (value != null) {
			return (Double)value;
		}
		else {
			Double dValue = Double.valueOf(this.properties.getProperty(name.getName(), name.getDefaultValue()));
			this.propertiesMap.put(name.getName(), dValue);
			return dValue;
		}
	}

	public String getString(NameWithDefault name) {
		Object value = propertiesMap.get(name.getName());
		if (value != null) {
			return (String)value;
		}
		else {
			String strValue = this.properties.getProperty(name.getName(), name.getDefaultValue());
			this.propertiesMap.put(name.getName(), strValue);
			return strValue;
		}
	}
	
	public double getPercentage(NameWithDefault name) {
		Object value = propertiesMap.get(name.getName());
		if (value != null) {
			return (Double)value;
		}
		else {
			String val = this.properties.getProperty(name.getName(), name.getDefaultValue());
			int index = val.indexOf("%");
			if (index > 0) {
				val = val.substring(0, index);
			}
			value = Double.valueOf(val) / 100;
			this.propertiesMap.put(name.getName(), value);
			return (Double)value;
		}
	}
}
