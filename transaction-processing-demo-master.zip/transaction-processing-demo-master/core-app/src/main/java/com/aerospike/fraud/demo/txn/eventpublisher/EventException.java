package com.aerospike.fraud.demo.txn.eventpublisher;

public class EventException extends Exception {
	
	public EventException(String e) {
		super(e);
	}

}
