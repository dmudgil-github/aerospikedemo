package com.aerospike.fraud.demo.txn.client;

import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;

import com.aerospike.client.util.Util;
import com.aerospike.fraud.demo.txn.model.Account;
import com.aerospike.fraud.demo.txn.model.AcctNumAndCode;
import com.aerospike.fraud.demo.txn.model.ClientHydratedTransaction;
import com.aerospike.fraud.demo.txn.model.CreditCard;
import com.aerospike.fraud.demo.txn.model.Merchant;
import com.aerospike.fraud.demo.txn.model.Terminal;
import com.aerospike.fraud.demo.txn.util.configuration.PropertiesManager;
import com.aerospike.fraud.demo.txn.util.seed.IdMapper;
import com.aerospike.fraud.demo.txn.util.seed.InboundTransactionSeeder;

public class InfiniteLoader implements Loader{

	private final Random random;
	private final IdMapper<Account> accountMapper;
	private final IdMapper<CreditCard> cardMapper;
	private final IdMapper<Merchant> merchantMapper;
	private final IdMapper<Terminal> terminalMapper;
	private final IdMapper<AcctNumAndCode> acctNumAndCodeMapper;
	private final PropertiesManager properties;
	private final AtomicLong counter;
	private final int throughput;
	private final Statistics statistics = Statistics.getInstance();
	
	public InfiniteLoader(Random random, IdMapper<Account> accountMapper, IdMapper<CreditCard> cardMapper, IdMapper<Merchant> merchantMapper, IdMapper<Terminal> terminalMapper,
			IdMapper<AcctNumAndCode> acctNumAndCodeMapper, PropertiesManager properties, int throughput, long seedValue) {
		super();
		this.random = random;
		this.accountMapper = accountMapper;
		this.cardMapper = cardMapper;
		this.merchantMapper = merchantMapper;
		this.terminalMapper = terminalMapper;
		this.acctNumAndCodeMapper = acctNumAndCodeMapper;
		this.throughput = throughput;
		this.properties = properties;
		this.counter = new AtomicLong(seedValue);
	}

	@Override
	public boolean hasMoreRecords() {
		return true;
	}

	@Override
	public ClientHydratedTransaction nextRecord() {
		if (throughput > 0) {
			int transactions;
			transactions = statistics.getTransactionsThisSecond().count.get();
			if (transactions > throughput) {
				long millis = statistics.getPeriodBegin().get() + 1000L - System.currentTimeMillis();                                        

				if (millis > 0) {
					Util.sleep(millis);
				}
			}
		}
		ClientHydratedTransaction r = InboundTransactionSeeder.createTransaction(random, accountMapper, cardMapper, merchantMapper, terminalMapper, acctNumAndCodeMapper, properties, counter.getAndIncrement());
		statistics.getTransactionsThisSecond().count.incrementAndGet();
		statistics.getTransactions().count.incrementAndGet();
		return r;
	}

}
