package com.aerospike.fraud.demo.txn.client;

public enum OperationMode {
	READONLY("readOnly"),
	COMPATIBLE("compatible"),
	FULL("full"),
	MAINREADS("mainReads");
	
	private String name;
	private OperationMode(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
}