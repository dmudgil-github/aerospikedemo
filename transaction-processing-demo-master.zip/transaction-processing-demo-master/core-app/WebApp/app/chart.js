// Chart module
angular.module('myChart', [])
.factory('d3', function() {
    // We could declare locals or other d3.js specific config here
    return d3;
})
// D3 loader service
.factory('SimpleD3Loader', ['d3', function(d3) {
    return function(url, callback) {
        d3.text(url, callback);
    }
}])
.factory('SimpleHttpLoader', ["$http", function ($http) {
    return function(url) {
        return $http({
        	url: url,
        	method: "GET",
        	timeout: 4000
        });
    }
}])
.directive('latencyChart', ['d3',
    function(d3) {
        function draw(svg, width, height, data, heading, domain) {
        	var SHOW_MIN_MAX_BARS = false;
            svg
                .attr('width', width)
                .attr('height', height);

            var fontSize = Math.floor(width/30) + 'px';
            if (heading) {
                svg.select('.chartTitle')
	        		.attr('x', width/2)
	        		.attr('y', 20)
	        		.text(heading)
	        		.attr('font-size', fontSize);
            }

            var getAttribute = function(data, domain, attribute) {
            	try {
            		var obj = data[domain];
            		if (obj) {
            			return data[domain][attribute];
            		}
            	}
            	catch (e) {
            	}
            	return 0;
            };
            var getX = function(obj) {
            	if (!obj || (obj.x === undefined)) {
            		return 0;
            	}
            	return obj.x;
            }
            var circleSize = width / 500;
            // Define a margin:
            var margins = {top: 30, left: 50, right: 20, bottom: 30};
            var innerWidth = width - margins.left - margins.right;
            var innerHeight = height - margins.top - margins.bottom;
            
            var margin = 50;
            var parseDate = d3.timeFormat('')
            // Define the x-scale
            var xScale = d3.scaleTime()
                .domain(d3.extent(data, function(d) { return d.date; }))
                .range([margins.left, width-margins.right]);
//                .range([0, innerWidth]);

            // Define x-axis
            var xAxis = d3.axisBottom(xScale)
                .tickFormat(d3.timeFormat('%H:%M:%S'))
                .ticks(5);

            // Define the y-scale
            var yScale = d3.scaleLinear()
                .domain([0, d3.max(data, function(d) { return getAttribute(d, domain, SHOW_MIN_MAX_BARS ? "maxWindow" : "percent99th");})])
                .range([height-margins.bottom, margins.top]);

            // Define the y grid
            var yGrid = d3.axisLeft(yScale)
	            .tickSize(-width + margins.left + margins.right, 0, 0)
	            .tickFormat("");

            // Define the y-axis
            var yAxis = d3.axisLeft(yScale)
                .tickFormat(d3.format('.2s'));

            // Draw x-axis
            svg.select('.x-axis')
                .attr('transform', 'translate(0, ' + (height-margins.bottom) + ')')
                .call(xAxis);

            // Draw the y-axis
            svg.select('.y-axis')
                .attr('transform', 'translate(' + margins.left + ')')
                .call(yAxis);
            svg.select('.y-grid')
	            .attr("transform", "translate(" + margins.left	 + ")")
	            .call(yGrid);

            // Add the new data points
            svg.select('.data')
                .selectAll('circle')
                .data(data)
	            .attr('r', circleSize)
	            .attr('cx', function(d) {return xScale(getX(d));})
	            .attr('cy', function(d) {return yScale(getAttribute(d, domain, "avgWindow"));})
                .enter()
                .append('circle')
                .attr('class', 'data-point')
	            .attr('r', circleSize)
	            .attr('cx', function(d) {return xScale(getX(d));})
	            .attr('cy', function(d) {return yScale(getAttribute(d, domain, "avgWindow"));});

            // Plot the range bars
            var rangeBars = function(d) {
            	var minWindow = yScale(getAttribute(d, domain, "minWindow"));
            	var maxWindow = yScale(getAttribute(d, domain, "maxWindow"));
            	var x = xScale(getX(d));
        		return [ "M", [x-3, minWindow ],
        		         "L", [x+3, minWindow ],
        		         "L", [x, minWindow ],
        		         "L", [x, maxWindow ],
        		         "L", [x-3, maxWindow ],
        		         "L", [x+3, maxWindow ]
        		         ].join(" ");
            };
            if (SHOW_MIN_MAX_BARS) {
	            svg.select('.data')
	            	.selectAll('.range')
	            	.data(data)
	            	.attr('d', rangeBars)
	            	.enter()
	            	.append('path')
	            	.attr('class', 'range')
	            	.attr('d', rangeBars);
            }
            
            svg.select('.data')
	            .selectAll('.range').data(data)
	            .exit()
	            .remove();

            
            // Plot the average (Window) line
            var line = d3.line()
                .x(function(d) { return xScale(getX(d));})
                .y(function(d) { return yScale(getAttribute(d, domain, "avgWindow"));})
                 .curve(d3.curveLinear);
            svg.select('.avg-line-window')
            	.select('path')
                .datum(data)
                .attr('d', line);

            // Plot the average line
            var line = d3.line()
                .x(function(d) { return xScale(getX(d));})
                .y(function(d) { return yScale(getAttribute(d, domain, "average"));})
                 .curve(d3.curveLinear);
            svg.select('.avg-line')
            	.select('path')
                .datum(data)
                .attr('d', line);
            svg.select('.avg-line text')
	    		.attr('x', width-margins.right-70)
	    		.attr('y', d3.max(data, function(d) { return yScale(getAttribute(d, domain, "average"));}))
	    		.text("avg (" + d3.max(data, function(d) { return getAttribute(d, domain, "average");}) + "ms)");

            // Plot the 95th% line
            var line = d3.line()
                .x(function(d) { return xScale(getX(d));})
                .y(function(d) { return yScale(getAttribute(d, domain, "percent95th"));})
                 .curve(d3.curveLinear);
            svg.select('.ninetyfifth-line')
            	.select('path')
                .datum(data)
                .attr('d', line);
            svg.select('.ninetyfifth text')
        		.attr('x', width-margins.right-70)
        		.attr('y', d3.max(data, function(d) { return yScale(getAttribute(d, domain, "percent95th"));}))
        		.text("95% (" + d3.max(data, function(d) { return getAttribute(d, domain, "percent95th");}) + "ms)");

            // Plot the 99th percentile line
            var line = d3.line()
                .x(function(d) { return xScale(getX(d));})
                .y(function(d) { return yScale(getAttribute(d, domain, "percent99th"));})
                 .curve(d3.curveLinear);
            svg.select('.ninetyninth-line')
            	.select('path')
                .datum(data)
                .attr('d', line);
            svg.select('.ninetyninth text')
	    		.attr('x', width-margins.right-70)
	    		.attr('y', d3.max(data, function(d) { return yScale(getAttribute(d, domain, "percent99th"))}))
	    		.text("99% (" + d3.max(data, function(d) { return getAttribute(d, domain, "percent99th");}) + "ms)");

            // Plot the minimum line
            var line = d3.line()
                .x(function(d) { return xScale(getX(d));})
                .y(function(d) { return yScale(getAttribute(d, domain, "min"));})
                 .curve(d3.curveLinear);
            svg.select('.min-line')
            	.select('path')
                .datum(data)
                .attr('d', line);
            svg.select('.min-line text')
	    		.attr('x', width-margins.right-70)
	    		.attr('y', d3.max(data, function(d) { return yScale(getAttribute(d, domain, "min"));}))
	    		.text("min (" + d3.max(data, function(d) { return getAttribute(d, domain, "min");}) + "ms)");

            var activePoint = svg.select('.data-point-active');
            var xCursor = svg.select('.x-cursor');
            var yCursor = svg.select('.y-cursor');
            var cursorData = svg.select('.cursor-data');

            var floatOverWidth = Number(svg.select('.cursor-data rect').attr('width'));
            
            svg.on('mouseenter', function() {
            });
            svg.on('mouseleave', function() {
            	svg.select('.cursor')
            		.style('opacity', '0');
            })
            svg.on('mousemove', function(){
                var pos = d3.mouse(this);
                var xValue = xScale.invert(pos[0]);
                var xBisect = d3.bisector(function(d) { return d.x; }).left;
                var index = xBisect(data, xValue);
                
                var hMargin = -8;
                var vMargin = 3;
                var xMin = d3.min(data, function(d) { return d.x; });
                var xMax = d3.max(data, function(d) { return d.x; });
                var yMax = d3.max(data, function(d) { return d[domain].average; });

                if (index == 0 || index >= data.length) {
                  return;
                }

                // get the nearest value
                var d0 = data[index - 1];
                var d1 = data[index];

                var d = xValue - d0.x > d1.x - xValue ? d1 : d0;
                
                if (d===undefined || !d.hasOwnProperty('x')) {
                  return;
                }
                
                activePoint
	                .attr("cx", xScale(d.x))
	                .attr("cy", yScale(d[domain].avgWindow))
	                .attr("r", 5);

                xCursor
	                .attr('x1', xScale(d.x))
	                .attr('y1', yScale(0))
	                .attr('x2', xScale(d.x))
	                .attr('y2', yScale(d[domain].avgWindow));
            
                yCursor
	                .attr('x1', xScale(xMin))
	                .attr('y1', yScale(d[domain].avgWindow))
	                .attr('x2', xScale(d.x))
	                .attr('y2', yScale(d[domain].avgWindow));
                
                var locX;
                var locY = pos[1];
                if (pos[0] + floatOverWidth+10 > width) {
                	locX = pos[0] - floatOverWidth - 10;
                }
                else {
                	locX = pos[0] +15;
                }
                if (locY < 5) {
                	locY = 5;
                }
                cursorData
                	.attr('transform', 'translate(' + locX + ', ' + locY + ')');
                
            	svg.select('.cursor')
            		.style('opacity', '1');

                cursorData.select('.cursor-text-val.min').text(d[domain].min + 'ms');
                cursorData.select('.cursor-text-val.max').text(d[domain].max + 'ms');
                cursorData.select('.cursor-text-val.avg').text(d[domain].average + 'ms');
                cursorData.select('.cursor-text-val.ninetyfifth').text(d[domain].percent95th + 'ms');
                cursorData.select('.cursor-text-val.ninetyninth').text(d[domain].percent99th + 'ms');
                cursorData.select('.cursor-text-val.winMin').text(d[domain].minWindow + 'ms');
                cursorData.select('.cursor-text-val.winMax').text(d[domain].maxWindow + 'ms');
                cursorData.select('.cursor-text-val.winAvg').text(d[domain].avgWindow + 'ms');
                cursorData.select('.cursor-text-val.winOps').text((d[domain].countWindow * 1000 / d.windowSize).round(0));
            });
/*
            var traceRect = null;
            svg.on('mousedown', function() {
                var pos = d3.mouse(this);
                var color = d3.rgb('steelblue');
                color.opacity = 0.2;
                traceRect = svg.append('rect')
                    .attr('x', pos[0])
                    .attr('y', pos[1])
                    .attr('width', 0)
                    .attr('height', 0)
                    .style('fill', color);

            });
            svg.on('mousemove', function() {
               if (traceRect) {
                   var pos = d3.mouse(this);
                   traceRect.attr('width', pos[0] - traceRect.attr('x'))
                       .attr('height', pos[1] - traceRect.attr('y'));
               }
            });
            svg.on('mouseup', function() {
                if (traceRect) {
                    traceRect.remove();
                    traceRect = null;
                }
            })
*/
        };

        // var cursorCont = xAxis.append('g').attr('class', 'cursor');
        // cursorCont.append('line').attr('class', 'x-cursor cursor');
        // cursorCont.append('line').attr('class', 'y-cursor cursor');
        // cursorCont.append('text').attr('class', 'x-label label');
        // cursorCont.append('text').attr('class', 'y-label label');

        return {
            restrict: 'E',
            scope: {
                heading: '@',
                domain: '@',
                data: '=',
            },
            compile: function(element, attrs, translude) {
                // Create an SVG root element
                var svg = d3.select(element[0]).append('svg');

                var visCont = svg.append('g').attr('class', 'vis');
                var axisCont = visCont.append('g').attr('class', 'axis');
                var dataCont = visCont.append('g').attr('class', 'data');
                var focusCont = visCont.append('g').attr('class', 'focus');
                var titleCont = visCont.append('g').attr('class', 'title');
                var cursorCont = visCont.append('g').attr('class', 'cursor').style('opacity', '0');

                var titleText = titleCont.append('text')
        			.attr('class', 'chartTitle');

                //cursor.append('g').attr('class', 'float-over');
                cursorCont.append('circle').attr('class', 'data-point-active');
                cursorCont.append('line').attr('class', 'x-cursor cursor');
                cursorCont.append('line').attr('class', 'y-cursor cursor');
                var cursorDataCont = cursorCont.append('g').attr('class', 'cursor-data');

                // Build the status container
                cursorDataCont.append('rect').attr('rx','10').attr('ry','10').attr('width','130').attr('height','160');
                cursorDataCont.append('text').attr('class', 'cursor-text min').attr('x', '10').attr('y','20').text('min:');
                cursorDataCont.append('text').attr('class', 'cursor-text max').attr('x', '10').attr('y','36').text('max:');
                cursorDataCont.append('text').attr('class', 'cursor-text avg').attr('x', '10').attr('y','52').text('avg:');
                cursorDataCont.append('text').attr('class', 'cursor-text ninetyfifth').attr('x', '10').attr('y','68').text('95th%:');
                cursorDataCont.append('text').attr('class', 'cursor-text ninetyninth').attr('x', '10').attr('y','84').text('99th%:');
                cursorDataCont.append('text').attr('class', 'cursor-text winMin').attr('x', '10').attr('y','100').text('min(w):');
                cursorDataCont.append('text').attr('class', 'cursor-text winMax').attr('x', '10').attr('y','116').text('max(w):');
                cursorDataCont.append('text').attr('class', 'cursor-text winAvg').attr('x', '10').attr('y','132').text('avg(w):');
                cursorDataCont.append('text').attr('class', 'cursor-text winOps').attr('x', '10').attr('y','148').text('count(w):');

                cursorDataCont.append('text').attr('class', 'cursor-text-val min').attr('x', '65').attr('y','20').text('0ms');
                cursorDataCont.append('text').attr('class', 'cursor-text-val max').attr('x', '65').attr('y','36').text('0ms');
                cursorDataCont.append('text').attr('class', 'cursor-text-val avg').attr('x', '65').attr('y','52').text('0ms');
                cursorDataCont.append('text').attr('class', 'cursor-text-val ninetyfifth').attr('x', '65').attr('y','68').text('0ms');
                cursorDataCont.append('text').attr('class', 'cursor-text-val ninetyninth').attr('x', '65').attr('y','84').text('0ms');
                cursorDataCont.append('text').attr('class', 'cursor-text-val winMin').attr('x', '65').attr('y','100').text('0ms');
                cursorDataCont.append('text').attr('class', 'cursor-text-val winMax').attr('x', '65').attr('y','116').text('0ms');
                cursorDataCont.append('text').attr('class', 'cursor-text-val winAvg').attr('x', '65').attr('y','132').text('0ms');
                cursorDataCont.append('text').attr('class', 'cursor-text-val winOps').attr('x', '65').attr('y','148').text('0');

                
                axisCont.append('g').attr('class', 'x-grid grid');
                axisCont.append('g').attr('class', 'y-grid grid');

                axisCont.append('g').attr('class', 'x-axis axis');
                axisCont.append('g').attr('class', 'y-axis axis');
                
                dataCont.append('g').attr('class', 'data');
                dataCont.append('g').attr('class', 'data-area');
                
                dataCont.append('g').attr('class', 'avg-line-window').append('path');
                dataCont.append('g').attr('class', 'avg-line').append('path');
                dataCont.append('g').attr('class', 'ninetyfifth ninetyfifth-line').append('path');
                dataCont.append('g').attr('class', 'ninetyninth ninetyninth-line').append('path');
                dataCont.append('g').attr('class', 'min-line').append('path');
                dataCont.append('g').attr('class', 'avg-line line-text').append('text');
                dataCont.append('g').attr('class', 'ninetyfifth line-text').append('text');
                dataCont.append('g').attr('class', 'ninetyninth line-text').append('text');
                dataCont.append('g').attr('class', 'min-line line-text').append('text');

                // Define the dimensions for the chart
                var width = 600, height = 300;

                // Return the link to the function
                return function(scope, element, attrs) {
                    // Watch the data attribute of the sccope
                    scope.$watch('data', function(newVal, oldVal, scope) {
                        // update the chart
                        draw(svg, width, height, scope.data, scope.heading, scope.domain);
                    }, true)
                };
            }
        };
    }]
)
.directive('throughputChart', ['d3',
    function(d3) {
        function draw(svg, width, height, data, title, domain) {
            svg
                .attr('width', width)
                .attr('height', height);
            
            var getAttribute = function(data, domain, attribute) {
            	try {
            		var obj = data[domain];
            		if (obj) {
            			return data[domain][attribute];
            		}
            	}
            	catch (e) {
            	}
            	return 0;
            };
            var getX = function(obj) {
            	if (!obj || (obj.x === undefined)) {
            		return 0;
            	}
            	return obj.x;
            }

            if (title !== undefined && title != '') {
                var titleElement = svg.select('.chartTitle');
                if (titleElement.size() == 0) {
                	var fontSize = Math.floor(width/30) + 'px';
                	svg.append('g')
                		.append('text')
                		.attr('class', 'chartTitle')
                		.attr('x', width/2)
                		.attr('y', 20)
                		.text(title)
                		.attr('font-size', fontSize);
                }
            }
            // Define a margin:
            var margins = {top: 30, left: 50, right: 20, bottom: 30};
            var innerWidth = width - margins.left - margins.right;
            var innerHeight = height - margins.top - margins.bottom;
            
            var margin = 50;
            var parseDate = d3.timeFormat('')
            // Define the x-scale
            var xScale = d3.scaleTime()
                .domain(d3.extent(data, function(d) { return d.date; }))
                .range([margins.left, width-margins.right]);
//                .range([0, innerWidth]);

            // Define x-axis
            var xAxis = d3.axisBottom(xScale)
                .tickFormat(d3.timeFormat('%H:%M:%S'))
                .ticks(5);

            // Define the y-scale
            var yScale;
            if (getAttribute(data[0], domain, "countsWindow") > 0) {
                yScale = d3.scaleLinear()
	                .domain([0, d3.max(data, function(d) { return getAttribute(d, domain, "countsWindow") * 1000 / d.windowSize;})])
	                .range([height-margins.bottom, margins.top]);
            }
            else {
                yScale = d3.scaleLinear()
	                .domain([0, d3.max(data, function(d) { return getAttribute(d, domain, "countWindow") * 1000 / d.windowSize;})])
	                .range([height-margins.bottom, margins.top]);
            }

            // Define the y-axis
            var yAxis = d3.axisLeft(yScale)
                .tickFormat(d3.format('.2s'));

            // Draw x-axis
            svg.select('.x-axis')
                .attr('transform', 'translate(0, ' + (height-margins.bottom) + ')')
                .call(xAxis);

            // Draw the y-axis
            svg.select('.y-axis')
                .attr('transform', 'translate(' + margins.left + ')')
                .call(yAxis);

            // Add the new data points
            svg.select('.data')
                .selectAll('circle')
                .data(data)
	            .attr('r', 2)
	            .attr('cx', function(d) {return xScale(getX(d));})
	            .attr('cy', function(d) {return yScale(getAttribute(d, domain, "countWindow") * 1000 / d.windowSize);})
                .enter()
                .append('circle')
                .attr('class', 'data-point')
	            .attr('r', 2)
	            .attr('cx', function(d) {return xScale(getX(d));})
	            .attr('cy', function(d) {return yScale(getAttribute(d, domain, "countWindow") * 1000 / d.windowSize);});

            // Now add the filled areas
            var area = d3.area()
                .x(function(d) { return xScale(getX(d));})
                .y0(yScale(0))
                .y1(function(d) { return yScale(getAttribute(d, domain, "countWindow") * 1000 / d.windowSize);});

            if (data[0] !== undefined && data[0][domain] !== undefined) {
            	if ( data[0][domain].hitsWindow !== undefined) {
	            	// Need to display hits vs misses
	                var hitsArea = d3.area()
		                .x(function(d) { return xScale(getX(d));})
		                .y0(yScale(0))
		                .y1(function(d) { return yScale(getAttribute(d, domain, "hitsWindow") * 1000 / d.windowSize);});
	
	                svg.select('.data-area path')
		                .style('fill', 'lightcyan')
		                .datum(data)
		                .attr('d', area);
		            svg.select('.data-area-success path')
		                .style('fill', 'lightblue')
		                .datum(data)
		                .attr('d', hitsArea);
	            }
            	else if ( data[0][domain].countsWindow !== undefined) {
	            	// Need to display hits vs misses
	                var countsArea = d3.area()
		                .x(function(d) { return xScale(getX(d));})
		                .y0(yScale(0))
		                .y1(function(d) { return yScale(getAttribute(d, domain, "countsWindow") * 1000 / d.windowSize);});
	
	                svg.select('.data-area path')
		                .style('fill', 'lightgreen')
		                .datum(data)
		                .attr('d', countsArea);
		            svg.select('.data-area-success path')
		                .style('fill', 'lightblue')
		                .datum(data)
		                .attr('d', area);
            	}
	            else {
	            	// Only one chart to display
	                svg.select('.data-area path')
		                .style('fill', 'lightblue')
		                .datum(data)
		                .attr('d', area);
	            }
            }
/*
            var traceRect = null;
            svg.on('mousedown', function() {
                var pos = d3.mouse(this);
                var color = d3.rgb('steelblue');
                color.opacity = 0.2;
                traceRect = svg.append('rect')
                    .attr('x', pos[0])
                    .attr('y', pos[1])
                    .attr('width', 0)
                    .attr('height', 0)
                    .style('fill', color);

            });
            svg.on('mousemove', function() {
               if (traceRect) {
                   var pos = d3.mouse(this);
                   traceRect.attr('width', pos[0] - traceRect.attr('x'))
                       .attr('height', pos[1] - traceRect.attr('y'));
               }
            });
            svg.on('mouseup', function() {
                if (traceRect) {
                    traceRect.remove();
                    traceRect = null;
                }
            })
*/
        };

        // var cursorCont = xAxis.append('g').attr('class', 'cursor');
        // cursorCont.append('line').attr('class', 'x-cursor cursor');
        // cursorCont.append('line').attr('class', 'y-cursor cursor');
        // cursorCont.append('text').attr('class', 'x-label label');
        // cursorCont.append('text').attr('class', 'y-label label');

        return {
            restrict: 'E',
            scope: {
            	heading: '@',
                domain: '@',
                width: '@',
                height: '@',
                data: '=',
            },
            compile: function(element, attrs, translude) {
                // Create an SVG root element
                var svg = d3.select(element[0]).append('svg');//.style('width','100%').style('height', '100%');

                svg.append('g').attr('class', 'data');
                svg.append('g').attr('class', 'x-axis axis');
                svg.append('g').attr('class', 'y-axis axis');
                svg.append('g').attr('class', 'data-area area').append('path');
                svg.append('g').attr('class', 'data-area-success area').append('path');

                var rect = svg.node().getBoundingClientRect();
                console.log(rect);
                // Define the dimensions for the chart
                var defWidth = 600, defHeight = 300;

                // Return the link to the function
                return function(scope, element, attrs) {
                	
                    // Watch the data attribute of the sccope
                    scope.$watch('data', function(newVal, oldVal, scope) {
                        // update the chart
//                    	var w = Number(scope.width || defWidth);
//                    	var h = Number(scope.height || defHeight);
//                    	w = rect.width;
//                    	h = rect.height;
                    	var w = 600, h = 300;
                        draw(svg, w, h, scope.data, scope.heading, scope.domain);
                    }, true)
                };
            }
        };
    }]
);