'use strict';

/*
 // Declare app level module which depends on views, and components
 angular.module('myApp', [
 'ngRoute',
 'myApp.view1',
 'myApp.view2',
 'myApp.version'
 ]).
 config(['$locationProvider', '$routeProvider', function($locationProvider, $routeProvider) {
 $locationProvider.hashPrefix('!');

 $routeProvider.otherwise({redirectTo: '/view1'});
 }]);
 */
angular.module('myApp', ['myChart'])
.controller('MainCtrl', ['$scope', '$interval', '$http', 'SimpleHttpLoader',
                         function($scope, $interval, $http, SimpleHttpLoader) {

	var NUM_DATA_TO_KEEP = 100;
	Number.prototype.round = function(places) {
		  return +(Math.round(this + "e+" + places)  + "e-" + places);
		};
	var parser = d3.timeParse('%Y%m%d-%H%M%S');

	$scope.modes = [{name:"FULL", description: "Full functionality (limited in Cassandra)"},
	                {name:"COMPATIBLE", description: "Equivalent read/write functionality"},
	                {name:"READONLY", description: "Only querying the account s-codes"}];
	$scope.selectedMode = $scope.modes[0];

	$scope.updateMode = function() {
		console.log($scope.selectedMode);
		for (let nodeIndex = 0; nodeIndex < $scope.nodes.length; nodeIndex++) {
			$http.post(nodes[nodeIndex].url + "/control?mode=" + $scope.selectedMode.name);
		} 
	}
	var nodes = [];
	// Load the list of the nodes from local storage
	if (Modernizr.localstorage) {
		var nodesStr = localStorage["nodes"];
		if (nodesStr == undefined) {
			nodes = [{url:"http://localhost:8080", status: "pending"}];
		}	
		else {
			nodes = JSON.parse(nodesStr);
		}
		console.log("Nodes = " + nodes);
	}
	$scope.nodes = nodes;

	$scope.data = [];
//	$scope.information =[{x:0, y:5}, {x:1, y:6}, {x:2, y:10}];
	$scope.information = [];

	function descendAndAdd(aggregation, newResult) {
		if (aggregation.count > 0 && newResult.count > 0) {
			if (newResult.hasOwnProperty("hits")) {
				aggregation.hits += newResult.hits;
				aggregation.hitsWindow += newResult.hitsWindow;
			}
			if (newResult.hasOwnProperty("counts")) {
				aggregation.counts += newResult.counts;
				aggregation.countsWindow += newResult.countsWindow;
			}
			aggregation.average = ((aggregation.average*aggregation.count + newResult.count*newResult.average) / (aggregation.count + newResult.count)).round(2); 
			aggregation.avgWindow = ((aggregation.avgWindow*aggregation.countWindow + newResult.countWindow*newResult.avgWindow) / (aggregation.countWindow + newResult.countWindow)).round(2);
			aggregation.count += newResult.count;
			aggregation.countWindow += newResult.countWindow;
			aggregation.max = Math.max(aggregation.max, newResult.max);
			aggregation.maxWindow = Math.max(aggregation.maxWindow, newResult.maxWindow);
			aggregation.min = Math.min(aggregation.min, newResult.min);
			aggregation.minWindow = Math.min(aggregation.minWindow, newResult.minWindow);
			aggregation.percent95th = ((aggregation.resultCount*aggregation.percent95th + newResult.percent95th) / (aggregation.resultCount+1)).round(2);
			aggregation.percent99th = ((aggregation.resultCount*aggregation.percent99th + newResult.percent99th) / (aggregation.resultCount+1)).round(2);
			aggregation.resultCount += 1;
		}
		else {
			aggregation = newResult;
			aggregation.timings = [];	// Throw away the timings for now.
			aggregation.resultCount = 1;
		}
		return aggregation;
//		for (var attrName in newResult) {
//			if (newResult.hasOwnProperty(attrName) && typeof(newResult[attrName] === "number")) {
//				if (typeof(aggregation[attrName]) === "number") {
//					aggregation[attrName] += newResult[attrName];
//				}
//				else {
//					aggregation[attrName] = newResult[attrName];
//				}
//			}
//		}
	}

	function process() {
		var results = {valid: false};
		var count = 0;
		var addResultsToArray = function() {
			count--;
			if (count === 0) {
				if (results.valid) {
					$scope.information.push(results);
					// Record only 180 iterations
					if ($scope.information.length > NUM_DATA_TO_KEEP) {
						$scope.information = $scope.information.slice(-NUM_DATA_TO_KEEP);
					}
				}
			}
		}
		var process = function(index) {
			var processor = function(xhrResults) {
				try {
					nodes[index].status = "online";
					results.valid = true;
					results.date = parser(xhrResults.data.date);
					results.windowSize = xhrResults.data.windowSize;
					// Merge these results into the data
					for (var attrName in xhrResults.data) {
						if (xhrResults.data.hasOwnProperty(attrName) && attrName !== "date" && attrName !== "windowSize") {
							if (!results.hasOwnProperty(attrName)) {
								results[attrName] = {resultCount:0};
							}
							results[attrName] = descendAndAdd(results[attrName], xhrResults.data[attrName]);
						}
					}
					results.x = results.date;
				}
				finally {
					addResultsToArray();
				}
			};
			return processor;
		}
		var failed = function(index) {
			return function(reason) {
				try {
					nodes[index].status = "offline";
				}
				finally {
					addResultsToArray();
				}
			}
		};
		var promises = [];
		for (var i = 0; i < nodes.length; i++) {
			count++;
			promises[i] = SimpleHttpLoader(nodes[i].url + "/data/info");
			promises[i].then(process(i), failed(i));
		}
	}
	process();
	var stop = $interval(process, 5000);

	function updateNodes() {
		if (Modernizr.localstorage) {
			localStorage["nodes"] = JSON.stringify($scope.nodes);
		}
	}
	$scope.addNode = function() {
		var node = $scope.newNodeName;
		if (node === undefined || node == '') {
			$scope.newNodeError = 'Node address must be entered';
		}
		else if (!(node.startsWith("http://") || node.startsWith("https://"))) {
			$scope.newNodeError = 'Node address must start with http(s)';
		}
		else {
			var found = false;
			for (var i = 0; i < $scope.nodes.length; i++) {
				if ($scope.nodes[i].url == node) {
					$scope.newNodeError = 'Cannot enter an existing node address';
					found = true;
					break;
				}
			}
			if (!found) {
				$scope.nodes.push({url: node, status: 'offline'});
				$scope.newNodeError = '';
				$scope.newNodeName = '';
				updateNodes();
			}
		}
	}
	$scope.removeNode = function(node, index) {
		console.log("remove node " + node);
		$scope.nodes.splice(index, 1);	
		updateNodes();
	};
}]);