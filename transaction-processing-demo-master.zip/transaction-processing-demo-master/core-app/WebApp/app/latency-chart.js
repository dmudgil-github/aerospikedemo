nv.addGraph(function() {
  var chart = nv.models.lineChart()
                .margin({left: 100})  
                .useInteractiveGuideline(true)  
                .transitionDuration(350)  
                .showLegend(true)       
                .showYAxis(true)        
                .showXAxis(true)  
  ;

  chart.xAxis     
      .axisLabel('Time')
      .tickFormat(d3.format(',r'));

  chart.yAxis     
      .axisLabel('Score')
      .tickFormat(d3.format('.02f'));


  var myData = data();   

  d3.select('#chart svg')    
      .datum(myData)       
      .call(chart);          

  //Update the chart when window resizes.
  nv.utils.windowResize(function() { chart.update() });
  return chart;
});
