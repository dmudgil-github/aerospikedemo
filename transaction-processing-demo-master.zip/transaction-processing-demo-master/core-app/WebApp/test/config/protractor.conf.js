exports.config = {
    // The address of a running Selenium server
    seleniumAddress: 'http://localhost:4444/wd/hub',

    // Spec patterns are relative to the config file location passed to protractor
    specs: [
        '../e2e/**/*.e2e.js'
    ],

    baserUrl: 'http://127.0.0.1:8000',

    // Options to be passed to Jasmine node
    jasmineNodeOpts: {
        showColors: true,   // Use colors in the commqnd line report.
    }
};
