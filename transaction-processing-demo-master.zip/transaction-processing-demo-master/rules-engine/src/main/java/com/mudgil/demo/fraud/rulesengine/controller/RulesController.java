package com.mudgil.demo.fraud.rulesengine.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.mudgil.demo.fraud.rulesengine.model.DecisionFact;
import com.mudgil.demo.fraud.rulesengine.model.Payload;
import com.mudgil.demo.fraud.rulesengine.model.TransactionFact;
import com.mudgil.demo.fraud.rulesengine.service.DecisionService;



@RestController
public class RulesController {

	private final DecisionService decisionService;
	
	public static final Logger logger = LoggerFactory.getLogger(RulesController.class);

	@Autowired
	public RulesController(DecisionService decisionService) {
		this.decisionService = decisionService;
	}

	@RequestMapping(value = "/getDecision", method = RequestMethod.GET, produces = "application/json")
	public TransactionFact getDecision(@RequestParam(required = false) String origRef, @RequestParam(required = false) String load) {
		
		System.out.println("getDecision() -"+origRef + "\t" +load);
		
		Payload payLoad = new Payload();
		payLoad.setOrigRef(origRef);
		payLoad.setLoad(load);

		TransactionFact decision = decisionService.getDecision(payLoad);

		return decision;
	}
	
}
