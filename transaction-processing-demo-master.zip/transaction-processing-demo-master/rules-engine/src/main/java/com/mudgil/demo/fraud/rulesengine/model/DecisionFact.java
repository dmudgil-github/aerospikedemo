package com.mudgil.demo.fraud.rulesengine.model;

public class DecisionFact {

	private String origRef;
	private int reasonCode;
	private int decision;
	
	
	public String getOrigRef() {
		return origRef;
	}

	public DecisionFact(String origRef) {
		this.origRef = origRef;
	}
	
	public int getReasonCode() {
		return reasonCode;
	}
	public void setReasonCode(int reasonCode) {
		this.reasonCode = reasonCode;
	}
	public int getDecision() {
		return decision;
	}
	public void setDecision(int decision) {
		this.decision = decision;
	}


}