package com.mudgil.demo.fraud.rulesengine.model;

public class TransactionFact {

	private String origRef;
	private String txnType;
	private double txnAmount;
	private int score;
	private int scoreCode;
	
	public String getOrigRef() {
		return origRef;
	}
	public void setOrigRef(String origRef) {
		this.origRef = origRef;
	}
	public String getTxnType() {
		return txnType;
	}
	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}
	public double getTxnAmount() {
		return txnAmount;
	}
	public void setTxnAmount(double txnAmount) {
		this.txnAmount = txnAmount;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public int getScoreCode() {
		return scoreCode;
	}
	public void setScoreCode(int scoreCode) {
		this.scoreCode = scoreCode;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((origRef == null) ? 0 : origRef.hashCode());
		result = prime * result + score;
		result = prime * result + scoreCode;
		long temp;
		temp = Double.doubleToLongBits(txnAmount);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((txnType == null) ? 0 : txnType.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TransactionFact other = (TransactionFact) obj;
		if (origRef == null) {
			if (other.origRef != null)
				return false;
		} else if (!origRef.equals(other.origRef))
			return false;
		if (score != other.score)
			return false;
		if (scoreCode != other.scoreCode)
			return false;
		if (Double.doubleToLongBits(txnAmount) != Double.doubleToLongBits(other.txnAmount))
			return false;
		if (txnType == null) {
			if (other.txnType != null)
				return false;
		} else if (!txnType.equals(other.txnType))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "TransactionFact [origRef=" + origRef + ", txnType=" + txnType + ", txnAmount=" + txnAmount + ", score="
				+ score + ", scoreCode=" + scoreCode + "]";
	}

	
	
}