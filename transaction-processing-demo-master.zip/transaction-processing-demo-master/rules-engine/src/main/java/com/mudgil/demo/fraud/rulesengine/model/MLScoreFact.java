package com.mudgil.demo.fraud.rulesengine.model;

public class MLScoreFact {

	private int mlScore;

	public int getMlScore() {
		return mlScore;
	}

	public void setMlScore(int mlScore) {
		this.mlScore = mlScore;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + mlScore;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MLScoreFact other = (MLScoreFact) obj;
		if (mlScore != other.mlScore)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "MLScoreFact [mlScore=" + mlScore + "]";
	}

	
	
}