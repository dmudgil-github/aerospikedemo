package com.mudgil.demo.fraud.rulesengine.model;

public class Payload {
	
	private String origRef;
	private String load;
	
	public Payload() {
		
	}
	
	public Payload(String origRef) {
		this.origRef = origRef;
	}
	
	public String getOrigRef() {
		return origRef;
	}
	
	public void setOrigRef(String origRef) {
		this.origRef = origRef;
	}
	
	public String getLoad() {
		return load;
	}
	
	public void setLoad(String load) {
		this.load = load;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((load == null) ? 0 : load.hashCode());
		result = prime * result + ((origRef == null) ? 0 : origRef.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Payload other = (Payload) obj;
		if (load == null) {
			if (other.load != null)
				return false;
		} else if (!load.equals(other.load))
			return false;
		if (origRef == null) {
			if (other.origRef != null)
				return false;
		} else if (!origRef.equals(other.origRef))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Payload [origRef=" + origRef + ", load=" + load + "]";
	}
	

	

}
