package com.mudgil.demo.fraud.rulesengine.service;

import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mudgil.demo.fraud.rulesengine.model.DecisionFact;
import com.mudgil.demo.fraud.rulesengine.model.Payload;
import com.mudgil.demo.fraud.rulesengine.model.TransactionFact;

@Service
public class DecisionService {

	private final KieContainer kieContainer;

	@Autowired
	public DecisionService(KieContainer kieContainer) {
		this.kieContainer = kieContainer;
	}

	public TransactionFact getDecision(Payload payload) {
		KieSession kieSession = kieContainer.newKieSession("rulesSession");
		
		TransactionFact txnFact = new TransactionFact();
		txnFact.setOrigRef(payload.getOrigRef());
		txnFact.setTxnAmount(2000);
		
//		DecisionFact decision = new DecisionFact (payload.getOrigRef());
		
		kieSession.insert(txnFact);
		kieSession.fireAllRules();
		kieSession.dispose();
		return txnFact;
	}
}